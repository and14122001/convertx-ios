import {
  acdbCreateDxfPairReader,
  acdbHostApplicationServices,
  acdbPeekDxfHeaderInfo
} from '../src/base'
import {
  AcDbCodePage,
  acdbDwgCodePageToEncoding,
  acdbNormalizeTextEncoding,
  acdbResolveDwgCodePage,
  acdbResolveDwgCodePageEncoding
} from '../src/misc'
import { AcDbDatabase } from '../src/database'
import { AcDbNativeDxfConverter } from '../src/dxf'

/** '한글' encoded in CP949 / EUC-KR (KS X 1001): 0xC7 0xD1 0xB1 0xDB. */
const HANGUL_CP949 = Uint8Array.from([0xc7, 0xd1, 0xb1, 0xdb])
/** 'Пример' in IBM866 / DOS866. */
const CYRILLIC_CP866 = Uint8Array.from([0x8f, 0xe0, 0xa8, 0xac, 0xa5, 0xe0])
/** 'サンプル' in Shift_JIS / DOS932. */
const JAPANESE_CP932 = Uint8Array.from([
  0x83, 0x54, 0x83, 0x93, 0x83, 0x76, 0x83, 0x8b
])
/** '예시' in EUC-KR / KSC5601. */
const KOREAN_KSC5601 = Uint8Array.from([0xbf, 0xb9, 0xbd, 0xc3])

/**
 * Builds DXF bytes whose lines are ASCII except the entries listed in
 * `rawLines`, which are spliced in as raw byte sequences. This lets tests
 * embed non-UTF-8 (e.g. CP949) string values that `TextEncoder` cannot
 * produce.
 */
function buildDxfBytes(lines: (string | Uint8Array)[]): ArrayBuffer {
  const chunks: Uint8Array[] = []
  for (const line of lines) {
    if (typeof line === 'string') {
      const bytes = new Uint8Array(line.length)
      for (let i = 0; i < line.length; i++) {
        const c = line.charCodeAt(i)
        if (c > 0x7f) throw new Error('non-ASCII line must be Uint8Array')
        bytes[i] = c
      }
      chunks.push(bytes)
    } else {
      chunks.push(line)
    }
    chunks.push(Uint8Array.from([10]))
  }
  const total = chunks.reduce((sum, c) => sum + c.length, 0)
  const out = new Uint8Array(total)
  let offset = 0
  for (const chunk of chunks) {
    out.set(chunk, offset)
    offset += chunk.length
  }
  return out.buffer
}

/**
 * Minimal pre-R2007 DXF with a layer name and TEXT string in a legacy
 * code page (bytes must match `$DWGCODEPAGE`).
 */
function buildLegacyTextDxf(
  codePageValue: string | null,
  textBytes: Uint8Array
): ArrayBuffer {
  const lines: (string | Uint8Array)[] = [
    '0', 'SECTION',
    '2', 'HEADER',
    '9', '$ACADVER',
    '1', 'AC1015',
    ...(codePageValue
      ? (['9', '$DWGCODEPAGE', '3', codePageValue] as string[])
      : []),
    '0', 'ENDSEC',
    '0', 'SECTION',
    '2', 'TABLES',
    '0', 'TABLE',
    '2', 'LAYER',
    '0', 'LAYER',
    '5', '10',
    '100', 'AcDbSymbolTableRecord',
    '100', 'AcDbLayerTableRecord',
    '2'
  ]
  lines.push(textBytes) // layer name (group 2)
  lines.push('70', '0', '62', '7', '6', 'Continuous', '0', 'ENDTAB', '0', 'ENDSEC')
  lines.push(
    '0', 'SECTION',
    '2', 'ENTITIES',
    '0', 'TEXT',
    '5', '1A',
    '100', 'AcDbEntity',
    '8'
  )
  lines.push(textBytes) // layer name (group 8)
  lines.push('100', 'AcDbText', '10', '0', '20', '0', '30', '0', '40', '2.5', '1')
  lines.push(textBytes) // text string (group 1)
  lines.push('0', 'ENDSEC', '0', 'EOF')
  return buildDxfBytes(lines)
}

function buildKoreanDxf(codePageValue: string | null): ArrayBuffer {
  return buildLegacyTextDxf(codePageValue, HANGUL_CP949)
}

function readStringPairs(
  reader: ReturnType<typeof acdbCreateDxfPairReader>
): Record<number, string> {
  const values: Record<number, string> = {}
  for (let pair = reader.next(); pair; pair = reader.next()) {
    if (pair.type === 'string' && (pair.code === 1 || pair.code === 8)) {
      values[pair.code] = pair.value as string
    }
  }
  return values
}

describe('AcDbCodePage', () => {
  it('maps Korean code pages onto the WHATWG euc-kr label', () => {
    expect(acdbDwgCodePageToEncoding(AcDbCodePage.CP949)).toBe('euc-kr')
    expect(acdbDwgCodePageToEncoding(AcDbCodePage.ANSI_949)).toBe('euc-kr')
  })

  it('normalizes common Korean/Chinese code page aliases for TextDecoder', () => {
    expect(acdbNormalizeTextEncoding('cp949')).toBe('euc-kr')
    expect(acdbNormalizeTextEncoding('CP949')).toBe('euc-kr')
    expect(acdbNormalizeTextEncoding('uhc')).toBe('euc-kr')
    expect(acdbNormalizeTextEncoding('cp936')).toBe('gbk')
    // Underscore / mixed-case forms of known labels normalize too.
    expect(acdbNormalizeTextEncoding('euc-kr')).toBe('euc-kr')
    expect(acdbNormalizeTextEncoding('EUC_KR')).toBe('euc-kr')
    expect(acdbNormalizeTextEncoding('windows-949')).toBe('euc-kr')
    // Unrelated supported labels pass through unchanged.
    expect(acdbNormalizeTextEncoding('windows-1252')).toBe('windows-1252')
    expect(acdbNormalizeTextEncoding('utf-8')).toBe('utf-8')
  })

  it('resolves ODA/BricsCAD $DWGCODEPAGE aliases case-insensitively', () => {
    expect(acdbResolveDwgCodePage('DOS866')).toBe(AcDbCodePage.CP866)
    expect(acdbResolveDwgCodePage('dos866')).toBe(AcDbCodePage.CP866)
    expect(acdbResolveDwgCodePage('DOS932')).toBe(AcDbCodePage.CP932)
    expect(acdbResolveDwgCodePage('KSC5601')).toBe(AcDbCodePage.CP949)
    expect(acdbResolveDwgCodePage('ksc5601')).toBe(AcDbCodePage.CP949)
    expect(acdbResolveDwgCodePage('ASCII')).toBe(AcDbCodePage.US_ASCII)
    expect(acdbResolveDwgCodePage('MAC-ROMAN')).toBe(AcDbCodePage.MACINTOSH)
    expect(acdbResolveDwgCodePage('ISO8859_5')).toBe(AcDbCodePage.ISO_8859_5)
    expect(acdbResolveDwgCodePage('iso8859_5')).toBe(AcDbCodePage.ISO_8859_5)
    expect(acdbResolveDwgCodePage('ansi_1251')).toBe(AcDbCodePage.ANSI_1251)
    expect(acdbResolveDwgCodePage('UTF-8')).toBe(AcDbCodePage.UTF8)
    expect(acdbResolveDwgCodePage('not-a-codepage')).toBeNull()

    expect(acdbResolveDwgCodePageEncoding('DOS866')).toBe('ibm866')
    expect(acdbResolveDwgCodePageEncoding('DOS932')).toBe('shift-jis')
    expect(acdbResolveDwgCodePageEncoding('KSC5601')).toBe('euc-kr')
    expect(acdbResolveDwgCodePageEncoding('ANSI_1251')).toBe('windows-1251')
  })
})

describe('DXF ODA/BricsCAD $DWGCODEPAGE aliases', () => {
  it.each([
    ['DOS866', CYRILLIC_CP866, 'Пример', 'ibm866'],
    ['DOS932', JAPANESE_CP932, 'サンプル', 'shift-jis'],
    ['KSC5601', KOREAN_KSC5601, '예시', 'euc-kr'],
    ['dos866', CYRILLIC_CP866, 'Пример', 'ibm866'],
    ['ksc5601', KOREAN_KSC5601, '예시', 'euc-kr']
  ] as const)(
    'decodes %s text via $DWGCODEPAGE',
    (codePage, bytes, expected, encodingLabel) => {
      const buffer = buildLegacyTextDxf(codePage, bytes)
      expect(acdbPeekDxfHeaderInfo(buffer).encoding).toBe(encodingLabel)
      const values = readStringPairs(acdbCreateDxfPairReader(buffer))
      expect(values[1]).toBe(expected)
      expect(values[8]).toBe(expected)
    }
  )
})

describe('DXF Korean (CP949) text decoding', () => {
  it('auto-detects ANSI_949 from $DWGCODEPAGE and decodes Korean strings', () => {
    const values = readStringPairs(
      acdbCreateDxfPairReader(buildKoreanDxf('ANSI_949'))
    )
    expect(values[1]).toBe('한글')
    expect(values[8]).toBe('한글')
  })

  it('honors an explicit cp949 encoding override (normalized to euc-kr)', () => {
    // Header lies: declares ANSI_1252 but the bytes are CP949.
    const values = readStringPairs(
      acdbCreateDxfPairReader(buildKoreanDxf('ANSI_1252'), {
        encoding: 'cp949'
      })
    )
    expect(values[1]).toBe('한글')
    expect(values[8]).toBe('한글')
  })

  it('decodes Korean layer names and text via the native DXF converter', async () => {
    const db = new AcDbDatabase()
    acdbHostApplicationServices().workingDatabase = db
    const converter = new AcDbNativeDxfConverter()
    await converter.read(buildKoreanDxf('ANSI_949'), db, {})

    // Layer name decoded from CP949 bytes.
    const layerNames = [...db.tables.layerTable.newIterator()].map(l => l.name)
    expect(layerNames).toContain('한글')

    // TEXT entity string decoded from CP949 bytes.
    const texts = [
      ...db.tables.blockTable.modelSpace.newIterator()
    ]
      .filter(entity => 'textString' in entity)
      .map(entity => (entity as { textString: string }).textString)
    expect(texts).toContain('한글')
  })

  it('decodes a stale pre-2007 ANSI_936 header as UTF-8 when the bytes are UTF-8', () => {
    // Some tools rewrite a legacy header onto UTF-8 content: the declared
    // version and code page are both stale. Byte validation must win over
    // the header, or every string in such files turns into mojibake.
    const lines = [
      '0', 'SECTION', '2', 'HEADER',
      '9', '$ACADVER', '1', 'AC1015',
      '9', '$DWGCODEPAGE', '3', 'ANSI_936',
      '0', 'ENDSEC',
      '0', 'SECTION', '2', 'ENTITIES',
      '0', 'TEXT', '5', '1A', '100', 'AcDbEntity',
      '8', '图层',
      '100', 'AcDbText', '10', '0', '20', '0', '30', '0', '40', '2.5', '1', '中文文本',
      '0', 'ENDSEC', '0', 'EOF'
    ]
    const bytes = new TextEncoder().encode(lines.join('\r\n') + '\r\n')
    const values = readStringPairs(acdbCreateDxfPairReader(bytes))
    expect(values[1]).toBe('中文文本')
    expect(values[8]).toBe('图层')
  })

  it('decodes legacy code-page ASCII DXF span by span, not as one string', () => {
    // Large enough that a full-file TextDecoder pass would be visible, and
    // larger than the 64 KiB header-peek chunk.
    const payload = new Uint8Array(80 * 1024)
    payload.fill(0x41)
    payload[0] = 0xdf // ß in windows-1252; invalid UTF-8 lead
    const lines: (string | Uint8Array)[] = [
      '0', 'SECTION', '2', 'HEADER',
      '9', '$ACADVER', '1', 'AC1015',
      '9', '$DWGCODEPAGE', '3', 'ANSI_1252',
      '0', 'ENDSEC',
      '0', 'SECTION', '2', 'ENTITIES',
      '0', 'TEXT', '1', payload,
      '0', 'ENDSEC', '0', 'EOF'
    ]
    const bytes = new Uint8Array(buildDxfBytes(lines))
    const decodeLengths: number[] = []
    const original = TextDecoder.prototype.decode
    TextDecoder.prototype.decode = function (
      this: TextDecoder,
      input?: AllowSharedBufferSource,
      options?: TextDecodeOptions
    ) {
      if (input != null) {
        decodeLengths.push(
          input instanceof ArrayBuffer ? input.byteLength : input.byteLength
        )
      }
      return original.call(this, input, options)
    }
    try {
      const values = readStringPairs(acdbCreateDxfPairReader(bytes))
      expect(values[1].startsWith('ß')).toBe(true)
      expect(values[1].length).toBe(payload.length)
    } finally {
      TextDecoder.prototype.decode = original
    }
    expect(decodeLengths.length).toBeGreaterThan(0)
    expect(Math.max(...decodeLengths)).toBeLessThan(bytes.byteLength)
  })
})

function buildBinaryDxfLayer(
  version: string,
  codePage: string,
  nameBytes: number[]
): Uint8Array {
  const bytes: number[] = [
    ...new TextEncoder().encode('AutoCAD Binary DXF\r\n'),
    0x1a,
    0x00
  ]
  const str = (code: number, value: number[]) => {
    bytes.push(code & 0xff, code >> 8, ...value, 0)
  }
  const ascii = (s: string) => [...s].map(c => c.charCodeAt(0))
  str(0, ascii('SECTION'))
  str(2, ascii('HEADER'))
  str(9, ascii('$ACADVER'))
  str(1, ascii(version))
  str(9, ascii('$DWGCODEPAGE'))
  str(3, ascii(codePage))
  str(0, ascii('ENDSEC'))
  str(0, ascii('SECTION'))
  str(2, ascii('TABLES'))
  str(0, ascii('LAYER'))
  str(2, nameBytes)
  str(0, ascii('ENDSEC'))
  str(0, ascii('EOF'))
  return new Uint8Array(bytes)
}

function readFirstNonSectionName(
  data: Uint8Array,
  options?: { encoding?: string }
): string | undefined {
  const reader = acdbCreateDxfPairReader(data, options)
  let name: string | undefined
  for (let pair = reader.next(); pair; pair = reader.next()) {
    if (
      pair.code === 2 &&
      pair.type === 'string' &&
      pair.value !== 'HEADER' &&
      pair.value !== 'TABLES'
    ) {
      name = pair.value as string
    }
  }
  return name
}

describe('Binary DXF $DWGCODEPAGE', () => {
  it('decodes ANSI_1252 layer names from a pre-R2007 binary DXF header', () => {
    const data = buildBinaryDxfLayer('AC1018', 'ANSI_1252', [
      0x41, 0x75, 0xdf, 0x65, 0x6e, 0x77, 0x61, 0x6e, 0x64
    ])
    expect(readFirstNonSectionName(data)).toBe('Außenwand')
  })

  it('still honors an explicit encoding override on binary DXF', () => {
    const data = buildBinaryDxfLayer('AC1018', 'ANSI_1252', [
      0x41, 0x75, 0xdf, 0x65, 0x6e, 0x77, 0x61, 0x6e, 0x64
    ])
    expect(readFirstNonSectionName(data, { encoding: 'utf-8' })).toBe(
      'Au\uFFFDenwand'
    )
    expect(
      readFirstNonSectionName(data, { encoding: 'windows-1252' })
    ).toBe('Außenwand')
  })

  it('keeps UTF-8 for R2007+ binary DXF even if $DWGCODEPAGE is stale', () => {
    const name = new TextEncoder().encode('Außenwand')
    const data = buildBinaryDxfLayer(
      'AC1021',
      'ANSI_1252',
      Array.from(name)
    )
    expect(readFirstNonSectionName(data)).toBe('Außenwand')
  })
})
