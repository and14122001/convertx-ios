import type { AcDbDxfFiler } from '../base/AcDbDxfFiler.js'
import type { AcDbObject } from '../base/AcDbObject.js'
import { AcDbBlockTableRecord } from '../database/AcDbBlockTableRecord.js'
import type { AcDbDatabase } from '../database/AcDbDatabase.js'
import {
  type AcDbLayerFilterPersistSource,
  type AcDbPersistDictionary,
  type AcDbPersistXRecord,
  acdbReadLayerFilterTree
} from '../ly/AcLyLayerFilterIO.js'
import { AcDbBlkRefObjectContextData } from '../object/AcDbBlkRefObjectContextData.js'
import { AcDbDictionary } from '../object/AcDbDictionary.js'
import { AcDbDictionaryVar } from '../object/AcDbDictionaryVar.js'
import { AcDbDimensionObjectContextData } from '../object/AcDbDimensionObjectContextData.js'
import { AcDbGroup } from '../object/AcDbGroup.js'
import { AcDbHatchScaleContextData } from '../object/AcDbHatchScaleContextData.js'
import { AcDbLayerFilter } from '../object/AcDbLayerFilter.js'
import { AcDbLayerIndex } from '../object/AcDbLayerIndex.js'
import { AcDbLeaderObjectContextData } from '../object/AcDbLeaderObjectContextData.js'
import { AcDbMLeaderObjectContextData } from '../object/AcDbMLeaderObjectContextData.js'
import { AcDbMLeaderStyle } from '../object/AcDbMLeaderStyle.js'
import { AcDbMlineStyle } from '../object/AcDbMlineStyle.js'
import { AcDbMTextAttributeObjectContextData } from '../object/AcDbMTextAttributeObjectContextData.js'
import { AcDbMTextObjectContextData } from '../object/AcDbMTextObjectContextData.js'
import { AcDbRasterImageDef } from '../object/AcDbRasterImageDef.js'
import { AcDbScale } from '../object/AcDbScale.js'
import { AcDbSortentsTable } from '../object/AcDbSortentsTable.js'
import { AcDbTextObjectContextData } from '../object/AcDbTextObjectContextData.js'
import { AcDbXrecord } from '../object/AcDbXrecord.js'
import { AcDbLayout } from '../object/layout/AcDbLayout.js'

const normalizeHandle = (handle?: string) =>
  handle ? handle.trim().toUpperCase() : ''

/**
 * Streams the DXF OBJECTS section into {@link AcDbDatabase} dictionaries.
 *
 * Known object types are written immediately. DICTIONARY / XRECORD payloads
 * are also buffered as lightweight persist maps for the Layer Manager filter
 * tree, then discarded after {@link acdbReadLayerFilterTree}.
 */
export class AcDbDxfObjectsReader {
  private readonly _dictionaries: AcDbLayerFilterPersistSource['dictionaries'] =
    new Map()
  private readonly _xrecords: AcDbLayerFilterPersistSource['xrecords'] =
    new Map()
  private _unknownObjectCount = 0

  constructor(private readonly _db: AcDbDatabase) {}

  /** Count of OBJECTS types skipped because no native reader exists yet. */
  get unknownObjectCount() {
    return this._unknownObjectCount
  }

  /**
   * Reads OBJECTS until ENDSEC. Caller must have already consumed the
   * `(0, SECTION)` / `(2, OBJECTS)` header pairs.
   */
  read(filer: AcDbDxfFiler): void {
    this._unknownObjectCount = 0
    while (!filer.atEof) {
      const item = filer.peekItem()
      if (!item) break
      if (Number(item.code) !== 0) {
        filer.readItem()
        continue
      }

      const name = String(item.value).toUpperCase()
      if (name === 'ENDSEC') {
        filer.readItem()
        break
      }

      filer.readItem()
      this.readObject(filer, name)
    }

    this.finishNamedObjectDictionaries()
    this.materializeBufferedDictionaries()
    this.finishCannoscale()
    this.finishAnnoallvisible()
    this.finishLayerFilterTree()
    this.linkLayoutsToBlockTableRecords()
    if (this._db.objects.layout.numEntries === 0) {
      this._db.createDefaultData({ layout: true })
    }
  }

  private readObject(filer: AcDbDxfFiler, typeName: string): void {
    switch (typeName) {
      case 'LAYOUT': {
        const layout = new AcDbLayout()
        layout.dxfIn(filer)
        if (layout.layoutName) {
          this._db.objects.layout.setAt(layout.layoutName, layout)
        }
        break
      }
      case 'IMAGEDEF': {
        const imageDef = new AcDbRasterImageDef()
        imageDef.dxfIn(filer)
        this._db.objects.imageDefinition.setAt(imageDef.objectId, imageDef)
        break
      }
      case 'LAYER_FILTER': {
        const filter = new AcDbLayerFilter()
        filter.dxfIn(filer)
        this._db.objects.layerFilter.setAt(filter.objectId, filter)
        break
      }
      case 'LAYER_INDEX': {
        const index = new AcDbLayerIndex()
        index.dxfIn(filer)
        this._db.objects.layerIndex.setAt(index.objectId, index)
        break
      }
      case 'MLEADERSTYLE': {
        const style = new AcDbMLeaderStyle()
        style.dxfIn(filer)
        this._db.objects.mleaderStyle.setAt(style.objectId, style)
        break
      }
      case 'MLINESTYLE': {
        const style = new AcDbMlineStyle()
        style.dxfIn(filer)
        this._db.objects.mlineStyle.setAt(
          style.styleName || style.objectId,
          style
        )
        break
      }
      case 'GROUP': {
        const group = new AcDbGroup()
        group.dxfIn(filer)
        const key = group.name || group.objectId
        this._db.objects.group.setAt(key, group)
        break
      }
      case 'SORTENTSTABLE': {
        const sortents = new AcDbSortentsTable()
        sortents.dxfIn(filer)
        this._db.objects.sortentsTable.setAt(sortents.objectId, sortents)
        break
      }
      case 'DICTIONARY':
      case 'ACDBDICTIONARYWDFLT': {
        const dict = this.readPersistDictionary(filer)
        if (dict.handle) {
          this._dictionaries.set(normalizeHandle(dict.handle), dict)
        }
        break
      }
      case 'SCALE': {
        const scale = new AcDbScale()
        scale.dxfIn(filer)
        const key = scale.scaleName || normalizeHandle(scale.objectId)
        if (key) {
          this._db.objects.scale.setAt(key, scale)
        }
        break
      }
      case 'DICTIONARYVAR': {
        const dictVar = new AcDbDictionaryVar()
        dictVar.dxfIn(filer)
        const handle = normalizeHandle(dictVar.objectId)
        if (handle) {
          this._db.objects.dictionaryVar.setAt(handle, dictVar)
        }
        break
      }
      case 'ACDB_MTEXTOBJECTCONTEXTDATA_CLASS': {
        const context = new AcDbMTextObjectContextData()
        context.dxfIn(filer)
        const handle = normalizeHandle(context.objectId)
        if (handle) {
          this._db.objects.objectContextData.setAt(handle, context)
        }
        break
      }
      case 'ACDB_TEXTOBJECTCONTEXTDATA_CLASS': {
        const context = new AcDbTextObjectContextData()
        context.dxfIn(filer)
        const handle = normalizeHandle(context.objectId)
        if (handle) {
          this._db.objects.objectContextData.setAt(handle, context)
        }
        break
      }
      case 'ACDB_ALDIMOBJECTCONTEXTDATA_CLASS':
      case 'ACDB_ANGDIMOBJECTCONTEXTDATA_CLASS':
      case 'ACDB_ARCDIMOBJECTCONTEXTDATA_CLASS':
      case 'ACDB_DMDIMOBJECTCONTEXTDATA_CLASS':
      case 'ACDB_ORDDIMOBJECTCONTEXTDATA_CLASS':
      case 'ACDB_RADDIMOBJECTCONTEXTDATA_CLASS':
      case 'ACDB_RADIMOBJECTCONTEXTDATA_CLASS':
      case 'ACDB_RADDIMLGCOBJECTCONTEXTDATA_CLASS': {
        const context = new AcDbDimensionObjectContextData()
        context.dxfIn(filer)
        const handle = normalizeHandle(context.objectId)
        if (handle) {
          this._db.objects.objectContextData.setAt(handle, context)
        }
        break
      }
      case 'ACDB_HATCHSCALECONTEXTDATA_CLASS': {
        const context = new AcDbHatchScaleContextData()
        context.dxfIn(filer)
        const handle = normalizeHandle(context.objectId)
        if (handle) {
          this._db.objects.objectContextData.setAt(handle, context)
        }
        break
      }
      case 'ACDB_BLKREFOBJECTCONTEXTDATA_CLASS': {
        const context = new AcDbBlkRefObjectContextData()
        context.dxfIn(filer)
        const handle = normalizeHandle(context.objectId)
        if (handle) {
          this._db.objects.objectContextData.setAt(handle, context)
        }
        break
      }
      case 'ACDB_LEADEROBJECTCONTEXTDATA_CLASS': {
        const context = new AcDbLeaderObjectContextData()
        context.dxfIn(filer)
        const handle = normalizeHandle(context.objectId)
        if (handle) {
          this._db.objects.objectContextData.setAt(handle, context)
        }
        break
      }
      case 'ACDB_MLEADEROBJECTCONTEXTDATA_CLASS': {
        const context = new AcDbMLeaderObjectContextData()
        context.dxfIn(filer)
        const handle = normalizeHandle(context.objectId)
        if (handle) {
          this._db.objects.objectContextData.setAt(handle, context)
        }
        break
      }
      case 'ACDB_MTEXTATTRIBUTEOBJECTCONTEXTDATA_CLASS': {
        const context = new AcDbMTextAttributeObjectContextData()
        context.dxfIn(filer)
        const handle = normalizeHandle(context.objectId)
        if (handle) {
          this._db.objects.objectContextData.setAt(handle, context)
        }
        break
      }
      case 'XRECORD': {
        const xrecord = new AcDbXrecord()
        xrecord.dxfIn(filer)
        const handle = normalizeHandle(xrecord.objectId)
        if (handle) {
          this._db.objects.xrecord.setAt(handle, xrecord)
          const persist: AcDbPersistXRecord = {
            handle,
            ownerObjectId: normalizeHandle(xrecord.ownerId),
            data: xrecord.data
              ? xrecord.data.toArray().map(item => ({
                  code: Number(item.code),
                  value: item.value
                }))
              : []
          }
          if (xrecord.extensionDictionary) {
            persist.extensionDictionaryId = normalizeHandle(
              xrecord.extensionDictionary
            )
          }
          this._xrecords.set(handle, persist)
        }
        break
      }
      default:
        // Unsupported object type — skip its pairs and record for diagnostics.
        this._unknownObjectCount += 1
        filer.skipToEndOfObject()
        break
    }
  }

  /**
   * Wire the root named-object dictionary and known child dictionaries
   * (ACAD_LAYOUT / ACAD_GROUP / …) from buffered DICTIONARY persist maps.
   */
  private finishNamedObjectDictionaries(): void {
    if (this._dictionaries.size === 0) return

    let root: AcDbPersistDictionary | undefined
    for (const dict of this._dictionaries.values()) {
      if (!dict.ownerObjectId || dict.ownerObjectId === '0') {
        root = dict
        break
      }
    }
    if (!root?.handle) return

    const rootDict = this._db.objects.dictionary
    rootDict.objectId = root.handle
    rootDict.ownerId = '0'

    const typedByKey: Record<string, AcDbDictionary> = {
      ACAD_LAYOUT: this._db.objects.layout,
      ACAD_GROUP: this._db.objects.group,
      ACAD_SORTENTS: this._db.objects.sortentsTable,
      ACAD_MLEADERSTYLE: this._db.objects.mleaderStyle,
      ACAD_MLINESTYLE: this._db.objects.mlineStyle,
      ACAD_SCALELIST: this._db.objects.scale,
      ISM_RASTER_IMAGE_DICT: this._db.objects.imageDefinition,
      MLIGHT_XRECORD: this._db.objects.xrecord
    }

    const objectsByHandle = this.collectLoadedObjectsByHandle()

    for (const [key, childHandle] of Object.entries(root.entries)) {
      const typed = typedByKey[key.toUpperCase()]
      if (!typed) continue

      typed.objectId = childHandle
      typed.ownerId = root.handle
      rootDict.setAt(key, typed)

      const child = this._dictionaries.get(normalizeHandle(childHandle))
      if (!child) continue

      for (const [entryName, entryHandle] of Object.entries(child.entries)) {
        const obj = objectsByHandle.get(normalizeHandle(entryHandle))
        if (!obj) continue
        // Skip when the object is already stored under another key (e.g. LAYOUT
        // was keyed by layoutName while ACAD_LAYOUT entry uses a different
        // spelling/encoding). Re-adding would create duplicate layout tabs.
        // Scan entries() rather than hasId(): this method reassigns typed.objectId
        // from the NOD child handle before merging, so ownerId-based hasId()
        // misses objects that were setAt under the previous dictionary handle.
        const targetId = normalizeHandle(obj.objectId)
        let alreadyStored = false
        for (const [, existing] of typed.entries()) {
          if (normalizeHandle(existing.objectId) === targetId) {
            alreadyStored = true
            break
          }
        }
        if (!typed.getAt(entryName) && !alreadyStored) {
          typed.setAt(entryName, obj)
        }
      }
    }
  }

  private collectLoadedObjectsByHandle(): Map<string, AcDbObject> {
    const map = new Map<string, AcDbObject>()
    const add = (obj: AcDbObject) => {
      const id = normalizeHandle(obj.objectId)
      if (id) map.set(id, obj)
    }
    for (const [, o] of this._db.objects.layout.entries()) add(o)
    for (const [, o] of this._db.objects.group.entries()) add(o)
    for (const [, o] of this._db.objects.sortentsTable.entries()) add(o)
    for (const [, o] of this._db.objects.imageDefinition.entries()) add(o)
    for (const [, o] of this._db.objects.mleaderStyle.entries()) add(o)
    for (const [, o] of this._db.objects.mlineStyle.entries()) add(o)
    for (const [, o] of this._db.objects.layerFilter.entries()) add(o)
    for (const [, o] of this._db.objects.layerIndex.entries()) add(o)
    for (const [, o] of this._db.objects.xrecord.entries()) add(o)
    for (const [, o] of this._db.objects.scale.entries()) add(o)
    for (const [, o] of this._db.objects.dictionaryVar.entries()) add(o)
    for (const [, o] of this._db.objects.objectContextData.entries()) add(o)
    return map
  }

  /**
   * Materializes every buffered DICTIONARY into an {@link AcDbDictionary}
   * registered in the database handle map so entity/viewport extension
   * dictionaries and annotation-scale context chains resolve via
   * {@link AcDbDatabase.getObjectById}.
   */
  private materializeBufferedDictionaries(): void {
    if (this._dictionaries.size === 0) return

    // Typed NOD children may have had objectId reassigned in
    // finishNamedObjectDictionaries without refreshing the handle registry.
    const typedByObjectId = new Map<string, AcDbDictionary>()
    for (const dict of this._db.getRootDictionaries()) {
      const id = normalizeHandle(dict.objectId)
      if (id) {
        typedByObjectId.set(id, dict)
        this._db.registerObjectHandle(dict)
      }
    }

    const materialized = new Map<string, AcDbDictionary>()
    for (const [handle, persist] of this._dictionaries) {
      // Skip dictionaries already represented by typed NOD children
      // (layout/group/scale/…). Those keep their existing AcDbDictionary.
      const existing =
        this._db.getObjectById(handle) ?? typedByObjectId.get(handle)
      if (existing instanceof AcDbDictionary) {
        materialized.set(handle, existing)
        continue
      }

      const dict = new AcDbDictionary(this._db)
      // Replace the constructor-minted handle with the DXF handle.
      this._db.releaseObjectHandle(dict)
      dict.objectId = handle
      dict.ownerId = persist.ownerObjectId || '0'
      if (persist.extensionDictionaryId) {
        dict.extensionDictionary = persist.extensionDictionaryId
      }
      this._db.registerObjectHandle(dict)
      materialized.set(handle, dict)
    }

    const objectsByHandle = this.collectLoadedObjectsByHandle()
    for (const [handle, dict] of materialized) {
      objectsByHandle.set(handle, dict)
    }

    for (const [handle, persist] of this._dictionaries) {
      const dict = materialized.get(handle)
      if (!dict) continue
      for (const [entryName, entryHandle] of Object.entries(persist.entries)) {
        const obj = objectsByHandle.get(normalizeHandle(entryHandle))
        if (!obj) continue
        if (dict.getAt(entryName)) continue
        // Same guard as finishNamedObjectDictionaries: LAYOUT (and similar)
        // may already be keyed by a canonical name while the persist map uses
        // a mojibake/alternate spelling for the same objectId.
        const targetId = normalizeHandle(obj.objectId)
        let alreadyStored = false
        for (const [, existing] of dict.entries()) {
          if (normalizeHandle(existing.objectId) === targetId) {
            alreadyStored = true
            break
          }
        }
        if (alreadyStored) continue
        try {
          dict.setAt(entryName, obj)
        } catch {
          // Strict-mode / ownership conflicts — keep the handle registry entry.
        }
      }
    }

    // Attach non-typed root NOD children (e.g. AcDbVariableDictionary) so
    // callers can resolve them by name from objects.dictionary.
    let rootPersist: AcDbPersistDictionary | undefined
    for (const dict of this._dictionaries.values()) {
      if (!dict.ownerObjectId || dict.ownerObjectId === '0') {
        rootPersist = dict
        break
      }
    }
    if (!rootPersist?.handle) return
    const rootDict = this._db.objects.dictionary
    for (const [key, childHandle] of Object.entries(rootPersist.entries)) {
      if (rootDict.getAt(key)) continue
      const child = objectsByHandle.get(normalizeHandle(childHandle))
      if (child instanceof AcDbDictionary) {
        try {
          rootDict.setAt(key, child)
        } catch {
          // ignore ownership conflicts
        }
      }
    }
  }

  /**
   * Reads CANNOSCALE from AcDbVariableDictionary → DICTIONARYVAR.
   */
  private finishCannoscale(): void {
    const root = this._db.objects.dictionary
    const variableDict = root.getAt('AcDbVariableDictionary')
    if (!(variableDict instanceof AcDbDictionary)) return
    const cannoscaleVar = variableDict.getAt('CANNOSCALE')
    if (cannoscaleVar instanceof AcDbDictionaryVar && cannoscaleVar.value) {
      this._db.cannoscale = cannoscaleVar.value
    }
  }

  /**
   * Reads ANNOALLVISIBLE from AcDbVariableDictionary → DICTIONARYVAR.
   * AutoCAD stores `"0"` / `"1"`; defaults to true when absent.
   */
  private finishAnnoallvisible(): void {
    const root = this._db.objects.dictionary
    const variableDict = root.getAt('AcDbVariableDictionary')
    if (!(variableDict instanceof AcDbDictionary)) return
    const annoVar = variableDict.getAt('ANNOALLVISIBLE')
    if (!(annoVar instanceof AcDbDictionaryVar) || annoVar.value == null) {
      return
    }
    const raw = String(annoVar.value).trim()
    this._db.annoallvisible = raw !== '0' && raw.toLowerCase() !== 'false'
  }

  private readPersistDictionary(filer: AcDbDxfFiler): AcDbPersistDictionary {
    const result: AcDbPersistDictionary = {
      handle: '',
      ownerObjectId: '',
      entries: {}
    }
    let pendingName: string | undefined

    while (!filer.atEndOfObject && !filer.atEof && !filer.atExtendedData) {
      const item = filer.readItem()
      if (!item) break
      const code = Number(item.code)
      switch (code) {
        case 5:
          result.handle = String(item.value)
          break
        case 330:
          result.ownerObjectId = String(item.value)
          break
        case 100:
        case 280:
        case 281:
          break
        case 3:
          pendingName = String(item.value)
          break
        case 350:
        case 340:
        case 360: {
          const target = normalizeHandle(String(item.value))
          if (pendingName) {
            result.entries[pendingName] = target
            pendingName = undefined
          } else if (code === 360 && !result.extensionDictionaryId) {
            // Extension dictionary hard-pointer before entry list.
            result.extensionDictionaryId = target
          }
          break
        }
        default:
          // Tolerate unknown dictionary fields.
          break
      }
    }

    result.handle = normalizeHandle(result.handle)
    result.ownerObjectId = normalizeHandle(result.ownerObjectId)
    if (result.extensionDictionaryId) {
      result.extensionDictionaryId = normalizeHandle(
        result.extensionDictionaryId
      )
    }
    return result
  }

  private finishLayerFilterTree(): void {
    if (this._dictionaries.size === 0 && this._xrecords.size === 0) {
      return
    }
    const tree = acdbReadLayerFilterTree({
      dictionaries: this._dictionaries,
      xrecords: this._xrecords
    })
    if (tree.root.getNestedFilters().length > 0) {
      this._db.layerFilters = tree
    }
    this._dictionaries.clear()
    this._xrecords.clear()
  }

  /**
   * Cross-links LAYOUT objects with BLOCK_RECORD layoutId / blockTableRecordId,
   * matching {@link AcDbObjectConverter.convertLayout} resolution rules.
   */
  private linkLayoutsToBlockTableRecords(): void {
    const blockTable = this._db.tables.blockTable
    const modelSpaceName = AcDbBlockTableRecord.MODEL_SPACE_NAME.toUpperCase()

    for (const [, layout] of this._db.objects.layout.entries()) {
      if (layout.layoutName === 'Model') {
        const modelSpace = blockTable.modelSpace
        layout.blockTableRecordId = modelSpace.objectId
        modelSpace.layoutId = layout.objectId
        continue
      }

      const layoutHandle = normalizeHandle(layout.objectId)
      let linked = false
      for (const btr of blockTable.newIterator()) {
        if (normalizeHandle(btr.layoutId) === layoutHandle) {
          layout.blockTableRecordId = btr.objectId
          linked = true
          break
        }
      }

      if (!linked && layout.blockTableRecordId) {
        const btr = blockTable.getIdAt(layout.blockTableRecordId)
        if (btr) {
          btr.layoutId = layout.objectId
        }
      } else if (!linked) {
        // Fallback: paper-space BTR whose name is not model space and has no layout yet.
        for (const btr of blockTable.newIterator()) {
          if (
            btr.isPaperSapce &&
            btr.name.toUpperCase() !== modelSpaceName &&
            !btr.layoutId
          ) {
            layout.blockTableRecordId = btr.objectId
            btr.layoutId = layout.objectId
            break
          }
        }
      }
    }
  }
}
