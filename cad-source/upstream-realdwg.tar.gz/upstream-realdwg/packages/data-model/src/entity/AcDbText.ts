import {
  AcGeBox3d,
  AcGeMathUtil,
  AcGeMatrix3d,
  AcGePoint3d,
  AcGePoint3dLike,
  acgeTransformOcsPointToWcs,
  acgeTransformWcsPointToOcs,
  AcGeVector3d,
  AcGeVector3dLike
} from '@mlightcad/geometry-engine'
import {
  AcGiEntity,
  AcGiMTextAttachmentPoint,
  AcGiMTextData,
  AcGiMTextFlowDirection,
  AcGiRenderer,
  AcGiTextStyle
} from '@mlightcad/graphic-interface'

import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js'
import {
  type AcDbAnnotationScaleContext,
  type AcDbAnnotationScaleDrawInfo,
  acdbAnnotativeModelHeight,
  acdbAnnotativePaperHeight,
  acdbBuildAnnotationScaleDrawInfo,
  acdbGetAnnotationScaleContexts,
  acdbGetAnnotative,
  acdbIsAnnotativeObject,
  acdbMatchAnnotationScaleContext,
  acdbSetAnnotative
} from '../misc/AcDbAnnotationScale.js'
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode.js'
import { AcDbTextObjectContextData } from '../object/AcDbTextObjectContextData.js'
import { AcDbEntity } from './AcDbEntity.js'
import { AcDbEntityProperties } from './AcDbEntityProperties.js'
import { acdbMovePrimaryGripPointAt } from './AcDbGripHelpers.js'
import {
  acdbEstimatePlainTextWidth,
  acdbExpandBoxByOrientedTextRect
} from './AcDbTextExtentsHelpers.js'

/**
 * Defines the horizontal alignment mode for text entities.
 */
export enum AcDbTextHorizontalMode {
  /** Left-aligned text */
  LEFT = 0,
  /** Center-aligned text */
  CENTER = 1,
  /** Right-aligned text */
  RIGHT = 2,
  /** Aligned text (fits between two points) */
  ALIGNED = 3,
  /** Middle-aligned text */
  MIDDLE = 4,
  /** Fit text (scales to fit between two points) */
  FIT = 5
}

/**
 * Defines the vertical alignment mode for text entities.
 */
export enum AcDbTextVerticalMode {
  /** Baseline-aligned text */
  BASELINE = 0,
  /** Bottom-aligned text */
  BOTTOM = 1,
  /** Middle-aligned text */
  MIDDLE = 2,
  /** Top-aligned text */
  TOP = 3
}

/**
 * Represents a text entity in AutoCAD.
 *
 * A text entity is a 2D geometric object that displays text strings in drawings.
 * Text entities can have various properties including position, height, rotation,
 * alignment, and style. Text is always drawn in the plane defined by its normal vector.
 *
 * @example
 * ```typescript
 * // Create a text entity
 * const text = new AcDbText();
 * text.textString = "Hello, World!";
 * text.position = new AcGePoint3d(0, 0, 0);
 * text.height = 2.5;
 * text.horizontalMode = AcDbTextHorizontalMode.CENTER;
 * text.verticalMode = AcDbTextVerticalMode.BASELINE;
 *
 * // Access text properties
 * console.log(`Text: ${text.textString}`);
 * console.log(`Position: ${text.position}`);
 * console.log(`Height: ${text.height}`);
 * ```
 */
export class AcDbText extends AcDbEntity {
  /** The entity type name */
  static override typeName: string = 'Text'

  override get dxfTypeName() {
    return 'TEXT'
  }

  /** The text string content */
  private _textString: string
  /** The thickness (extrusion) of the text */
  private _thickness: number
  /** The height of the text */
  private _height: number
  /** The insertion point of the text (DXF group 10). */
  private _position: AcGePoint3d
  /**
   * The alignment point of the text (DXF group 11).
   *
   * Used when {@link horizontalMode} is not LEFT or {@link verticalMode} is
   * not BASELINE. Mirrors `AcDbText::alignmentPoint` in ObjectARX.
   */
  private _alignmentPoint: AcGePoint3d
  /**
   * Whether the alignment point was explicitly provided by the source file
   * (DXF group 11 / DWG) or set through the API.
   *
   * Parse paths mirror {@link _position} into {@link _alignmentPoint} when
   * group 11 is absent, so coordinate equality cannot tell "unset" apart
   * from a spec-compliant file whose group 11 happens to equal group 10
   * (e.g. everything written by ezdxf's `Text.set_placement`). This flag is
   * the source of truth used by {@link resolveTextAnchor}.
   */
  private _hasAlignmentPoint = false
  /** The rotation angle of the text */
  private _rotation: number
  /** The oblique angle of the text */
  private _oblique: number
  /** The horizontal alignment mode */
  private _horizontalMode: AcDbTextHorizontalMode
  /** The vertical alignment mode */
  private _verticalModel: AcDbTextVerticalMode
  /** The text style name */
  private _styleName: string
  /** The width factor (scale) of the text */
  private _widthFactor: number
  /**
   * Text generation flags (DXF group 71).
   * Bit 2 = backward (mirrored in X); bit 4 = upside down (mirrored in Y).
   */
  private _generationFlag = 0
  /** Extrusion / plane normal (DXF group 210). */
  private _normal = new AcGeVector3d(0, 0, 1)

  /**
   * Creates a new text entity.
   *
   * This constructor initializes a text entity with default values.
   * The text string is empty, height is 0, and position is at the origin.
   *
   * @example
   * ```typescript
   * const text = new AcDbText();
   * text.textString = "Sample Text";
   * text.position = new AcGePoint3d(10, 20, 0);
   * text.height = 3.0;
   * ```
   */
  constructor() {
    super()
    this._textString = ''
    this._height = 0
    // DXF default thickness is 0 (group 39 is optional).
    this._thickness = 0
    this._position = new AcGePoint3d()
    this._alignmentPoint = new AcGePoint3d()
    this._rotation = 0
    this._oblique = 0
    this._horizontalMode = AcDbTextHorizontalMode.LEFT
    // Baseline + Left is the DXF default; Middle with an unset alignment
    // point at the origin made other readers place every TEXT at (0,0).
    this._verticalModel = AcDbTextVerticalMode.BASELINE
    this._styleName = ''
    this._widthFactor = 1
  }

  /**
   * Gets the text string content of this entity.
   *
   * @returns The text string
   *
   * @example
   * ```typescript
   * const content = text.textString;
   * console.log(`Text content: ${content}`);
   * ```
   */
  get textString() {
    return this._textString
  }

  /**
   * Sets the text string content of this entity.
   *
   * @param value - The new text string
   *
   * @example
   * ```typescript
   * text.textString = "New text content";
   * ```
   */
  set textString(value: string) {
    this._textString = value
  }

  /**
   * Gets the thickness of the text.
   *
   * The thickness is the text's dimension along its normal vector direction
   * (sometimes called the extrusion direction).
   *
   * @returns The thickness value
   *
   * @example
   * ```typescript
   * const thickness = text.thickness;
   * console.log(`Text thickness: ${thickness}`);
   * ```
   */
  get thickness() {
    return this._thickness
  }

  /**
   * Sets the thickness of the text.
   *
   * @param value - The new thickness value
   *
   * @example
   * ```typescript
   * text.thickness = 2.0;
   * ```
   */
  set thickness(value: number) {
    this._thickness = value
  }

  /**
   * Gets the height of the text.
   *
   * The height value is used as a scale factor for both height and width
   * of the text.
   *
   * @returns The height value
   *
   * @example
   * ```typescript
   * const height = text.height;
   * console.log(`Text height: ${height}`);
   * ```
   */
  get height() {
    return this._height
  }

  /**
   * Whether this TEXT is annotative (AcadAnnotative XDATA and/or scale contexts).
   */
  get annotative() {
    return acdbGetAnnotative(this)
  }
  set annotative(value: boolean) {
    acdbSetAnnotative(this, value)
  }

  /**
   * Sets the height of the text.
   *
   * @param value - The new height value
   *
   * @example
   * ```typescript
   * text.height = 5.0;
   * ```
   */
  set height(value: number) {
    this._height = value
  }

  /**
   * Gets the insertion point of the text in WCS coordinates.
   *
   * @returns The insertion point as a 3D point
   *
   * @example
   * ```typescript
   * const position = text.position;
   * console.log(`Text position: ${position.x}, ${position.y}, ${position.z}`);
   * ```
   */
  get position() {
    return this._position
  }

  /**
   * Sets the insertion point of the text in WCS coordinates.
   *
   * @param value - The new insertion point
   *
   * @example
   * ```typescript
   * text.position = new AcGePoint3d(15, 25, 0);
   * ```
   */
  set position(value: AcGePoint3d) {
    this._position.copy(value)
  }

  /**
   * Gets the alignment point of the text in WCS coordinates.
   *
   * The alignment point is the placement anchor used when
   * {@link horizontalMode} is not {@link AcDbTextHorizontalMode.LEFT} or
   * {@link verticalMode} is not {@link AcDbTextVerticalMode.BASELINE}. For
   * a Middle/Center text, for example, this is the centroid of the text's
   * bounding box. Mirrors `AcDbText::alignmentPoint` in ObjectARX and maps
   * to DXF group code 11.
   *
   * When the horizontal/vertical modes are at their defaults, the alignment
   * point is unused and typically equals {@link position}.
   *
   * @returns The alignment point as a 3D point
   */
  get alignmentPoint() {
    return this._alignmentPoint
  }

  /**
   * Sets the alignment point of the text in WCS coordinates.
   *
   * Setting an alignment point through the API marks it as explicitly
   * provided (see {@link hasAlignmentPoint}).
   *
   * @param value - The new alignment point
   */
  set alignmentPoint(value: AcGePoint3d) {
    this._alignmentPoint.copy(value)
    this._hasAlignmentPoint = true
  }

  /**
   * Whether the alignment point was explicitly provided by the source file
   * or through the API, as opposed to mirrored from {@link position} by a
   * parse-time fallback when group 11 is absent.
   */
  get hasAlignmentPoint() {
    return this._hasAlignmentPoint
  }

  /**
   * Marks whether the alignment point is explicitly provided. Parse paths
   * (DXF/DWG converters) set this after assigning {@link alignmentPoint}.
   */
  set hasAlignmentPoint(value: boolean) {
    this._hasAlignmentPoint = value
  }

  /**
   * Gets the rotation angle of the text.
   *
   * The rotation angle is relative to the X axis of the text's OCS,
   * with positive angles going counterclockwise when looking down the Z axis
   * toward the origin.
   *
   * @returns The rotation angle in radians
   *
   * @example
   * ```typescript
   * const rotation = text.rotation;
   * console.log(`Text rotation: ${rotation} radians (${rotation * 180 / Math.PI} degrees)`);
   * ```
   */
  get rotation() {
    return this._rotation
  }

  /**
   * Sets the rotation angle of the text.
   *
   * @param value - The new rotation angle in radians
   *
   * @example
   * ```typescript
   * text.rotation = Math.PI / 4; // 45 degrees
   * ```
   */
  set rotation(value: number) {
    this._rotation = value
  }

  /**
   * Gets the oblique angle of the text.
   *
   * The oblique angle is the angle from the text's vertical; that is, the top
   * of the text "slants" relative to the bottom, similar to italic text.
   * Positive angles slant characters forward at their tops.
   *
   * @returns The oblique angle in radians
   *
   * @example
   * ```typescript
   * const oblique = text.oblique;
   * console.log(`Text oblique angle: ${oblique} radians`);
   * ```
   */
  get oblique() {
    return this._oblique
  }

  /**
   * Sets the oblique angle of the text.
   *
   * @param value - The new oblique angle in radians
   *
   * @example
   * ```typescript
   * text.oblique = Math.PI / 6; // 30 degrees
   * ```
   */
  set oblique(value: number) {
    this._oblique = value
  }

  /**
   * Gets the horizontal alignment mode of the text.
   *
   * @returns The horizontal alignment mode
   *
   * @example
   * ```typescript
   * const horizontalMode = text.horizontalMode;
   * console.log(`Horizontal mode: ${horizontalMode}`);
   * ```
   */
  get horizontalMode() {
    return this._horizontalMode
  }

  /**
   * Sets the horizontal alignment mode of the text.
   *
   * @param value - The new horizontal alignment mode
   *
   * @example
   * ```typescript
   * text.horizontalMode = AcDbTextHorizontalMode.CENTER;
   * ```
   */
  set horizontalMode(value: AcDbTextHorizontalMode) {
    this._horizontalMode = value
  }

  /**
   * Gets the vertical alignment mode of the text.
   *
   * @returns The vertical alignment mode
   *
   * @example
   * ```typescript
   * const verticalMode = text.verticalMode;
   * console.log(`Vertical mode: ${verticalMode}`);
   * ```
   */
  get verticalMode() {
    return this._verticalModel
  }

  /**
   * Sets the vertical alignment mode of the text.
   *
   * @param value - The new vertical alignment mode
   *
   * @example
   * ```typescript
   * text.verticalMode = AcDbTextVerticalMode.BASELINE;
   * ```
   */
  set verticalMode(value: AcDbTextVerticalMode) {
    this._verticalModel = value
  }

  /**
   * Gets the style name used by this text entity.
   *
   * @returns The text style name
   *
   * @example
   * ```typescript
   * const styleName = text.styleName;
   * console.log(`Text style: ${styleName}`);
   * ```
   */
  get styleName() {
    return this._styleName
  }

  /**
   * Sets the style name for this text entity.
   *
   * @param value - The new text style name
   *
   * @example
   * ```typescript
   * text.styleName = DEFAULT_TEXT_STYLE;
   * ```
   */
  set styleName(value: string) {
    this._styleName = value
  }

  /**
   * Gets the width factor of the text.
   *
   * The width factor is applied to the text's width to allow the width to be
   * adjusted independently of the height. For example, if the widthFactor value
   * is 0.8, then the text is drawn with a width that is 80% of its normal width.
   *
   * @returns The width factor value
   *
   * @example
   * ```typescript
   * const widthFactor = text.widthFactor;
   * console.log(`Width factor: ${widthFactor}`);
   * ```
   */
  get widthFactor() {
    return this._widthFactor
  }

  /**
   * Sets the width factor of the text.
   *
   * @param value - The new width factor value
   *
   * @example
   * ```typescript
   * text.widthFactor = 0.8; // 80% width
   * ```
   */
  set widthFactor(value: number) {
    this._widthFactor = value
  }

  /**
   * Text generation flags (DXF group 71).
   * Bit 2 = backward; bit 4 = upside down.
   */
  get generationFlag() {
    return this._generationFlag
  }
  set generationFlag(value: number) {
    this._generationFlag = value
  }

  /** True when the text is mirrored in X (generation flag bit 2). */
  get isBackward() {
    return (this._generationFlag & 2) !== 0
  }
  set isBackward(value: boolean) {
    this._generationFlag = value
      ? this._generationFlag | 2
      : this._generationFlag & ~2
  }

  /** True when the text is mirrored in Y (generation flag bit 4). */
  get isUpsideDown() {
    return (this._generationFlag & 4) !== 0
  }
  set isUpsideDown(value: boolean) {
    this._generationFlag = value
      ? this._generationFlag | 4
      : this._generationFlag & ~4
  }

  /** Extrusion / plane normal (DXF group 210). */
  get normal(): AcGeVector3d {
    return this._normal
  }
  set normal(value: AcGeVector3dLike) {
    this._normal.copy(value)
  }

  /**
   * Gets the geometric extents (bounding box) of this text.
   *
   * @returns The bounding box that encompasses the text
   *
   * @example
   * ```typescript
   * const extents = text.geometricExtents;
   * console.log(`Text bounds: ${extents.minPoint} to ${extents.maxPoint}`);
   * ```
   */
  get geometricExtents(): AcGeBox3d {
    const box = new AcGeBox3d()
    const { anchor, attachmentPoint } = this.resolveTextAnchor()
    const draw = this.extrusionDrawingAdjust()
    const width = acdbEstimatePlainTextWidth(
      this.textString,
      this.height,
      Math.abs(draw.widthFactor)
    )
    return acdbExpandBoxByOrientedTextRect(
      box,
      anchor,
      width,
      this.height,
      attachmentPoint,
      draw.rotation
    )
  }

  /**
   * Gets the grip points for this text entity.
   *
   * Uses the same WCS anchor as drawing / extents ({@link resolveTextAnchor}):
   * group 10 for LEFT+BASELINE, otherwise group 11 (`alignmentPoint`) when set.
   * Returning only group 10 made Middle/Center TEXT show the grip inside the
   * glyph run (near the DXF second point) instead of at the visible attachment.
   *
   * @returns Array containing the text placement anchor.
   */
  subGetGripPoints() {
    return [this.resolveTextAnchor().anchor]
  }

  /** @inheritdoc */
  subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike) {
    // Grips are exposed in WCS; storage is OCS — convert the drag delta.
    const ocsOffset = acgeTransformWcsPointToOcs(offset, this._normal)
    acdbMovePrimaryGripPointAt(indices, ocsOffset, this._position)
    // Non-default alignments render from group 11 (`alignmentPoint`), so a grip
    // drag must translate both anchors together (preserves their OCS offset).
    this._alignmentPoint.add(ocsOffset)
    return this
  }

  /**
   * Gets the object snap points for this text.
   *
   * Object snap points are precise points that can be used for positioning
   * when drawing or editing. This method provides snap points based on the
   * specified snap mode.
   *
   * @param osnapMode - The object snap mode
   * @param _pickPoint - The point where the user picked
   * @param _lastPoint - The last point
   * @param snapPoints - Array to populate with snap points
   */
  subGetOsnapPoints(
    osnapMode: AcDbOsnapMode,
    _pickPoint: AcGePoint3dLike,
    _lastPoint: AcGePoint3dLike,
    snapPoints: AcGePoint3dLike[]
  ) {
    if (AcDbOsnapMode.Insertion === osnapMode) {
      // Match drawing / grips: INS is the effective placement anchor.
      snapPoints.push(this.resolveTextAnchor().anchor)
    }
  }

  /**
   * Transforms this text by the specified matrix.
   */
  transformBy(matrix: AcGeMatrix3d) {
    const origin = this._position.clone()
    const xAxisPoint = this._position
      .clone()
      .add(
        new AcGeVector3d(Math.cos(this._rotation), Math.sin(this._rotation), 0)
      )
    const yAxisPoint = this._position
      .clone()
      .add(
        new AcGeVector3d(-Math.sin(this._rotation), Math.cos(this._rotation), 0)
      )
    const zAxisPoint = this._position.clone().add(new AcGeVector3d(0, 0, 1))

    origin.applyMatrix4(matrix)
    xAxisPoint.applyMatrix4(matrix)
    yAxisPoint.applyMatrix4(matrix)
    zAxisPoint.applyMatrix4(matrix)

    const xAxis = new AcGeVector3d(xAxisPoint).sub(origin)
    const yAxis = new AcGeVector3d(yAxisPoint).sub(origin)
    const zAxis = new AcGeVector3d(zAxisPoint).sub(origin)
    const yScale = yAxis.length()
    const xScale = xAxis.length()
    const zScale = zAxis.length()

    this._position.copy(origin)
    if (xScale > 0) {
      this._rotation = Math.atan2(xAxis.y, xAxis.x)
    }
    if (yScale > 0) {
      this._height *= yScale
      if (xScale > 0) {
        this._widthFactor *= xScale / yScale
      }
    }
    if (zScale > 0) {
      this._thickness *= zScale
    }
    const alignmentPoint = this._alignmentPoint.clone()
    alignmentPoint.applyMatrix4(matrix)
    this._alignmentPoint.copy(alignmentPoint)
    return this
  }

  /**
   * Returns the full property definition for this text entity, including
   * general group and geometry group.
   *
   * The geometry group exposes editable start/end coordinates via
   * {@link AcDbPropertyAccessor} so the property palette can update
   * the text in real-time.
   *
   * Each property is an {@link AcDbEntityRuntimeProperty}.
   */
  get properties(): AcDbEntityProperties {
    return {
      type: this.type,
      groups: [
        this.getGeneralProperties(),
        {
          groupName: 'text',
          properties: [
            {
              name: 'contents',
              type: 'string',
              editable: true,
              accessor: {
                get: () => this.textString,
                set: (v: string) => {
                  this.textString = v
                }
              }
            },
            {
              name: 'annotative',
              type: 'boolean',
              editable: true,
              accessor: {
                get: () => this.annotative,
                set: (v: boolean) => {
                  this.annotative = v
                }
              }
            },
            {
              name: 'styleName',
              type: 'string',
              editable: true,
              accessor: {
                get: () => this.styleName,
                set: (v: string) => {
                  this.styleName = v
                }
              }
            },
            {
              name: 'textHeight',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.height,
                set: (v: number) => {
                  this.height = v
                }
              }
            },
            {
              name: 'rotation',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.rotation,
                set: (v: number) => {
                  this.rotation = v
                }
              }
            },
            {
              name: 'widthFactor',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.widthFactor,
                set: (v: number) => {
                  this.widthFactor = v
                }
              }
            },
            {
              name: 'oblique',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.oblique,
                set: (v: number) => {
                  this.oblique = v
                }
              }
            }
          ]
        },
        {
          groupName: 'geometry',
          properties: [
            {
              name: 'positionX',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.position.x,
                set: (v: number) => {
                  this.position.x = v
                }
              }
            },
            {
              name: 'positionY',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.position.y,
                set: (v: number) => {
                  this.position.y = v
                }
              }
            },
            {
              name: 'positionZ',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.position.z,
                set: (v: number) => {
                  this.position.z = v
                }
              }
            }
          ]
        }
      ]
    }
  }

  /**
   * Gets the text style for this text entity.
   *
   * This method retrieves the text style from the text style table.
   * If the specified style is not found, it falls back to the 'STANDARD' style.
   *
   * @returns The text style object
   *
   * @example
   * ```typescript
   * const textStyle = text.getTextStyle();
   * ```
   */
  protected getTextStyle(): AcGiTextStyle {
    const style = this.database.tables.textStyleTable.resolveAt(this.styleName)
    if (!style) {
      throw new Error('No valid text style found in text style table.')
    }
    return style.textStyle
  }

  /**
   * Draws this text using the specified renderer.
   *
   * This method renders the text as a multiline text entity using the text's
   * current style properties.
   *
   * @param renderer - The renderer to use for drawing
   * @param delay - The flag to delay creating one rendered entity and just create one dummy
   * entity. Renderer can delay heavy calculation operation to avoid blocking UI when this flag
   * is true.
   * @returns The rendered text entity, or undefined if drawing failed
   */
  /**
   * Resolves height / anchor / rotation for the active CANNOSCALE when this
   * TEXT is annotative.
   */
  resolveAnnotativePresentation(): {
    height: number
    position: AcGePoint3d
    attachmentPoint: AcGiMTextAttachmentPoint
    rotation: number
    preferred?: AcDbAnnotationScaleContext
    annotationScale?: AcDbAnnotationScaleDrawInfo
  } {
    const { anchor, attachmentPoint } = this.resolveTextAnchor()
    const draw = this.extrusionDrawingAdjust()
    const contexts = acdbGetAnnotationScaleContexts(this)
    const isAnnotative =
      contexts.length > 0 || acdbIsAnnotativeObject(this)

    let height = this.height
    let position = anchor
    let rotation = draw.rotation
    let preferred: AcDbAnnotationScaleContext | undefined
    let annotationScale: AcDbAnnotationScaleDrawInfo | undefined

    if (isAnnotative && contexts.length > 0) {
      const paperHeight = acdbAnnotativePaperHeight(this.height, contexts)
      preferred =
        acdbMatchAnnotationScaleContext(
          contexts,
          this.database?.cannoscale
        ) ??
        contexts.find(c => c.isDefault) ??
        contexts[0]
      height = acdbAnnotativeModelHeight(
        paperHeight,
        preferred.scale.scaleFactor
      )
      const ctx = preferred.contextData
      if (ctx instanceof AcDbTextObjectContextData) {
        const useAlignment =
          ctx.horizontalMode !== AcDbTextHorizontalMode.LEFT ||
          ctx.alignmentPoint.x !== 0 ||
          ctx.alignmentPoint.y !== 0 ||
          ctx.alignmentPoint.z !== 0
        const ctxAnchor = useAlignment ? ctx.alignmentPoint : ctx.position
        position = this.pointToWcs(ctxAnchor)
        rotation = ctx.rotation
      }
      annotationScale = acdbBuildAnnotationScaleDrawInfo(contexts, preferred)
    }

    return {
      height,
      position,
      attachmentPoint,
      rotation,
      preferred,
      annotationScale
    }
  }

  subWorldDraw(
    renderer: AcGiRenderer,
    delay?: boolean
  ): AcGiEntity | undefined {
    // For non-default alignments the DXF stores the placement anchor in
    // group 11 (`alignmentPoint`) — `position` (group 10) is only the
    // left-baseline insertion point and is misleading for CENTER/RIGHT
    // or MIDDLE/TOP/BOTTOM modes. Pick the right reference + the matching
    // attachment point so the renderer can compute the offset itself
    // from the real bbox of the laid-out glyphs.
    const {
      height,
      position,
      attachmentPoint,
      rotation,
      annotationScale
    } = this.resolveAnnotativePresentation()
    const draw = this.extrusionDrawingAdjust()
    const mtextData: AcGiMTextData = {
      text: this.textString,
      height,
      width: Infinity,
      widthFactor: draw.widthFactor,
      position,
      // Please use 'rotation' and do not set value of 'directionVector' because it will overrides
      // rotation value.
      rotation,
      // MText draw text from top to bottom.
      drawingDirection: AcGiMTextFlowDirection.BOTTOM_TO_TOP,
      attachmentPoint
    }
    const drawable = renderer.mtext(mtextData, this.getTextStyle(), delay)
    if (drawable && annotationScale) {
      const userData = drawable.userData as {
        annotationScale?: AcDbAnnotationScaleDrawInfo
      }
      userData.annotationScale = annotationScale
    }
    return drawable
  }

  /**
   * Maps an OCS text point into WCS using {@link normal}.
   */
  private pointToWcs(point: AcGePoint3dLike): AcGePoint3d {
    return acgeTransformOcsPointToWcs(point, this._normal)
  }

  /**
   * Plan-view drawing adjustments for entity extrusion.
   *
   * For extrusion (0,0,-1) the flat WCS equivalent is an XY mirror: negate
   * rotation and width factor (see issue #226). Other extrusions map the OCS
   * X axis into WCS for rotation only.
   */
  private extrusionDrawingAdjust(): {
    rotation: number
    widthFactor: number
  } {
    if (
      this._normal.x === 0 &&
      this._normal.y === 0 &&
      this._normal.z === 1
    ) {
      return { rotation: this._rotation, widthFactor: this._widthFactor }
    }
    if (
      this._normal.x === 0 &&
      this._normal.y === 0 &&
      this._normal.z < 0
    ) {
      return {
        rotation: -this._rotation,
        widthFactor: -this._widthFactor
      }
    }
    const axis = new AcGeVector3d(
      Math.cos(this._rotation),
      Math.sin(this._rotation),
      0
    )
    axis.transformDirection(
      new AcGeMatrix3d().setFromExtrusionDirection(this._normal)
    )
    return {
      rotation: Math.atan2(axis.y, axis.x),
      widthFactor: this._widthFactor
    }
  }

  /**
   * Resolves the anchor point and attachment used for rendering and extents.
   *
   * For default LEFT + BASELINE, `position` (group 10) is the anchor.
   * For other alignments, `alignmentPoint` (group 11) is used when set.
   * When group 11 is missing, falls back to LEFT/BASELINE at `position`.
   */
  private resolveTextAnchor(): {
    anchor: AcGePoint3d
    attachmentPoint: AcGiMTextAttachmentPoint
  } {
    const attachmentPoint = this.resolveAttachmentPoint()

    if (attachmentPoint === AcGiMTextAttachmentPoint.BaselineLeft) {
      return { anchor: this.pointToWcs(this._position), attachmentPoint }
    }

    const ap = this._alignmentPoint
    // "Unset" is decided by the explicit-presence flag, not by coordinate
    // equality: spec-compliant writers (ezdxf `set_placement`, AutoCAD) emit
    // group 11 equal to group 10 when the insertion point coincides with the
    // alignment point. The all-zero check stays as a guard for files that
    // carry a degenerate zero group 11.
    const apIsUnset =
      !this._hasAlignmentPoint ||
      (ap.x === 0 && ap.y === 0 && ap.z === 0)
    if (apIsUnset) {
      return {
        anchor: this.pointToWcs(this._position),
        attachmentPoint: AcGiMTextAttachmentPoint.BaselineLeft
      }
    }

    return { anchor: this.pointToWcs(ap), attachmentPoint }
  }

  /**
   * Maps the (horizontal, vertical) DXF alignment modes of this TEXT/ATTRIB
   * to the matching {@link AcGiMTextAttachmentPoint}.
   *
   * The DXF spec uses two orthogonal axes (group 72 + group 73), with the
   * special-case `halign=MIDDLE (4)` collapsing both to a single centroid
   * placement. The renderer accepts the standard 3×3 + Baseline matrix
   * (TopLeft … BaselineRight). This function translates between the two.
   *
   * For default LEFT + BASELINE we return `BaselineLeft` and the caller
   * uses `position` (group 10) as the anchor. For every other case we
   * return the matching attachment and the caller passes
   * `alignmentPoint` (group 11) — the DXF placement anchor — to the
   * renderer.
   */
  private resolveAttachmentPoint(): AcGiMTextAttachmentPoint {
    const h = this._horizontalMode
    const v = this._verticalModel

    // halign=MIDDLE (4) is a special "centroid" mode that overrides
    // valign — the placement anchor is the bbox center regardless of
    // what valign claims.
    if (h === AcDbTextHorizontalMode.MIDDLE) {
      return AcGiMTextAttachmentPoint.MiddleCenter
    }

    // halign=ALIGNED (3) and halign=FIT (5) are two-point text — the
    // libredwg/dxf converter has already pre-computed `position` so it
    // sits at the left baseline of a string whose `widthFactor` was
    // scaled to fit between the two points. The renderer's default
    // BaselineLeft anchor is the right choice.
    if (
      h === AcDbTextHorizontalMode.ALIGNED ||
      h === AcDbTextHorizontalMode.FIT
    ) {
      return AcGiMTextAttachmentPoint.BaselineLeft
    }

    // Standard 3×3 mapping. Note BASELINE (0) maps to Baseline*, BOTTOM
    // (1) maps to Bottom* — different semantics in the DXF spec, even if
    // the visual difference is just the descender height.
    switch (v) {
      case AcDbTextVerticalMode.TOP:
        if (h === AcDbTextHorizontalMode.CENTER)
          return AcGiMTextAttachmentPoint.TopCenter
        if (h === AcDbTextHorizontalMode.RIGHT)
          return AcGiMTextAttachmentPoint.TopRight
        return AcGiMTextAttachmentPoint.TopLeft
      case AcDbTextVerticalMode.MIDDLE:
        if (h === AcDbTextHorizontalMode.CENTER)
          return AcGiMTextAttachmentPoint.MiddleCenter
        if (h === AcDbTextHorizontalMode.RIGHT)
          return AcGiMTextAttachmentPoint.MiddleRight
        return AcGiMTextAttachmentPoint.MiddleLeft
      case AcDbTextVerticalMode.BOTTOM:
        if (h === AcDbTextHorizontalMode.CENTER)
          return AcGiMTextAttachmentPoint.BottomCenter
        if (h === AcDbTextHorizontalMode.RIGHT)
          return AcGiMTextAttachmentPoint.BottomRight
        return AcGiMTextAttachmentPoint.BottomLeft
      case AcDbTextVerticalMode.BASELINE:
      default:
        if (h === AcDbTextHorizontalMode.CENTER)
          return AcGiMTextAttachmentPoint.BaselineCenter
        if (h === AcDbTextHorizontalMode.RIGHT)
          return AcGiMTextAttachmentPoint.BaselineRight
        return AcGiMTextAttachmentPoint.BaselineLeft
    }
  }

  /**
   * Writes DXF fields for this object.
   *
   * @param filer - DXF output writer.
   * @returns The instance (for chaining).
   */
  override dxfOutFields(filer: AcDbDxfFiler) {
    super.dxfOutFields(filer)
    filer.writeSubclassMarker('AcDbText')
    if (this.thickness !== 0) {
      filer.writeDouble(39, this.thickness)
    }
    filer.writePoint3d(10, this.position)
    filer.writeDouble(40, this.height)
    filer.writeString(1, this.textString)
    filer.writeAngle(50, this.rotation)
    filer.writeDouble(41, this.widthFactor)
    filer.writeAngle(51, this.oblique)
    filer.writeString(7, this.styleName || 'Standard')
    if (this.generationFlag !== 0) {
      filer.writeInt16(71, this.generationFlag)
    }
    filer.writeInt16(72, this.horizontalMode)
    // Group 11 is meaningful when horizontal/vertical modes are non-default.
    // If the alignment point was never set, reuse the insertion point so
    // readers that honor group 11 do not drop the text at the origin.
    const needsAlignment =
      this.horizontalMode !== AcDbTextHorizontalMode.LEFT ||
      this.verticalMode !== AcDbTextVerticalMode.BASELINE
    const alignment = this.hasAlignmentPoint
      ? this.alignmentPoint
      : needsAlignment
        ? this.position
        : this.alignmentPoint
    filer.writePoint3d(11, alignment)
    filer.writeVector3d(210, this.normal)
    // DXF TEXT requires a second AcDbText subclass marker immediately before
    // vertical justification (group 73).
    filer.writeSubclassMarker('AcDbText')
    filer.writeInt16(73, this.verticalMode)
    return this
  }

  override dxfInFields(filer: AcDbDxfFiler): this {
    super.dxfInFields(filer)
    filer.atSubclassData('AcDbText')

    let px = this.position.x
    let py = this.position.y
    let pz = this.position.z
    let ax = this.alignmentPoint.x
    let ay = this.alignmentPoint.y
    let az = this.alignmentPoint.z
    let hasAlignment = false
    let nx = this.normal.x
    let ny = this.normal.y
    let nz = this.normal.z

    while (!filer.atEndOfObject && !filer.atEof && !filer.atExtendedData) {
      const item = filer.readItem()
      if (!item) break
      const code = Number(item.code)
      const n = Number(item.value)
      switch (code) {
        case 10:
          px = n
          break
        case 20:
          py = n
          break
        case 30:
          pz = n
          break
        case 11:
          ax = n
          hasAlignment = true
          break
        case 21:
          ay = n
          hasAlignment = true
          break
        case 31:
          az = n
          hasAlignment = true
          break
        case 1:
          this.textString = String(item.value)
          break
        case 7:
          this.styleName = String(item.value)
          break
        case 39:
          this.thickness = n
          break
        case 40:
          this.height = n
          break
        case 41:
          this.widthFactor = n
          break
        case 50:
          this.rotation = AcGeMathUtil.degToRad(n)
          break
        case 51:
          this.oblique = AcGeMathUtil.degToRad(n)
          break
        case 71:
          this.generationFlag = n
          break
        case 72:
          this.horizontalMode = n
          break
        case 73:
          this.verticalMode = n
          break
        case 210:
          nx = n
          break
        case 220:
          ny = n
          break
        case 230:
          nz = n
          break
        case 100: {
          // TEXT uses a duplicated AcDbText marker before group 73. ATTRIB /
          // ATTDEF follow with a different subclass — hand those off.
          const marker = String(item.value)
          if (marker === 'AcDbText') {
            break
          }
          filer.pushBackItem(item)
          this.finishTextDxfIn(px, py, pz, ax, ay, az, hasAlignment, nx, ny, nz)
          return this
        }
        default:
          // Unknown optional TEXT codes — keep scanning within this object.
          break
      }
    }

    this.finishTextDxfIn(px, py, pz, ax, ay, az, hasAlignment, nx, ny, nz)
    return this
  }

  private finishTextDxfIn(
    px: number,
    py: number,
    pz: number,
    ax: number,
    ay: number,
    az: number,
    hasAlignment: boolean,
    nx: number,
    ny: number,
    nz: number
  ) {
    this.position = new AcGePoint3d(px, py, pz)
    // The assignment goes through the setter (which marks the alignment
    // point as provided), so set the flag explicitly afterwards: only a
    // present and non-zero group 11 counts as provided; the fallback branch
    // merely mirrors `position` into `alignmentPoint`.
    if (hasAlignment && !(ax === 0 && ay === 0 && az === 0)) {
      this.alignmentPoint = new AcGePoint3d(ax, ay, az)
      this._hasAlignmentPoint = true
    } else {
      this.alignmentPoint = new AcGePoint3d(px, py, pz)
      this._hasAlignmentPoint = false
    }
    const normal = new AcGeVector3d(nx, ny, nz)
    if (normal.lengthSq() > 0) {
      this.normal.copy(normal.normalize())
    }
  }
}
