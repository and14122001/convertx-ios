import {
  AcGeMatrix3d,
  AcGePoint3d,
  AcGePoint3dLike
} from '@mlightcad/geometry-engine'

import { AcDbDxfFiler } from '../../base/index.js'
import { AcDbEntityProperties } from '../AcDbEntityProperties.js'
import {
  acdbBuildAnnotationText,
  acdbCreateDimLineEntity,
  acdbCreateDimMText,
  acdbCreateEmptyDimBlock,
  acdbDimFeatureScale,
  acdbEnsureDimArrowBlocks,
  acdbTextHeightFromStyle
} from './AcDbDimBlockBuilder.js'
import { AcDbDimension } from './AcDbDimension.js'

/**
 * Represents an ordinate dimension entity in AutoCAD.
 *
 * Ordinate dimensions measure the "horizontal" (X axis) or "vertical" (Y axis) distance
 * from a specified origin point to some other specified point. They are commonly used
 * in mechanical drawings, architectural plans, and other technical documentation where
 * precise coordinate measurements are required.
 *
 * The dimension displays a leader line from the defining point to the leader end point,
 * with the annotation text located appropriately near the end of the leader. Ordinate
 * dimensions are particularly useful for dimensioning parts with multiple features that
 * need to be positioned relative to a common reference point.
 */
export class AcDbOrdinateDimension extends AcDbDimension {
  /** The entity type name */
  static override typeName: string = 'OrdinateDimension'

  private _definingPoint: AcGePoint3d
  private _leaderEndPoint: AcGePoint3d

  /**
   * Creates a new ordinate dimension.
   *
   * @param definingPoint - The point where the ordinate leader should start. This is
   *                        the point being measured relative to the dimension's origin
   * @param leaderEndPoint - The point where the ordinate leader should end. This point
   *                         is used for the dimension leader's endpoint and in text
   *                         position calculations
   * @param dimText - Optional custom dimension text to display instead of the calculated
   *                  coordinate value. If null, the calculated coordinate will be displayed
   * @param dimStyle - Optional name of the dimension style table record to use for
   *                   formatting. If null, the current default style will be used
   */
  constructor(
    definingPoint: AcGePoint3dLike,
    leaderEndPoint: AcGePoint3dLike,
    dimText: string | null = null,
    dimStyle: string | null = null
  ) {
    super()
    this._definingPoint = new AcGePoint3d().copy(definingPoint)
    this._leaderEndPoint = new AcGePoint3d().copy(leaderEndPoint)

    this.dimensionText = dimText
    // TODO: Set it to the current default dimStyle within the AutoCAD editor if dimStyle is null
    this.dimensionStyleName = dimStyle
    // DXF group 70 low nibble 6 = ordinate. Bit 0x40 selects the X datum.
    this.dimensionType = 6
  }

  /**
   * Ordinate origin (DXF group 10). Measurement is the X or Y delta from this
   * point to {@link definingPoint}.
   */
  get origin() {
    return this._dxfDefinitionPoint
  }
  set origin(value: AcGePoint3d) {
    this._dxfDefinitionPoint.copy(value)
  }

  /**
   * When true the dimension reports the X coordinate (group 70 bit 64).
   * Otherwise it reports the Y coordinate.
   */
  get useXAxis() {
    return (this.dimensionType & 0x40) !== 0
  }
  set useXAxis(value: boolean) {
    const preserved = (this.dimensionType & ~0x4f) | 6
    this.dimensionType = value ? preserved | 0x40 : preserved
  }

  /**
   * Gets or sets the ordinate point to be measured.
   *
   * This is the point (in WCS coordinates) that defines the location being measured.
   * The dimension measures the X or Y distance between this point and the dimension's
   * origin point, depending on the orientation of the ordinate dimension.
   *
   * @returns The defining point of the ordinate dimension
   */
  get definingPoint() {
    return this._definingPoint
  }
  set definingPoint(value: AcGePoint3d) {
    this._definingPoint.copy(value)
  }

  /**
   * Gets or sets the leader end point.
   *
   * This point is used as the dimension leader's endpoint and is used in the text
   * position calculations. It determines where the leader line ends and where the
   * dimension text is positioned relative to the leader.
   *
   * @returns The leader end point of the ordinate dimension
   */
  get leaderEndPoint() {
    return this._leaderEndPoint
  }
  set leaderEndPoint(value: AcGePoint3d) {
    this._leaderEndPoint.copy(value)
  }

  override get properties(): AcDbEntityProperties {
    const baseProperties = this.getBaseProperties()
    return {
      type: this.type,
      groups: [
        ...baseProperties.groups,
        {
          groupName: 'geometry',
          properties: [
            ...this.createPoint3dProperties(
              'definingPoint',
              () => this.definingPoint
            ),
            ...this.createPoint3dProperties(
              'leaderEndPoint',
              () => this.leaderEndPoint
            )
          ]
        }
      ]
    }
  }

  /**
   * @inheritdoc
   */
  protected override collectDimensionDefinitionGripPoints() {
    return [this.definingPoint, this.leaderEndPoint]
  }

  /**
   * @inheritdoc
   */
  protected override subTransformBy(matrix: AcGeMatrix3d) {
    this._dxfDefinitionPoint.applyMatrix4(matrix)
    this._definingPoint.applyMatrix4(matrix)
    this._leaderEndPoint.applyMatrix4(matrix)
  }

  /**
   * Gets the geometric extents (bounding box) of this dimension entity.
   *
   * The geometric extents define the minimum bounding box that completely contains
   * the dimension entity, including all its components like the leader line and text.
   *
   * @returns A 3D bounding box containing the dimension entity
   * @inheritdoc
   */
  get geometricExtents() {
    return this.getGeometricExtentsFromDimBlockOrPoints([
      this.definingPoint,
      this.leaderEndPoint
    ])
  }

  /**
   * Gets the number of arrow lines for this dimension.
   *
   * Ordinate dimensions typically don't use arrows since they are coordinate-based
   * measurements rather than distance measurements between two points.
   *
   * @returns The number of arrow lines (always 0 for ordinate dimensions)
   * @inheritdoc
   */
  protected get arrowLineCount() {
    return 0
  }

  protected override getMeasurementPropertyValue() {
    if (this.measurement != null) return this.measurement
    return this.useXAxis
      ? this.definingPoint.x - this.origin.x
      : this.definingPoint.y - this.origin.y
  }

  createDimBlock(blockName: string) {
    const style = this.dimensionStyle
    acdbEnsureDimArrowBlocks(this.database, style)

    const block = acdbCreateEmptyDimBlock(blockName)
    const def = this.definingPoint
    const end = this.leaderEndPoint
    const knee = this.useXAxis
      ? new AcGePoint3d(def.x, end.y, def.z)
      : new AcGePoint3d(end.x, def.y, def.z)

    if (def.distanceTo(knee) > 1e-9) {
      block.appendEntity(acdbCreateDimLineEntity(def, knee, style))
    }
    if (knee.distanceTo(end) > 1e-9) {
      block.appendEntity(acdbCreateDimLineEntity(knee, end, style))
    } else if (def.distanceTo(end) > 1e-9 && def.distanceTo(knee) <= 1e-9) {
      block.appendEntity(acdbCreateDimLineEntity(def, end, style))
    }

    const alongX = this.useXAxis || style.dimtih !== 0
    const rotation = alongX ? 0 : Math.PI / 2
    const gap =
      (style.dimgap >= 0 ? style.dimgap : 0) *
        acdbDimFeatureScale(style, this) +
      acdbTextHeightFromStyle(style, this) * 0.5
    const textPos = new AcGePoint3d(
      end.x + (this.useXAxis ? Math.sign(end.x - def.x || 1) * gap : 0),
      end.y + (this.useXAxis ? 0 : Math.sign(end.y - def.y || 1) * gap),
      end.z
    )
    this.textPosition = textPos
    const mtext = acdbCreateDimMText({
      contents: acdbBuildAnnotationText(
        this.getMeasurementPropertyValue() ?? 0,
        this.dimensionText,
        style,
        'linear'
      ),
      position: textPos,
      rotation,
      style,
      entity: this
    })
    if (mtext) block.appendEntity(mtext)

    return block
  }

  /**
   * Writes DXF fields for this object.
   *
   * @param filer - DXF output writer.
   * @returns The instance (for chaining).
   */
  override dxfOutFields(filer: AcDbDxfFiler) {
    super.dxfOutFields(filer)
    filer.writeSubclassMarker('AcDbOrdinateDimension')
    filer.writePoint3d(13, this.definingPoint)
    filer.writePoint3d(14, this.leaderEndPoint)
    return this
  }

  override dxfInFields(filer: AcDbDxfFiler): this {
    super.dxfInFields(filer)
    filer.atSubclassData('AcDbOrdinateDimension')

    let dx = this.definingPoint.x
    let dy = this.definingPoint.y
    let dz = this.definingPoint.z
    let lx = this.leaderEndPoint.x
    let ly = this.leaderEndPoint.y
    let lz = this.leaderEndPoint.z

    const commit = () => {
      this.definingPoint = new AcGePoint3d(dx, dy, dz)
      this.leaderEndPoint = new AcGePoint3d(lx, ly, lz)
    }

    while (!filer.atEndOfObject && !filer.atEof && !filer.atExtendedData) {
      const item = filer.readItem()
      if (!item) break
      const code = Number(item.code)
      const n = Number(item.value)
      switch (code) {
        case 13:
          dx = n
          break
        case 23:
          dy = n
          break
        case 33:
          dz = n
          break
        case 14:
          lx = n
          break
        case 24:
          ly = n
          break
        case 34:
          lz = n
          break
        default:
          break
      }
    }

    commit()
    return this
  }
}
