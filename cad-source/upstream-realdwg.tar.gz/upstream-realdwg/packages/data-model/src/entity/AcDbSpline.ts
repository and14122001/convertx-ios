import { AcCmErrors } from '@mlightcad/common'
import {
  AcGeIntersectPrimitive,
  AcGeKnotParameterizationType,
  AcGeMatrix3d,
  acgeOffsetSmoothedSampledPath,
  AcGePoint2d,
  AcGePoint3dLike,
  AcGeSpline3d,
  AcGeVector3d,
  AcGeVector3dLike
} from '@mlightcad/geometry-engine'
import { AcGiRenderer } from '@mlightcad/graphic-interface'

import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js'
import { acdbDrawTessellateOptions } from '../misc/AcDbDrawTessellate.js'
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode.js'
import { AcDbCurve } from './AcDbCurve.js'
import { AcDbPolyline } from './AcDbPolyline.js'

function resolveSplineKnotParameterization(
  flag: number
): AcGeKnotParameterizationType {
  if (flag & 2048) return 'SqrtChord'
  if (flag & 1024) return 'Chord'
  return 'Uniform'
}

function createAcDbSplineFromGeo(
  geo: AcGeSpline3d,
  closed: boolean
): AcDbSpline | null {
  try {
    return new AcDbSpline(
      geo.controlPoints,
      geo.knots,
      acgeNormalizeSplineWeights(geo.weights, geo.controlPoints.length),
      geo.degree,
      closed
    )
  } catch {
    return null
  }
}

function acgeNormalizeSplineWeights(
  weights: number[] | undefined,
  controlPointCount: number
): number[] | undefined {
  if (!weights || weights.length !== controlPointCount) {
    return undefined
  }
  return weights
}

/**
 * Represents a spline entity in AutoCAD.
 *
 * A spline is a 3D geometric object defined by control points or fit points.
 * Splines are smooth curves that can be used to create complex curved shapes
 * in drawings. They can be either open or closed curves.
 *
 * @example
 * ```typescript
 * // Create a spline from control points
 * const controlPoints = [
 *   new AcGePoint3d(0, 0, 0),
 *   new AcGePoint3d(5, 5, 0),
 *   new AcGePoint3d(10, 0, 0)
 * ];
 * const knots = [0, 0, 0, 1, 1, 1];
 * const spline = new AcDbSpline(controlPoints, knots);
 *
 * // Create a spline from fit points
 * const fitPoints = [
 *   new AcGePoint3d(0, 0, 0),
 *   new AcGePoint3d(5, 5, 0),
 *   new AcGePoint3d(10, 0, 0)
 * ];
 * const spline2 = new AcDbSpline(fitPoints, AcGeKnotParameterizationType.Uniform);
 * ```
 */
export class AcDbSpline extends AcDbCurve {
  /** The entity type name */
  static override typeName: string = 'Spline'

  override get dxfTypeName() {
    return 'SPLINE'
  }

  /**
   * Creates a spline entity from control points, knots, and optional weights.
   *
   * Unlike the constructor, this factory tolerates imperfect DWG/DXF data: it derives
   * a valid degree when `declaredDegree` is missing or zero, clamps degree to the
   * available control points, and returns `null` instead of throwing when the input
   * cannot produce a valid NURBS curve.
   *
   * @param controlPoints - Control vertices in World Coordinate System (WCS) coordinates
   * @param knots - Full knot vector for the spline
   * @param weights - Optional per-control-point weights; ignored when the array length
   *   does not match `controlPoints.length`
   * @param declaredDegree - Degree from the source file; when less than 1, derived from
   *   `knots.length - controlPoints.length - 1`, then clamped to `[1, controlPoints.length - 1]`
   * @param closed - Whether the spline forms a closed loop
   * @returns A new spline entity, or `null` if construction fails
   *
   * @example
   * ```typescript
   * const spline = AcDbSpline.fromControlPoints(
   *   [
   *     { x: 0, y: 0, z: 0 },
   *     { x: 1, y: 1, z: 0 },
   *     { x: 2, y: 0, z: 0 },
   *     { x: 3, y: 1, z: 0 }
   *   ],
   *   [0, 0, 0, 0, 1, 1, 1, 1],
   *   undefined,
   *   0,
   *   false
   * );
   * ```
   */
  static fromControlPoints(
    controlPoints: AcGePoint3dLike[],
    knots: number[],
    weights: number[] | undefined,
    declaredDegree: number | undefined,
    closed: boolean
  ): AcDbSpline | null {
    const geo = AcGeSpline3d.fromControlPoints(
      controlPoints,
      knots,
      weights,
      declaredDegree,
      closed
    )
    return geo ? createAcDbSplineFromGeo(geo, closed) : null
  }

  /**
   * Creates a spline entity that interpolates fit points.
   *
   * Knots and control points are computed internally from the fit data. Start and end
   * tangents are applied only when they are non-zero direction vectors. Degree is
   * clamped so that `fitPoints.length + tangentCount >= degree + 1`.
   *
   * @param fitPoints - Points the spline should pass through, in WCS coordinates
   * @param knotParam - Knot parameterization (`'Uniform'`, `'Chord'`, or `'SqrtChord'`)
   * @param declaredDegree - Requested degree from the source file; defaults to 3 when
   *   missing or less than 1, then clamped to fit the available fit/tangent data
   * @param closed - Whether the spline forms a closed loop
   * @param startTangent - Optional start tangent direction; ignored when zero-length
   * @param endTangent - Optional end tangent direction; ignored when zero-length
   * @returns A new spline entity, or `null` if construction fails
   *
   * @example
   * ```typescript
   * const spline = AcDbSpline.fromFitPoints(
   *   [{ x: 0, y: 0, z: 0 }, { x: 10, y: 0, z: 0 }],
   *   'Uniform',
   *   3,
   *   false,
   *   { x: 1, y: 0, z: 0 },
   *   { x: 1, y: 0, z: 0 }
   * );
   * ```
   */
  static fromFitPoints(
    fitPoints: AcGePoint3dLike[],
    knotParam: AcGeKnotParameterizationType,
    declaredDegree: number | undefined,
    closed: boolean,
    startTangent?: AcGePoint3dLike | null,
    endTangent?: AcGePoint3dLike | null
  ): AcDbSpline | null {
    const geo = AcGeSpline3d.fromFitPoints(
      fitPoints,
      knotParam,
      declaredDegree,
      closed,
      startTangent,
      endTangent
    )
    return geo ? createAcDbSplineFromGeo(geo, closed) : null
  }

  /**
   * Creates a spline entity from parsed DWG/DXF SPLINE fields.
   *
   * This is the preferred entry point for file converters. Control-point data is tried
   * first; when that fails (for example, too few control points for the knot vector),
   * fit-point data is used as a fallback.
   *
   * The `flag` field encodes spline properties from group code 70:
   * - bit 0 (`0x01`): closed spline
   * - bit 1 (`0x02`): periodic
   * - bit 2 (`0x04`): rational (weights are passed separately via `weights`)
   * - bit 10 (`1024`): Chord knot parameterization for fit splines
   * - bit 11 (`2048`): SqrtChord knot parameterization for fit splines
   * - when neither Chord nor SqrtChord is set: Uniform knot parameterization
   *
   * @param spline - Parsed SPLINE entity payload from a DWG/DXF reader
   * @param spline.flag - SPLINE flags (group code 70)
   * @param spline.degree - Declared degree (group code 71)
   * @param spline.numberOfControlPoints - Count of control points (group code 73)
   * @param spline.numberOfKnots - Count of knots (group code 72)
   * @param spline.numberOfFitPoints - Count of fit points (group code 74)
   * @param spline.controlPoints - Control vertices (group codes 10/20/30)
   * @param spline.knots - Knot values (group code 40)
   * @param spline.weights - Optional weights (group code 41)
   * @param spline.fitPoints - Fit points (group codes 11/21/31)
   * @param spline.startTangent - Optional start tangent (group codes 12/22/32)
   * @param spline.endTangent - Optional end tangent (group codes 13/23/33)
   * @returns A new spline entity, or `null` when neither control nor fit data can be used
   */
  static fromDwgSpline(spline: {
    flag: number
    degree?: number
    numberOfControlPoints: number
    numberOfKnots: number
    numberOfFitPoints: number
    controlPoints: AcGePoint3dLike[]
    knots: number[]
    weights?: number[]
    fitPoints: AcGePoint3dLike[]
    startTangent?: AcGePoint3dLike | null
    endTangent?: AcGePoint3dLike | null
  }): AcDbSpline | null {
    const closed = !!(spline.flag & 0x01)
    const knotParam = resolveSplineKnotParameterization(spline.flag)

    const controlPointCount =
      spline.numberOfControlPoints || spline.controlPoints?.length || 0
    const knotCount = spline.numberOfKnots || spline.knots?.length || 0
    const fitPointCount =
      spline.numberOfFitPoints || spline.fitPoints?.length || 0

    if (controlPointCount > 0 && knotCount > 0) {
      const fromControlPoints = AcDbSpline.fromControlPoints(
        spline.controlPoints,
        spline.knots,
        spline.weights,
        spline.degree,
        closed
      )
      if (fromControlPoints) {
        return fromControlPoints
      }
    }

    // LibreDWG / some DWG writers emit fit points without group 74
    // (`numberOfFitPoints`). Branching on the declared count alone drops the
    // spline into an empty path (cad-viewer#724).
    if (fitPointCount > 0) {
      return AcDbSpline.fromFitPoints(
        spline.fitPoints,
        knotParam,
        spline.degree,
        closed,
        spline.startTangent,
        spline.endTangent
      )
    }

    return null
  }

  /** Backing for the lazily materialized geometric spline object. */
  private _geoData: AcGeSpline3d | null = null

  /**
   * The underlying geometric spline object. Materialized lazily so that
   * factory-created entities (dxfIn path) never build a dummy spline.
   */
  private get _geo(): AcGeSpline3d {
    if (this._geoData == null) {
      const controlPoints = [
        { x: 0, y: 0, z: 0 },
        { x: 1, y: 0, z: 0 },
        { x: 2, y: 0, z: 0 },
        { x: 3, y: 0, z: 0 }
      ]
      const knots = [0, 0, 0, 0, 1, 1, 1, 1]
      this._geoData =
        AcGeSpline3d.fromControlPoints(
          controlPoints,
          knots,
          undefined,
          3,
          false
        ) ?? new AcGeSpline3d(controlPoints, knots, undefined, 3, false)
    }
    return this._geoData
  }

  private set _geo(value: AcGeSpline3d) {
    this._geoData = value
  }
  /** Knot tolerance (DXF group 42) */
  private _knotTolerance = 1e-6
  /** Control-point tolerance (DXF group 43) */
  private _controlTolerance = 1e-6
  /** Fit tolerance (DXF group 44) */
  private _fitTolerance = 1e-9
  /** Extrusion / plane normal (DXF group 210) */
  private _normal = new AcGeVector3d(0, 0, 1)

  /**
   * Creates a new spline entity from control points.
   *
   * This constructor creates a spline using the specified control points, knots,
   * and optional weights. The control points must be in World Coordinate System (WCS) coordinates.
   *
   * @param controlPoints - Array of control points in WCS coordinates
   * @param knots - Array of knot values that define the spline's parameterization
   * @param weights - Optional array of weights for each control point (default: 1 for all)
   * @param degree - Optional degree of the spline (default: 3)
   * @param closed - Whether the spline should be closed (default: false)
   *
   * @example
   * ```typescript
   * const controlPoints = [
   *   new AcGePoint3d(0, 0, 0),
   *   new AcGePoint3d(5, 5, 0),
   *   new AcGePoint3d(10, 0, 0)
   * ];
   * const knots = [0, 0, 0, 1, 1, 1];
   * const spline = new AcDbSpline(controlPoints, knots);
   * ```
   */
  constructor(
    controlPoints: AcGePoint3dLike[],
    knots: number[],
    weights?: number[],
    degree?: number,
    closed?: boolean
  )
  /**
   * Creates a new spline entity from fit points.
   *
   * This constructor creates a spline that passes through the specified fit points.
   * The fit points must be in World Coordinate System (WCS) coordinates.
   *
   * @param fitPoints - Array of fit points in WCS coordinates
   * @param knotParam - Knot parameterization type that defines how knots are generated
   * @param degree - Optional degree of the spline (default: 3)
   * @param closed - Whether the spline should be closed (default: false)
   *
   * @example
   * ```typescript
   * const fitPoints = [
   *   new AcGePoint3d(0, 0, 0),
   *   new AcGePoint3d(5, 5, 0),
   *   new AcGePoint3d(10, 0, 0)
   * ];
   * const spline = new AcDbSpline(fitPoints, AcGeKnotParameterizationType.Uniform);
   * ```
   */
  constructor()
  constructor(
    fitPoints: AcGePoint3dLike[],
    knotParam: AcGeKnotParameterizationType,
    degree?: number,
    closed?: boolean
  )
  constructor(a?: unknown, b?: unknown, c?: unknown, d?: unknown, e?: unknown) {
    super()
    // No-arg construction is the dxfIn factory path: geometry is built by
    // dxfIn, and the lazy _geo accessor materializes the default on demand.
    if (a === undefined) return
    this.rebuild(
      a as AcGePoint3dLike[],
      b as number[],
      c as number[],
      d as number | undefined,
      e as boolean
    )
  }

  /**
   * Rebuilds the spline geometry with new parameters.
   *
   * This method recreates the underlying geometric spline object with the specified parameters.
   * It supports the same parameter combinations as the constructor.
   *
   * @param controlPoints - Array of control points in WCS coordinates
   * @param knots - Array of knot values that define the spline's parameterization
   * @param weights - Optional array of weights for each control point (default: 1 for all)
   * @param degree - Optional degree of the spline (default: 3)
   * @param closed - Whether the spline should be closed (default: false)
   *
   * @example
   * ```typescript
   * const controlPoints = [
   *   new AcGePoint3d(0, 0, 0),
   *   new AcGePoint3d(5, 5, 0),
   *   new AcGePoint3d(10, 0, 0)
   * ];
   * const knots = [0, 0, 0, 1, 1, 1];
   * spline.rebuild(controlPoints, knots);
   * ```
   */
  rebuild(
    controlPoints: AcGePoint3dLike[],
    knots: number[],
    weights?: number[],
    degree?: number,
    closed?: boolean
  ): void
  /**
   * Rebuilds the spline geometry with new parameters.
   *
   * This method recreates the underlying geometric spline object with the specified parameters.
   * It supports the same parameter combinations as the constructor.
   *
   * @param fitPoints - Array of fit points in WCS coordinates
   * @param knotParam - Knot parameterization type that defines how knots are generated
   * @param degree - Optional degree of the spline (default: 3)
   * @param closed - Whether the spline should be closed (default: false)
   *
   * @example
   * ```typescript
   * const fitPoints = [
   *   new AcGePoint3d(0, 0, 0),
   *   new AcGePoint3d(5, 5, 0),
   *   new AcGePoint3d(10, 0, 0)
   * ];
   * spline.rebuild(fitPoints, AcGeKnotParameterizationType.Uniform);
   * ```
   */
  rebuild(
    fitPoints: AcGePoint3dLike[],
    knotParam: AcGeKnotParameterizationType,
    degree?: number,
    closed?: boolean
  ): void
  rebuild(a?: unknown, b?: unknown, c?: unknown, d?: unknown, e?: unknown) {
    const argsLength =
      +(a !== undefined) +
      +(b !== undefined) +
      +(c !== undefined) +
      +(d !== undefined) +
      +(e !== undefined)

    if (argsLength < 2 || argsLength > 5) {
      throw AcCmErrors.ILLEGAL_PARAMETERS
    }

    const isFitPointsConstructor = !Array.isArray(b)

    if (isFitPointsConstructor) {
      this._geo = new AcGeSpline3d(
        a as AcGePoint3dLike[],
        b as AcGeKnotParameterizationType,
        c as number | undefined,
        d as boolean | undefined
      )
    } else {
      this._geo = new AcGeSpline3d(
        a as AcGePoint3dLike[],
        b as number[],
        c as number[] | undefined,
        d as number | undefined,
        e as boolean | undefined
      )
    }
  }

  /**
   * Gets the geometric extents (bounding box) of this spline.
   *
   * @returns The bounding box that encompasses the entire spline
   *
   * @example
   * ```typescript
   * const extents = spline.geometricExtents;
   * console.log(`Spline bounds: ${extents.minPoint} to ${extents.maxPoint}`);
   * ```
   */
  get geometricExtents() {
    return this._geo.box
  }

  /** @inheritdoc */
  override subGetIntersectCurves(): AcGeIntersectPrimitive[] {
    return [
      {
        kind: 'spline',
        spline: this._geo.clone(),
        extendable: false
      }
    ]
  }

  /**
   * Gets whether this spline is closed.
   *
   * A closed spline forms a complete loop where the end point connects to the start point.
   *
   * @returns True if the spline is closed, false otherwise
   *
   * @example
   * ```typescript
   * const isClosed = spline.closed;
   * console.log(`Spline is closed: ${isClosed}`);
   * ```
   */
  get closed(): boolean {
    return this._geo.closed
  }

  /** @inheritdoc */
  get area(): number {
    return this._geo.area
  }

  /**
   * Sets whether this spline is closed.
   *
   * @param value - True to close the spline, false to open it
   *
   * @example
   * ```typescript
   * spline.closed = true; // Close the spline
   * ```
   */
  set closed(value: boolean) {
    this._geo.closed = value
  }

  /** Knot tolerance (DXF group 42). */
  get knotTolerance() {
    return this._knotTolerance
  }
  set knotTolerance(value: number) {
    this._knotTolerance = value
  }

  /** Control-point tolerance (DXF group 43). */
  get controlTolerance() {
    return this._controlTolerance
  }
  set controlTolerance(value: number) {
    this._controlTolerance = value
  }

  /** Fit tolerance (DXF group 44). */
  get fitTolerance() {
    return this._fitTolerance
  }
  set fitTolerance(value: number) {
    this._fitTolerance = value
  }

  /** Extrusion direction / plane normal (DXF group 210). */
  get normal(): AcGeVector3d {
    return this._normal
  }
  set normal(value: AcGeVector3dLike) {
    this._normal.copy(value)
  }

  /**
   * Gets the grip points for this spline.
   *
   * Grip points follow the spline definition mode: fit points for fit splines,
   * control vertices for control-point splines.
   *
   * @returns Array of grip points for editing
   */
  subGetGripPoints() {
    return this._geo.getGripPoints()
  }

  /** @inheritdoc */
  subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike) {
    this._geo.moveGripPointsAt(indices, offset)
    return this
  }

  /**
   * Gets the object snap points for this spline.
   *
   * Object snap points are precise points that can be used for positioning
   * when drawing or editing. This method provides snap points based on the
   * specified snap mode.
   *
   * @param osnapMode - The object snap mode
   * @param _pickPoint - The point where the user picked
   * @param _lastPoint - The last point
   * @param snapPoints - Array to populate with snap points
   */
  subGetOsnapPoints(
    osnapMode: AcDbOsnapMode,
    pickPoint: AcGePoint3dLike,
    _lastPoint: AcGePoint3dLike,
    snapPoints: AcGePoint3dLike[]
  ) {
    switch (osnapMode) {
      case AcDbOsnapMode.EndPoint:
        snapPoints.push(this._geo.startPoint)
        snapPoints.push(this._geo.endPoint)
        break
      case AcDbOsnapMode.Node: {
        const seen = new Set<number>()
        for (const knot of this._geo.knots) {
          if (seen.has(knot)) continue
          seen.add(knot)
          snapPoints.push(this._geo.evaluateAt(knot))
        }
        break
      }
      case AcDbOsnapMode.Nearest:
        snapPoints.push(this._geo.nearestPoint(pickPoint))
        break
      default:
        break
    }
  }

  /**
   * Transforms this spline by the specified matrix.
   */
  transformBy(matrix: AcGeMatrix3d) {
    this._geo.transform(matrix)
    return this
  }

  /**
   * This spline always draws as a single `lineStrip` primitive.
   *
   * @internal
   */
  override get directBatchPrimitive() {
    return 'lineStrip' as const
  }

  /**
   * Draws this spline using the specified renderer.
   *
   * This method renders the spline as a series of connected line segments
   * using the spline's current style properties.
   *
   * @param renderer - The renderer to use for drawing
   * @returns The rendered spline entity, or undefined if drawing failed
   */
  subWorldDraw(renderer: AcGiRenderer) {
    const points = this._geo.tessellate(acdbDrawTessellateOptions(renderer))
    return renderer.lines(points)
  }

  /**
   * Writes DXF fields for this object.
   *
   * @param filer - DXF output writer.
   * @returns The instance (for chaining).
   */
  override dxfOutFields(filer: AcDbDxfFiler) {
    const spline = this._geo as unknown as {
      degree: number
      knots: number[]
      weights: number[]
      controlPoints: AcGePoint3dLike[]
      fitPoints?: AcGePoint3dLike[]
    }
    super.dxfOutFields(filer)
    filer.writeSubclassMarker('AcDbSpline')
    filer.writeInt16(70, this.closed ? 1 : 0)
    filer.writeInt16(71, spline.degree)
    filer.writeInt16(72, spline.knots.length)
    filer.writeInt16(73, spline.controlPoints.length)
    filer.writeInt16(74, spline.fitPoints?.length ?? 0)
    filer.writeDouble(42, this.knotTolerance)
    filer.writeDouble(43, this.controlTolerance)
    filer.writeDouble(44, this.fitTolerance)
    for (const knot of spline.knots) {
      filer.writeDouble(40, knot)
    }
    for (const weight of spline.weights) {
      filer.writeDouble(41, weight)
    }
    for (const point of spline.controlPoints) {
      filer.writePoint3d(10, point)
    }
    for (const point of spline.fitPoints ?? []) {
      filer.writePoint3d(11, point)
    }
    filer.writeVector3d(210, this.normal)
    return this
  }

  override dxfInFields(filer: AcDbDxfFiler): this {
    super.dxfInFields(filer)
    filer.atSubclassData('AcDbSpline')

    let flag = this.closed ? 1 : 0
    let degree = 3
    let numberOfKnots = 0
    let numberOfControlPoints = 0
    let numberOfFitPoints = 0
    const knots: number[] = []
    const weights: number[] = []
    const controlPoints: AcGePoint3dLike[] = []
    const fitPoints: AcGePoint3dLike[] = []
    let startTangent: AcGePoint3dLike | null = null
    let endTangent: AcGePoint3dLike | null = null
    let knotTolerance = this.knotTolerance
    let controlTolerance = this.controlTolerance
    let fitTolerance = this.fitTolerance
    let nx = this.normal.x
    let ny = this.normal.y
    let nz = this.normal.z

    let pendingCtrl: AcGePoint3dLike | null = null
    let pendingFit: AcGePoint3dLike | null = null
    let pendingStart: AcGePoint3dLike | null = null
    let pendingEnd: AcGePoint3dLike | null = null

    const flushCtrl = () => {
      if (pendingCtrl) {
        controlPoints.push(pendingCtrl)
        pendingCtrl = null
      }
    }
    const flushFit = () => {
      if (pendingFit) {
        fitPoints.push(pendingFit)
        pendingFit = null
      }
    }

    while (!filer.atEndOfObject && !filer.atEof && !filer.atExtendedData) {
      const item = filer.readItem()
      if (!item) break
      const code = Number(item.code)
      const n = Number(item.value)
      switch (code) {
        case 70:
          flag = n
          break
        case 71:
          degree = n
          break
        case 72:
          numberOfKnots = n
          break
        case 73:
          numberOfControlPoints = n
          break
        case 74:
          numberOfFitPoints = n
          break
        case 42:
          knotTolerance = n
          break
        case 43:
          controlTolerance = n
          break
        case 44:
          fitTolerance = n
          break
        case 40:
          knots.push(n)
          break
        case 41:
          weights.push(n)
          break
        case 10:
          flushCtrl()
          pendingCtrl = { x: n, y: 0, z: 0 }
          break
        case 20:
          if (pendingCtrl) pendingCtrl.y = n
          break
        case 30:
          if (pendingCtrl) pendingCtrl.z = n
          break
        case 11:
          flushFit()
          pendingFit = { x: n, y: 0, z: 0 }
          break
        case 21:
          if (pendingFit) pendingFit.y = n
          break
        case 31:
          if (pendingFit) pendingFit.z = n
          break
        case 12:
          pendingStart = { x: n, y: 0, z: 0 }
          break
        case 22:
          if (pendingStart) pendingStart.y = n
          break
        case 32:
          if (pendingStart) {
            pendingStart.z = n
            startTangent = pendingStart
            pendingStart = null
          }
          break
        case 13:
          pendingEnd = { x: n, y: 0, z: 0 }
          break
        case 23:
          if (pendingEnd) pendingEnd.y = n
          break
        case 33:
          if (pendingEnd) {
            pendingEnd.z = n
            endTangent = pendingEnd
            pendingEnd = null
          }
          break
        case 210:
          nx = n
          break
        case 220:
          ny = n
          break
        case 230:
          nz = n
          break
        default:
          break
      }
    }

    flushCtrl()
    flushFit()
    this.knotTolerance = knotTolerance
    this.controlTolerance = controlTolerance
    this.fitTolerance = fitTolerance
    const normal = new AcGeVector3d(nx, ny, nz)
    if (normal.lengthSq() > 0) {
      this.normal.copy(normal.normalize())
    }
    this.applyDxfInSpline({
      flag,
      degree,
      numberOfControlPoints: numberOfControlPoints || controlPoints.length,
      numberOfKnots: numberOfKnots || knots.length,
      numberOfFitPoints: numberOfFitPoints || fitPoints.length,
      controlPoints,
      knots,
      weights: weights.length > 0 ? weights : undefined,
      fitPoints,
      startTangent,
      endTangent
    })
    return this
  }

  private applyDxfInSpline(data: {
    flag: number
    degree?: number
    numberOfControlPoints: number
    numberOfKnots: number
    numberOfFitPoints: number
    controlPoints: AcGePoint3dLike[]
    knots: number[]
    weights?: number[]
    fitPoints: AcGePoint3dLike[]
    startTangent?: AcGePoint3dLike | null
    endTangent?: AcGePoint3dLike | null
  }) {
    const built = AcDbSpline.fromDwgSpline(data)
    if (built) {
      this._geo = built._geo
      this.closed = built.closed
    }
  }

  /**
   * {@inheritDoc AcDbCurve.getOffsetCurves}
   *
   * Approximates the spline with a densely sampled path in XY, offsets each sample
   * along its local normal, and trims self-intersecting loops at tight bends.
   * The result is an {@link AcDbPolyline}, not a spline entity.
   */
  override getOffsetCurves(offsetDist: number): AcDbCurve[] {
    const curve = this.createOffsetCurve(offsetDist)
    return curve ? [curve] : []
  }

  /**
   * {@inheritDoc AcDbCurve.getOffsetSideAtPoint}
   *
   * Evaluates side relative to the sampled 2D approximation of the spline.
   */
  override getOffsetSideAtPoint(point: AcGePoint3dLike): 1 | -1 {
    const path = this.collectPath2d(1)
    if (path.length < 2) return 1
    return AcDbPolyline.from2dPoints(path, this.closed).getOffsetSideAtPoint(
      point
    )
  }

  /**
   * @param offsetDist - Signed offset distance in drawing units
   * @returns Offset polyline approximating this spline, or `null` on failure
   */
  private createOffsetCurve(offsetDist: number): AcDbCurve | null {
    const { points, tangents } = this._geo.getOffsetSamplePath2d(offsetDist)
    const geo = acgeOffsetSmoothedSampledPath(
      points,
      this.closed,
      offsetDist,
      tangents
    )
    return geo ? AcDbPolyline.fromGePolyline(geo) : null
  }

  /**
   * Samples {@link AcGeSpline3d} for side tests (uniform parameter density).
   *
   * @param offsetDist - Used only to choose sample spacing
   * @returns XY points along the spline
   */
  private collectPath2d(offsetDist: number): AcGePoint2d[] {
    return this._geo.getOffsetSamplePath2d(offsetDist).points
  }
}

