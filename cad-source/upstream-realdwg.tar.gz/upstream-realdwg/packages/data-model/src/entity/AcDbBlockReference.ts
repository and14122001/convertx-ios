import {
  AcGeBox3d,
  AcGeIntersectPrimitive,
  AcGeMathUtil,
  AcGeMatrix3d,
  AcGePoint3d,
  AcGePoint3dLike,
  AcGeQuaternion,
  AcGeVector3d,
  AcGeVector3dLike
} from '@mlightcad/geometry-engine'
import { AcGiEntity, AcGiRenderer } from '@mlightcad/graphic-interface'

import { AcDbDxfFiler } from '../base/AcDbDxfFiler.js'
import { AcDbObjectId } from '../base/AcDbObject.js'
import {
  type AcDbAnnotationScaleContext,
  type AcDbAnnotationScaleDrawInfo,
  acdbBuildAnnotationScaleDrawInfo,
  acdbGetAnnotationScaleContexts,
  acdbGetAnnotative,
  acdbIsAnnotativeObject,
  acdbMatchAnnotationScaleContext,
  acdbResolveAnnotationScaleDrawInfo,
  acdbSetAnnotative
} from '../misc/AcDbAnnotationScale.js'
import { AcDbObjectIterator } from '../misc/AcDbObjectIterator.js'
import { AcDbOsnapMode } from '../misc/AcDbOsnapMode.js'
import { AcDbRenderingCache } from '../misc/AcDbRenderingCache.js'
import { AcDbBlkRefObjectContextData } from '../object/AcDbBlkRefObjectContextData.js'
import { AcDbDynBlockReference } from '../object/AcDbDynBlockReference.js'
import { AcDbAttribute } from './AcDbAttribute.js'
import { AcDbEntity } from './AcDbEntity.js'
import {
  AcDbEntityProperties,
  AcDbEntityPropertyGroup
} from './AcDbEntityProperties.js'
import { acdbMovePrimaryGripPointAt } from './AcDbGripHelpers.js'
import { acdbTransformIntersectPrimitives } from './AcDbIntersectHelpers.js'
import {
  acdbParseGsMark,
  acdbPickNearestOsnapPoint
} from './AcDbOsnapHelpers.js'

/**
 * Represents a block reference entity in AutoCAD.
 *
 * A block reference is used to place, size, and display an instance of the collection
 * of entities within the block table record that it references. Block references allow
 * you to reuse complex geometry by referencing a block definition multiple times with
 * different positions, rotations, and scales.
 *
 * @example
 * ```typescript
 * // Create a block reference
 * const blockRef = new AcDbBlockReference("MyBlock");
 * blockRef.position = new AcGePoint3d(10, 20, 0);
 * blockRef.rotation = Math.PI / 4; // 45 degrees
 * blockRef.scaleFactors = new AcGePoint3d(2, 2, 1); // 2x scale
 *
 * // Access block reference properties
 * console.log(`Block name: ${blockRef.blockTableRecord?.name}`);
 * console.log(`Position: ${blockRef.position}`);
 * console.log(`Rotation: ${blockRef.rotation}`);
 * ```
 */
export class AcDbBlockReference extends AcDbEntity {
  /** The entity type name */
  static override typeName: string = 'BlockReference'

  override get dxfTypeName() {
    return 'INSERT'
  }

  /** The WCS position point (insertion point) of the block reference */
  private _position: AcGePoint3d
  /** The rotation value in radians */
  private _rotation: number
  /** The X, Y, and Z scale factors for the block reference */
  private _scaleFactors: AcGePoint3d
  /** The normal vector of the plane containing the block reference */
  private _normal: AcGeVector3d
  /** The name of the referenced block */
  private _blockName: string
  /** Attributes associated with this block reference */
  private _attribs: Map<string, AcDbAttribute>
  /** MINSERT column count (DXF group 70); default 1 */
  private _columnCount = 1
  /** MINSERT row count (DXF group 71); default 1 */
  private _rowCount = 1
  /** MINSERT column spacing (DXF group 44) */
  private _columnSpacing = 0
  /** MINSERT row spacing (DXF group 45) */
  private _rowSpacing = 0

  /**
   * Creates a new block reference entity.
   *
   * This constructor initializes a block reference with the specified block name.
   * The position is set to the origin, rotation to 0, normal to Z-axis, and scale factors to 1.
   *
   * @param blockName - The name of the block table record to reference
   *
   * @example
   * ```typescript
   * const blockRef = new AcDbBlockReference("MyBlock");
   * blockRef.position = new AcGePoint3d(5, 10, 0);
   * blockRef.rotation = Math.PI / 6; // 30 degrees
   * ```
   */
  /** Transient presentation used while `subWorldDraw` is in progress. */
  private _drawPresentation?: {
    position: AcGePoint3d
    rotation: number
    scaleFactors: AcGePoint3d
    preferred?: AcDbAnnotationScaleContext
    annotationScale?: AcDbAnnotationScaleDrawInfo
  }

  constructor(blockName: string) {
    super()
    this._blockName = blockName ?? ''
    this._position = new AcGePoint3d()
    this._rotation = 0.0
    this._normal = new AcGeVector3d(0, 0, 1)
    this._scaleFactors = new AcGePoint3d(1, 1, 1)
    this._attribs = new Map()
  }

  /**
   * Gets the WCS position point (insertion point) of the block reference.
   *
   * @returns The position point in WCS coordinates
   *
   * @example
   * ```typescript
   * const position = blockRef.position;
   * console.log(`Block position: ${position.x}, ${position.y}, ${position.z}`);
   * ```
   */
  /**
   * Whether this INSERT is annotative (entity XDATA/contexts, or an annotative
   * block definition).
   */
  get annotative() {
    if (acdbGetAnnotative(this)) return true
    const btr = this.blockTableRecord
    return !!btr?.annotative
  }
  set annotative(value: boolean) {
    acdbSetAnnotative(this, value)
  }

  get position(): AcGePoint3d {
    return this._position
  }

  /**
   * Sets the WCS position point (insertion point) of the block reference.
   *
   * @param value - The new position point
   *
   * @example
   * ```typescript
   * blockRef.position = new AcGePoint3d(15, 25, 0);
   * ```
   */
  set position(value: AcGePoint3dLike) {
    this._position.copy(value)
  }

  /**
   * Gets the rotation value of the block reference.
   *
   * The rotation value is relative to the X axis of a coordinate system that is parallel
   * to the OCS of the block reference, but has its origin at the position point of the
   * block reference. The rotation axis is the Z axis of this coordinate system with
   * positive rotations going counterclockwise when looking down the Z axis towards the origin.
   *
   * @returns The rotation value in radians
   *
   * @example
   * ```typescript
   * const rotation = blockRef.rotation;
   * console.log(`Rotation: ${rotation} radians (${rotation * 180 / Math.PI} degrees)`);
   * ```
   */
  get rotation() {
    return this._rotation
  }

  /**
   * Sets the rotation value of the block reference.
   *
   * @param value - The new rotation value in radians
   *
   * @example
   * ```typescript
   * blockRef.rotation = Math.PI / 4; // 45 degrees
   * ```
   */
  set rotation(value: number) {
    this._rotation = value
  }

  /**
   * Gets the X, Y, and Z scale factors for the block reference.
   *
   * @returns The scale factors as a 3D point
   *
   * @example
   * ```typescript
   * const scaleFactors = blockRef.scaleFactors;
   * console.log(`Scale factors: ${scaleFactors.x}, ${scaleFactors.y}, ${scaleFactors.z}`);
   * ```
   */
  get scaleFactors(): AcGePoint3d {
    return this._scaleFactors
  }

  /**
   * Sets the X, Y, and Z scale factors for the block reference.
   *
   * @param value - The new scale factors
   *
   * @example
   * ```typescript
   * blockRef.scaleFactors = new AcGePoint3d(2, 1.5, 1); // 2x X scale, 1.5x Y scale
   * ```
   */
  set scaleFactors(value: AcGePoint3dLike) {
    this._scaleFactors.copy(value)
  }

  /**
   * Gets the normal vector of the plane containing the block reference.
   *
   * @returns The normal vector
   *
   * @example
   * ```typescript
   * const normal = blockRef.normal;
   * console.log(`Normal: ${normal.x}, ${normal.y}, ${normal.z}`);
   * ```
   */
  get normal(): AcGeVector3d {
    return this._normal
  }

  /**
   * Sets the normal vector of the plane containing the block reference.
   *
   * @param value - The new normal vector
   *
   * @example
   * ```typescript
   * blockRef.normal = new AcGeVector3d(0, 0, 1);
   * ```
   */
  set normal(value: AcGeVector3dLike) {
    this._normal.copy(value).normalize()
  }

  /**
   * Gets the name of the block definition referenced by this INSERT entity.
   *
   * The returned value is the block table record key used to resolve
   * {@link blockTableRecord} from the current database.
   *
   * @returns The referenced block name.
   */
  get blockName() {
    return this._blockName
  }

  /**
   * Sets the name of the block table record referenced by this insert.
   * Used when filing in from DXF (group code 2).
   */
  set blockName(value: string) {
    this._blockName = value
  }

  /** MINSERT column count (DXF group 70). */
  get columnCount() {
    return this._columnCount
  }
  set columnCount(value: number) {
    this._columnCount = Math.max(1, Math.floor(value) || 1)
  }

  /** MINSERT row count (DXF group 71). */
  get rowCount() {
    return this._rowCount
  }
  set rowCount(value: number) {
    this._rowCount = Math.max(1, Math.floor(value) || 1)
  }

  /** MINSERT column spacing (DXF group 44). */
  get columnSpacing() {
    return this._columnSpacing
  }
  set columnSpacing(value: number) {
    this._columnSpacing = value
  }

  /** MINSERT row spacing (DXF group 45). */
  get rowSpacing() {
    return this._rowSpacing
  }
  set rowSpacing(value: number) {
    this._rowSpacing = value
  }

  /**
   * Gets the block table record referenced by this block reference.
   *
   * The referenced block table record contains the entities that the block reference will display.
   *
   * @returns The block table record, or undefined if not found
   *
   * @example
   * ```typescript
   * const blockRecord = blockRef.blockTableRecord;
   * if (blockRecord) {
   *   console.log(`Block name: ${blockRecord.name}`);
   * }
   * ```
   */
  get blockTableRecord() {
    // Missing block names must not throw when looking up the BTR.
    if (!this._blockName) {
      return undefined
    }
    return this.database.tables.blockTable.getAt(this._blockName)
  }

  /**
   * Block table record used for drawing, extents, osnap, and intersection.
   *
   * For dynamic block references that use an anonymous `*U` representation,
   * this returns that anonymous record (via {@link AcDbDynBlockReference});
   * otherwise it returns {@link blockTableRecord}.
   */
  get drawableBlockTableRecord() {
    return AcDbDynBlockReference.drawableBlockTableRecord(this)
  }

  /**
   * Appends the specified AcDbAttribute object to the attribute list of the block reference,
   * establishes the block reference as the attribute's owner, and adds the attribute to the
   * AcDbDatabase that contains the block reference.
   * @param attrib - The attribute to be appended to the attribute list of the block reference.
   */
  appendAttributes(attrib: AcDbAttribute) {
    this._attribs.set(attrib.objectId, attrib)
    attrib.ownerId = this.objectId
    this.syncAttributeDatabases()
  }

  /**
   * Propagates this INSERT's database association to all attached attributes.
   *
   * Also refreshes each attribute's {@link AcDbObject.ownerId} and commits a
   * real database handle. Attributes may have been appended while this INSERT
   * still had a TEMP_ id; once the INSERT is committed those stale owner ids
   * (and TEMP_ attribute handles) must be replaced so DXF round-trips and
   * owner lookups keep working.
   *
   * @internal
   */
  syncAttributeDatabases() {
    try {
      const db = this.database
      const next = new Map<string, AcDbAttribute>()
      this._attribs.forEach(attrib => {
        attrib.database = db
        db.commitObjectHandle(attrib)
        attrib.ownerId = this.objectId
        next.set(attrib.objectId, attrib)
      })
      this._attribs = next
    } catch {
      // INSERT not yet associated with a database.
    }
  }

  /**
   * Creates an iterator object that can be used to iterate over the attributes associated
   * with the block reference.
   *
   * @returns An iterator object that can be used to iterate over the attributes
   */
  attributeIterator(): AcDbObjectIterator<AcDbAttribute> {
    return new AcDbObjectIterator(this._attribs)
  }

  /**
   * Gets the block-local transformation matrix of this block reference.
   *
   * This matrix represents the **INSERT entity transform in Object Coordinate
   * System (OCS)**, excluding the extrusion / normal transformation.
   *
   * In AutoCAD, a block reference transform is conceptually applied in the
   * following order:
   *
   * 1. Translate geometry by the negative block base point
   * 2. Apply non-uniform scaling
   * 3. Apply rotation about the block Z axis (OCS Z)
   * 4. Translate to the insertion point
   * 5. Finally, transform from OCS to WCS using the entity normal (extrusion)
   *
   * This property returns the matrix for steps **1–4 only**.
   *
   * The OCS → WCS transformation derived from {@link normal} **must NOT be
   * included here**, because:
   *
   * - The rotation angle of an INSERT is defined in OCS
   * - Applying OCS earlier would rotate around an incorrect axis
   * - Cached block geometry must remain reusable for different normals
   *
   * Therefore, the extrusion transformation is applied **after rendering**
   * (see {@link AcDbRenderingCache.draw}), matching AutoCAD / RealDWG behavior.
   *
   * ### Matrix composition (right-multiply convention)
   *
   * ```
   * blockTransform =
   *   T(position.x, position.y, 0)
   * · R(rotation about OCS Z)
   * · S(scaleFactors)
   * · T(-blockBasePoint)
   * ```
   *
   * Insertion Z is flattened to 0 so elevated nested INSERTs stay inside the
   * 2D orthographic near/far band (same plan-view policy as
   * {@link AcDbLine.subWorldDraw}). {@link position}.z is still stored on the
   * entity.
   *
   * ### Notes
   *
   * - The returned matrix operates in OCS space
   * - Rotation is always about the OCS Z axis
   * - {@link normal} is applied later as a final orientation step
   * - This mirrors the internal behavior of `AcDbBlockReference` in ObjectARX
   *
   * @returns A transformation matrix representing the block-local INSERT transform
   *          in OCS, excluding extrusion.
   */
  get blockTransform(): AcGeMatrix3d {
    // Retrieve the referenced block table record.
    // The block definition contains its own local coordinate system
    // whose origin is the block base point.
    const blockTableRecord = this.drawableBlockTableRecord

    // The base point (origin) of the block definition.
    // All entities inside the block are defined relative to this point.
    // If the block record is missing, fall back to (0,0,0).
    const basePoint = blockTableRecord?.origin ?? AcGePoint3d.ORIGIN

    const position = this._drawPresentation?.position ?? this._position
    const rotation = this._drawPresentation?.rotation ?? this._rotation
    const scaleFactors =
      this._drawPresentation?.scaleFactors ?? this._scaleFactors

    // ------------------------------------------------------------
    // Step 1: Translate geometry by the negative block base point
    //
    // This moves block geometry so that the block base point
    // coincides with the origin (0,0,0) in block-local space.
    //
    // AutoCAD always applies this compensation first.
    // ------------------------------------------------------------
    const mBase = new AcGeMatrix3d().makeTranslation(
      -basePoint.x,
      -basePoint.y,
      -basePoint.z
    )

    // ------------------------------------------------------------
    // Step 2: Apply non-uniform scaling
    //
    // Scale factors are applied in block-local OCS coordinates.
    // Negative or non-uniform scales are supported.
    // ------------------------------------------------------------
    const mScale = new AcGeMatrix3d().makeScale(
      scaleFactors.x,
      scaleFactors.y,
      scaleFactors.z
    )

    // ------------------------------------------------------------
    // Step 3: Apply rotation about the block Z axis (OCS Z)
    //
    // IMPORTANT:
    // - The rotation angle of an INSERT is defined in OCS
    // - The rotation axis is always the local Z axis
    // - The extrusion / normal is NOT applied here
    //
    // Rotation is therefore constructed around (0,0,1).
    // ------------------------------------------------------------
    const qRot = new AcGeQuaternion().setFromAxisAngle(
      AcGeVector3d.Z_AXIS,
      rotation
    )
    const mRot = new AcGeMatrix3d().makeRotationFromQuaternion(qRot)

    // ------------------------------------------------------------
    // Step 4: Translate to the insertion point
    //
    // This moves the transformed block geometry from the origin
    // to its final insertion point, still in OCS.
    //
    // Plan-view note: translation Z is forced to 0. Orthographic 2D
    // cameras use a narrow near/far band around Z≈0 (see
    // AcDbLine.subWorldDraw). Nested INSERTs often carry large
    // elevations (e.g. title-block signature stamps at |Z|≈9000);
    // preserving that Z depth-clips their geometry even though XY is
    // on-screen. The stored position.z is unchanged for properties / DXF.
    // ------------------------------------------------------------
    const mInsert = new AcGeMatrix3d().makeTranslation(
      position.x,
      position.y,
      0
    )

    // ------------------------------------------------------------
    // Final composition (right-multiply convention)
    //
    // blockTransform =
    //   T(position.x, position.y, 0)
    // · R(rotation about OCS Z)
    // · S(scaleFactors)
    // · T(-blockBasePoint)
    //
    // NOTE:
    // - This matrix operates entirely in OCS
    // - The OCS → WCS transform derived from `normal`
    //   is intentionally excluded here
    // - Extrusion is applied later at render time
    // ------------------------------------------------------------
    return new AcGeMatrix3d()
      .multiplyMatrices(mInsert, mRot)
      .multiply(mScale)
      .multiply(mBase)
  }

  /**
   * Gets the grip points for this block reference.
   *
   * @returns Array containing the block insertion point.
   */
  subGetGripPoints() {
    return [this._position]
  }

  /** @inheritdoc */
  subMoveGripPointsAt(indices: number[], offset: AcGeVector3dLike) {
    acdbMovePrimaryGripPointAt(indices, offset, this._position)
    return this
  }

  /**
   * Gets the object snap points for this block reference.
   *
   * Object snap points are precise points that can be used for positioning
   * when drawing or editing. This method provides snap points based on the
   * specified snap mode.
   *
   * @param osnapMode - The object snap mode
   * @param pickPoint - The point where the user picked
   * @param lastPoint - The last point
   * @param snapPoints - Array to populate with snap points
   * @param gsMark - The object id of subentity. For now, it is used by INSERT
   * entity only. In AutoCAD, it uses AcGiSubEntityTraits::setSelectionMarkerInput
   * to set GS marker of the subentity involved in the object snap operation. For
   * now, we don't provide such a GS marker mechanism yet. So passed id of subentity
   * as GS marker. Maybe this behavior will change in the future.
   * @param insertionMat - Cumulative insertion transform matrix from parent
   * block references.
   */
  subGetOsnapPoints(
    osnapMode: AcDbOsnapMode,
    pickPoint: AcGePoint3dLike,
    lastPoint: AcGePoint3dLike,
    snapPoints: AcGePoint3dLike[],
    gsMark?: AcDbObjectId,
    insertionMat?: AcGeMatrix3d
  ) {
    const parentInsertionMat = insertionMat ?? new AcGeMatrix3d()

    if (AcDbOsnapMode.Insertion === osnapMode) {
      snapPoints.push(this.getInsertionPoint(parentInsertionMat))
    } else if (gsMark) {
      this.subEntityGetOsnapPoints(
        osnapMode,
        pickPoint,
        lastPoint,
        snapPoints,
        gsMark,
        parentInsertionMat
      )
    } else {
      this.collectBlockOsnapPoints(
        osnapMode,
        pickPoint,
        lastPoint,
        snapPoints,
        parentInsertionMat
      )
    }
  }

  /**
   * Transforms this block reference by an arbitrary world-space matrix.
   *
   * Unlike simple entities that can transform raw geometry directly, an INSERT
   * stores placement as decomposed parameters (`position`, `rotation`,
   * `scaleFactors`, and `normal`). This method applies the input matrix to a
   * derived local frame, then reconstructs those parameters from the transformed
   * frame so the reference remains representable as an INSERT.
   *
   * Recomposition pipeline:
   *
   * 1. Build local axes from current `rotation`, `normal`, and `scaleFactors`
   * 2. Transform axis endpoints and origin by `matrix`
   * 3. Recompute normal from transformed X/Y axes (with a degenerate fallback)
   * 4. Project transformed X axis into the new OCS to recover `rotation`
   * 5. Recover axis lengths as new `scaleFactors`
   * 6. Transform all attached attributes with the same matrix
   *
   * @param matrix - Transformation matrix in WCS.
   * @returns The current block reference instance.
   */
  transformBy(matrix: AcGeMatrix3d) {
    const extrusion = new AcGeMatrix3d().setFromExtrusionDirection(this._normal)
    const rotation = new AcGeMatrix3d().makeRotationZ(this._rotation)
    const localToWcs = new AcGeMatrix3d().multiplyMatrices(extrusion, rotation)

    const origin = this._position.clone()
    const xAxisPoint = new AcGePoint3d(this._scaleFactors.x, 0, 0)
      .applyMatrix4(localToWcs)
      .add(origin)
    const yAxisPoint = new AcGePoint3d(0, this._scaleFactors.y, 0)
      .applyMatrix4(localToWcs)
      .add(origin)
    const zAxisPoint = new AcGePoint3d(0, 0, this._scaleFactors.z)
      .applyMatrix4(localToWcs)
      .add(origin)

    origin.applyMatrix4(matrix)
    xAxisPoint.applyMatrix4(matrix)
    yAxisPoint.applyMatrix4(matrix)
    zAxisPoint.applyMatrix4(matrix)

    const xAxis = new AcGeVector3d(xAxisPoint).sub(origin)
    const yAxis = new AcGeVector3d(yAxisPoint).sub(origin)
    const zAxis = new AcGeVector3d(zAxisPoint).sub(origin)

    let normal = new AcGeVector3d().crossVectors(xAxis, yAxis)
    if (normal.lengthSq() === 0) {
      normal = this._normal.clone().transformDirection(matrix)
    } else {
      normal.normalize()
    }

    const extrusionMatrix = new AcGeMatrix3d().setFromExtrusionDirection(normal)
    const ocsInverse = extrusionMatrix.clone().invert()
    const localXAxis = xAxis.clone().applyMatrix4(ocsInverse)

    this._position.copy(origin)
    this._normal.copy(normal)
    this._rotation = Math.atan2(localXAxis.y, localXAxis.x)
    this._scaleFactors.set(xAxis.length(), yAxis.length(), zAxis.length())

    this._attribs.forEach(attrib => attrib.transformBy(matrix))
    return this
  }

  /**
   * Returns the full property definition for this block reference entity, including
   * general group and geometry group.
   *
   * The geometry group exposes editable properties via {@link AcDbPropertyAccessor}
   * so the property palette can update the block reference in real-time.
   *
   * Each property is an {@link AcDbEntityRuntimeProperty}.
   */
  get properties(): AcDbEntityProperties {
    const props: AcDbEntityProperties = {
      type: this.type,
      groups: [
        this.getGeneralProperties(),
        {
          groupName: 'geometry',
          properties: [
            {
              name: 'annotative',
              type: 'boolean',
              editable: true,
              accessor: {
                get: () => this.annotative,
                set: (v: boolean) => {
                  this.annotative = v
                }
              }
            },
            {
              name: 'blockName',
              type: 'float',
              editable: false,
              accessor: {
                get: () => this._blockName
              }
            },
            {
              name: 'positionX',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.position.x,
                set: (v: number) => {
                  this.position.x = v
                }
              }
            },
            {
              name: 'positionY',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.position.y,
                set: (v: number) => {
                  this.position.y = v
                }
              }
            },
            {
              name: 'positionZ',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.position.z,
                set: (v: number) => {
                  this.position.z = v
                }
              }
            },
            {
              name: 'rotation',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.rotation,
                set: (v: number) => {
                  this.rotation = v
                }
              }
            },
            {
              name: 'scaleFactorsX',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.scaleFactors.x,
                set: (v: number) => {
                  this.scaleFactors.x = v
                }
              }
            },
            {
              name: 'scaleFactorsY',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.scaleFactors.y,
                set: (v: number) => {
                  this.scaleFactors.y = v
                }
              }
            },
            {
              name: 'scaleFactorsZ',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.scaleFactors.z,
                set: (v: number) => {
                  this.scaleFactors.z = v
                }
              }
            },
            {
              name: 'normalX',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.normal.x,
                set: (v: number) => {
                  this.normal.x = v
                }
              }
            },
            {
              name: 'normalY',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.normal.y,
                set: (v: number) => {
                  this.normal.y = v
                }
              }
            },
            {
              name: 'normalZ',
              type: 'float',
              editable: true,
              accessor: {
                get: () => this.normal.z,
                set: (v: number) => {
                  this.normal.z = v
                }
              }
            }
          ]
        }
      ]
    }
    if (this._attribs.size > 0) {
      const group: AcDbEntityPropertyGroup = {
        groupName: 'attribute',
        properties: []
      }
      props.groups.push(group)
      this._attribs.forEach(attr => {
        group.properties.push({
          name: attr.tag,
          type: 'string',
          editable: !attr.isConst,
          skipTranslation: true,
          accessor: {
            get: () => attr.textString,
            set: (v: string) => {
              attr.textString = v
            }
          }
        })
      })
    }
    return props
  }

  /**
   * Gets the geometric extents (bounding box) of this block reference.
   *
   * This method calculates the bounding box by transforming the geometric extents
   * of all entities in the referenced block according to the block reference's
   * position, rotation, and scale factors.
   *
   * @returns The bounding box that encompasses the entire block reference
   *
   * @example
   * ```typescript
   * const extents = blockRef.geometricExtents;
   * console.log(`Block bounds: ${extents.minPoint} to ${extents.maxPoint}`);
   * ```
   */
  get geometricExtents(): AcGeBox3d {
    const box = new AcGeBox3d()
    const blockTableRecord = this.drawableBlockTableRecord
    if (blockTableRecord != null) {
      const entities = blockTableRecord.newIterator()
      for (const entity of entities) {
        box.union(entity.geometricExtents)
      }
    }
    // Include extrusion so extents match drawn geometry for normals such as
    // (0,0,-1) from MIRROR (blockTransform alone leaves insertion X unmirrored).
    const matrix = this.getFullInsertionTransform()
    box.applyMatrix4(matrix)

    return box
  }

  /** @inheritdoc */
  override subGetIntersectCurves(): AcGeIntersectPrimitive[] {
    const blockTableRecord = this.drawableBlockTableRecord
    if (blockTableRecord == null) return []

    const primitives: AcGeIntersectPrimitive[] = []
    const cols = Math.max(1, this.columnCount)
    const rows = Math.max(1, this.rowCount)
    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        const localOffset = new AcGeMatrix3d().makeTranslation(
          col * this.columnSpacing,
          row * this.rowSpacing,
          0
        )
        const matrix = new AcGeMatrix3d().multiplyMatrices(
          this.getFullInsertionTransform(),
          localOffset
        )
        for (const entity of blockTableRecord.newIterator()) {
          primitives.push(
            ...acdbTransformIntersectPrimitives(
              entity.subGetIntersectCurves(),
              matrix
            )
          )
        }
      }
    }
    return primitives
  }

  /**
   * Resolves insertion / scale for the active CANNOSCALE when this INSERT is
   * annotative.
   */
  resolveAnnotativePresentation(): {
    position: AcGePoint3d
    rotation: number
    scaleFactors: AcGePoint3d
    preferred?: AcDbAnnotationScaleContext
    annotationScale?: AcDbAnnotationScaleDrawInfo
  } {
    const contexts = acdbGetAnnotationScaleContexts(this)
    const isAnnotative =
      contexts.length > 0 ||
      acdbIsAnnotativeObject(this) ||
      !!this.blockTableRecord?.annotative

    let position = this._position.clone()
    let rotation = this._rotation
    let scaleFactors = this._scaleFactors.clone()
    let preferred: AcDbAnnotationScaleContext | undefined
    let annotationScale: AcDbAnnotationScaleDrawInfo | undefined

    if (isAnnotative && contexts.length > 0) {
      preferred =
        acdbMatchAnnotationScaleContext(
          contexts,
          this.database?.cannoscale
        ) ??
        contexts.find(c => c.isDefault) ??
        contexts[0]
      annotationScale = acdbBuildAnnotationScaleDrawInfo(contexts, preferred)
      const ctx = preferred.contextData
      if (ctx instanceof AcDbBlkRefObjectContextData) {
        position = ctx.position.clone()
        rotation = ctx.rotation
        scaleFactors = new AcGePoint3d(ctx.scaleX, ctx.scaleY, ctx.scaleZ)
      }
    } else if (isAnnotative) {
      annotationScale = acdbResolveAnnotationScaleDrawInfo(this).annotationScale
    }

    return {
      position,
      rotation,
      scaleFactors,
      preferred,
      annotationScale
    }
  }

  /**
   * @inheritdoc
   */
  private attachAnnotationScaleDrawInfo(
    drawable: AcGiEntity | undefined,
    annotationScale?: AcDbAnnotationScaleDrawInfo
  ) {
    if (!drawable || !this.annotative) return drawable
    let info = annotationScale
    if (!info) {
      info = acdbResolveAnnotationScaleDrawInfo(this).annotationScale
    }
    if (!info) {
      info = {
        drawnScaleFactor: 1,
        supportedScaleFactors: [1],
        supportedScaleNames: []
      }
    }
    const userData = (drawable.userData ??= {}) as {
      annotationScale?: AcDbAnnotationScaleDrawInfo
    }
    userData.annotationScale = info
    return drawable
  }

  subWorldDraw(renderer: AcGiRenderer) {
    const presentation = this.resolveAnnotativePresentation()
    this._drawPresentation = presentation
    try {
      return this.subWorldDrawWithPresentation(renderer, presentation)
    } finally {
      this._drawPresentation = undefined
    }
  }

  private subWorldDrawWithPresentation(
    renderer: AcGiRenderer,
    presentation: {
      annotationScale?: AcDbAnnotationScaleDrawInfo
    }
  ) {
    const blockTableRecord = this.drawableBlockTableRecord
    if (blockTableRecord != null) {
      const attribs: AcGiEntity[] = []
      this._attribs.forEach(attrib => {
        if (!attrib.isInvisible) {
          const result = attrib.worldDraw(renderer)
          if (result) attribs.push(result)
        }
      })
      const cols = Math.max(1, this.columnCount)
      const rows = Math.max(1, this.rowCount)
      if (cols === 1 && rows === 1) {
        return this.attachAnnotationScaleDrawInfo(
          AcDbRenderingCache.instance.draw(
            renderer,
            blockTableRecord,
            this.resolvedColor,
            attribs,
            true,
            this.blockTransform,
            this._normal
          ),
          presentation.annotationScale
        )
      }
      const instances: AcGiEntity[] = []
      for (let row = 0; row < rows; row++) {
        for (let col = 0; col < cols; col++) {
          const localOffset = new AcGeMatrix3d().makeTranslation(
            col * this.columnSpacing,
            row * this.rowSpacing,
            0
          )
          const matrix = new AcGeMatrix3d().multiplyMatrices(
            this.blockTransform,
            localOffset
          )
          const drawn = AcDbRenderingCache.instance.draw(
            renderer,
            blockTableRecord,
            this.resolvedColor,
            col === 0 && row === 0 ? attribs : [],
            true,
            matrix,
            this._normal
          )
          if (drawn) instances.push(drawn)
        }
      }
      return this.attachAnnotationScaleDrawInfo(
        renderer.group(instances),
        presentation.annotationScale
      )
    } else {
      const block = renderer.group([])
      return block
    }
  }

  /**
   * Writes this INSERT entity to DXF, including its attribute sequence.
   *
   * The output order follows DXF conventions:
   *
   * 1. Emit INSERT common/object fields via the base implementation
   * 2. Emit one `ATTRIB` section for each attached attribute
   * 3. Emit a terminating `SEQEND` record when attributes were written
   *
   * @param filer - DXF output writer.
   * @param allXdata - When true, emits all XData attached to this entity.
   * @returns The current entity instance.
   */
  override dxfOut(filer: AcDbDxfFiler, allXdata = false) {
    super.dxfOut(filer, allXdata)
    let hasAttributes = false
    for (const attrib of this.attributeIterator()) {
      hasAttributes = true
      filer.writeStart('ATTRIB')
      attrib.dxfOut(filer, allXdata)
    }
    if (hasAttributes) {
      filer.writeStart('SEQEND')
      filer.writeHandle(5, this.database.generateHandle())
      filer.writeObjectId(330, this.objectId)
      filer.writeSubclassMarker('AcDbEntity')
    }
    return this
  }

  /**
   * Collects object snap points from all entities in this block reference.
   */
  private collectBlockOsnapPoints(
    osnapMode: AcDbOsnapMode,
    pickPoint: AcGePoint3dLike,
    lastPoint: AcGePoint3dLike,
    snapPoints: AcGePoint3dLike[],
    parentInsertionMat: AcGeMatrix3d
  ) {
    const blockTableRecord = this.drawableBlockTableRecord
    if (!blockTableRecord) return

    const thisInsertionMat = new AcGeMatrix3d().multiplyMatrices(
      parentInsertionMat,
      this.getFullInsertionTransform()
    )
    const inverseMat = thisInsertionMat.clone().invert()
    const localPickPoint = new AcGePoint3d(pickPoint).applyMatrix4(inverseMat)
    const localLastPoint = new AcGePoint3d(lastPoint).applyMatrix4(inverseMat)
    const candidates: AcGePoint3d[] = []

    for (const entity of blockTableRecord.newIterator()) {
      const localSnapPoints: AcGePoint3d[] = []
      if (entity instanceof AcDbBlockReference) {
        entity.subGetOsnapPoints(
          osnapMode,
          pickPoint,
          lastPoint,
          localSnapPoints,
          undefined,
          thisInsertionMat
        )
        // Avoid push(...array): large blocks exceed V8's apply argument limit.
        for (let i = 0; i < localSnapPoints.length; i++) {
          candidates.push(localSnapPoints[i])
        }
        continue
      }

      entity.subGetOsnapPoints(
        osnapMode,
        localPickPoint,
        localLastPoint,
        localSnapPoints,
        undefined,
        thisInsertionMat
      )
      localSnapPoints.forEach(point =>
        candidates.push(new AcGePoint3d(point).applyMatrix4(thisInsertionMat))
      )
    }

    if (candidates.length === 0) return

    if (
      osnapMode === AcDbOsnapMode.Nearest ||
      osnapMode === AcDbOsnapMode.Perpendicular ||
      osnapMode === AcDbOsnapMode.Tangent
    ) {
      const nearest = acdbPickNearestOsnapPoint(pickPoint, candidates)
      if (nearest) snapPoints.push(nearest)
    } else {
      // Avoid push(...array): large blocks exceed V8's apply argument limit.
      for (let i = 0; i < candidates.length; i++) {
        snapPoints.push(candidates[i])
      }
    }
  }

  /**
   * Recursively resolves object snap points from nested block references.
   *
   * This helper traverses child entities under the current block reference to
   * locate the sub-entity identified by `gsMark`. When found, it converts
   * pick/last points into the target local space, asks that entity for snap
   * points, then maps results back to the caller space as needed.
   *
   * When the same definition entity appears under more than one nested INSERT,
   * spatial-index ids may carry a `#n` suffix. That suffix is treated as a
   * 0-based occurrence index in depth-first leaf order (matching
   * uniquifySpatialItemIds in cad-simple-viewer) so the instance under the
   * cursor is selected instead of the first DFS match (#745).
   *
   * The method tracks visited block references to prevent infinite recursion in
   * cyclic block graphs.
   *
   * @param osnapMode - Requested osnap mode.
   * @param pickPoint - User pick point in caller space.
   * @param lastPoint - Previous point in caller space.
   * @param snapPoints - Output collection to append resolved snap points into.
   * @param gsMark - Object id of the target sub-entity, optionally with `#n`.
   * @param parentInsertionMat - Cumulative transform from ancestor INSERTs.
   * @param visitedRefs - Internal recursion guard set.
   * @param remainingOccurrence - Internal: how many earlier matches to skip.
   * @returns Remaining occurrence count after the search, or `-1` when found.
   */
  private subEntityGetOsnapPoints(
    osnapMode: AcDbOsnapMode,
    pickPoint: AcGePoint3dLike,
    lastPoint: AcGePoint3dLike,
    snapPoints: AcGePoint3dLike[],
    gsMark: AcDbObjectId,
    parentInsertionMat: AcGeMatrix3d,
    visitedRefs = new Set<AcDbObjectId>(),
    remainingOccurrence?: number
  ): number {
    const parsed = acdbParseGsMark(gsMark)
    const targetId = parsed.objectId
    let remaining =
      remainingOccurrence === undefined
        ? parsed.occurrence
        : remainingOccurrence

    // Avoid an infinite loop when a matched INSERT is asked for its own id.
    if (targetId === this.objectId || visitedRefs.has(this.objectId)) {
      return remaining
    }

    visitedRefs.add(this.objectId)

    try {
      const blockTableRecord = this.drawableBlockTableRecord
      if (blockTableRecord == null) return remaining

      const thisInsertionMat = new AcGeMatrix3d().multiplyMatrices(
        parentInsertionMat,
        this.getFullInsertionTransform()
      )
      const inverseInsertionMat = thisInsertionMat.clone().invert()
      const localPickPoint = new AcGePoint3d(pickPoint).applyMatrix4(
        inverseInsertionMat
      )
      const localLastPoint = new AcGePoint3d(lastPoint).applyMatrix4(
        inverseInsertionMat
      )

      for (const entity of blockTableRecord.newIterator()) {
        if (entity.objectId === targetId) {
          if (remaining > 0) {
            remaining -= 1
            continue
          }

          const localSnapPoints: AcGePoint3d[] = []
          entity.subGetOsnapPoints(
            osnapMode,
            localPickPoint,
            localLastPoint,
            localSnapPoints,
            targetId,
            thisInsertionMat
          )

          if (entity instanceof AcDbBlockReference) {
            localSnapPoints.forEach(point => {
              snapPoints.push(point.clone())
            })
          } else {
            localSnapPoints.forEach(point => {
              snapPoints.push(
                new AcGePoint3d(point).applyMatrix4(thisInsertionMat)
              )
            })
          }

          return -1
        }

        if (entity instanceof AcDbBlockReference) {
          const nestedRemaining = entity.subEntityGetOsnapPoints(
            osnapMode,
            pickPoint,
            lastPoint,
            snapPoints,
            gsMark,
            thisInsertionMat,
            visitedRefs,
            remaining
          )
          if (nestedRemaining < 0) return -1
          remaining = nestedRemaining
        }
      }

      return remaining
    } finally {
      visitedRefs.delete(this.objectId)
    }
  }

  /**
   * Computes the insertion osnap point in caller space.
   *
   * The insertion point is the block definition base point transformed by the
   * full cumulative insertion transform (ancestor transform + this reference's
   * own full insertion transform including extrusion).
   *
   * @param parentInsertionMat - Cumulative transform from parent block references.
   * @returns The insertion point in the caller coordinate space.
   */
  private getInsertionPoint(parentInsertionMat: AcGeMatrix3d) {
    const blockBasePoint =
      this.drawableBlockTableRecord?.origin ?? AcGePoint3d.ORIGIN
    const insertionMat = new AcGeMatrix3d().multiplyMatrices(
      parentInsertionMat,
      this.getFullInsertionTransform()
    )
    return new AcGePoint3d(blockBasePoint).applyMatrix4(insertionMat)
  }

  /**
   * Builds the full INSERT transform for this block reference.
   *
   * {@link blockTransform} contains translation/rotation/scale in OCS only.
   * This method prepends the extrusion transform derived from {@link normal} so
   * the returned matrix maps block-local geometry all the way into WCS.
   *
   * @returns Full block insertion transform including OCS extrusion.
   */
  private getFullInsertionTransform() {
    const extrusion = new AcGeMatrix3d().setFromExtrusionDirection(this._normal)
    return new AcGeMatrix3d().multiplyMatrices(extrusion, this.blockTransform)
  }

  /**
   * Writes DXF fields for this object.
   *
   * @param filer - DXF output writer.
   * @returns The instance (for chaining).
   */
  override dxfOutFields(filer: AcDbDxfFiler) {
    super.dxfOutFields(filer)
    filer.writeSubclassMarker('AcDbBlockReference')
    filer.writePoint3d(10, this.position)
    filer.writeString(2, this.blockName)
    filer.writeDouble(41, this.scaleFactors.x)
    filer.writeDouble(42, this.scaleFactors.y)
    filer.writeDouble(43, this.scaleFactors.z)
    filer.writeAngle(50, this.rotation)
    if (this.columnCount > 1) {
      filer.writeInt16(70, this.columnCount)
    }
    if (this.rowCount > 1) {
      filer.writeInt16(71, this.rowCount)
    }
    if (this.columnSpacing !== 0) {
      filer.writeDouble(44, this.columnSpacing)
    }
    if (this.rowSpacing !== 0) {
      filer.writeDouble(45, this.rowSpacing)
    }
    filer.writeVector3d(210, this.normal)
    return this
  }

  override dxfInFields(filer: AcDbDxfFiler): this {
    super.dxfInFields(filer)
    filer.atSubclassData('AcDbBlockReference')

    let x = this.position.x
    let y = this.position.y
    let z = this.position.z
    let sx = this.scaleFactors.x
    let sy = this.scaleFactors.y
    let sz = this.scaleFactors.z
    let rotDeg = AcGeMathUtil.radToDeg(this.rotation)
    let nx = this.normal.x
    let ny = this.normal.y
    let nz = this.normal.z
    let columnCount = this.columnCount
    let rowCount = this.rowCount
    let columnSpacing = this.columnSpacing
    let rowSpacing = this.rowSpacing

    const commit = () => {
      this.position = new AcGePoint3d(x, y, z)
      this.scaleFactors = new AcGePoint3d(sx, sy, sz)
      this.rotation = AcGeMathUtil.degToRad(rotDeg)
      this.normal.copy(new AcGeVector3d(nx, ny, nz))
      this.columnCount = columnCount > 0 ? columnCount : 1
      this.rowCount = rowCount > 0 ? rowCount : 1
      this.columnSpacing = columnSpacing
      this.rowSpacing = rowSpacing
    }

    while (!filer.atEndOfObject && !filer.atEof && !filer.atExtendedData) {
      const item = filer.readItem()
      if (!item) break
      const code = Number(item.code)
      const n = Number(item.value)
      switch (code) {
        case 10:
          x = n
          break
        case 20:
          y = n
          break
        case 30:
          z = n
          break
        case 2:
          this.blockName = String(item.value)
          break
        case 41:
          sx = n
          break
        case 42:
          sy = n
          break
        case 43:
          sz = n
          break
        case 44:
          columnSpacing = n
          break
        case 45:
          rowSpacing = n
          break
        case 50:
          rotDeg = n
          break
        case 66:
          // Attributes-follow flag — ATTRIB entities are streamed separately.
          break
        case 70:
          columnCount = n
          break
        case 71:
          rowCount = n
          break
        case 210:
          nx = n
          break
        case 220:
          ny = n
          break
        case 230:
          nz = n
          break
        case 100:
          // Next subclass (e.g. AcDbTable) — hand off.
          filer.pushBackItem(item)
          commit()
          return this
        default:
          // Unknown optional INSERT codes — keep scanning within this subclass.
          break
      }
    }

    commit()
    return this
  }
}
