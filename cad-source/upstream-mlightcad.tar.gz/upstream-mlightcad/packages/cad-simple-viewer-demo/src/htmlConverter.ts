import {
  type AcApHtmlExpiryDays,
  type AcApHtmlExportFormat,
  AcApHtmlSnapshotBuilder,
  ACEX_DEFAULT_CHUNK_SIZE_MIB,
  ACEX_MAX_CHUNK_SIZE_MIB,
  ACEX_MIN_CHUNK_SIZE_MIB,
  acexChunkSizeMiBToBytes,
  type AcExHtmlBackground,
  type AcExInitialViewMode,
  type AcExViewerMode,
  applyAcExHtmlBackground,
  buildAcExPackage,
  captureAcApHtmlViewState,
  clampAcApHtmlChunkSizeMiB,
  encodeSnapshot,
  packHtml,
  protectAcExHtmlEncodedSnapshot,
  resolveAcApHtmlExpiresAt,
  resolveAcApHtmlExportOptions,
  resolveAcApHtmlPackageBuildOptions,
  zipAcExPackageFiles
} from '@mlightcad/cad-html-plugin'
import {
  AcApDocManager,
  type AcApOpenDatabaseOptions,
  AcApOpenViewMode,
  AcEdOpenMode,
  AcTrView2d,
  getDrawingExportBaseName,
  LIBREDWG_PARSER_WORKER_FILE,
  MTEXT_RENDERER_WORKER_FILE,
  resolveExportDownloadName
} from '@mlightcad/cad-simple-viewer'
import { log } from '@mlightcad/data-model'

import { registerLibreDwgConverter } from './registerLibreDwg'

const SAMPLE_DRAWING_URL =
  'https://cdn.jsdelivr.net/gh/mlightcad/cad-data@main/data/canteen.dwg'
const SAMPLE_DRAWING_NAME = 'canteen.dwg'
const VIEWER_RUNTIME_URL = './viewer-runtime.iife.js'
const CAD_DATA_BASE_URL = 'https://cdn.jsdelivr.net/gh/mlightcad/cad-data@main/'

const OPEN_OPTIONS: AcApOpenDatabaseOptions = {
  minimumChunkSize: 1000,
  mode: AcEdOpenMode.Read,
  progressiveRendering: false
}

type ConverterTab = 'data' | 'display' | 'security'

const MESSAGES = {
  invalidType: 'Please choose a .dwg or .dxf file.',
  ready: 'Selected {name}. Adjust options, then convert.',
  opening: 'Opening {name}…',
  convertingHtml: 'Converting {name} to HTML…',
  convertingZip: 'Converting {name} to multi-file package…',
  convertedHtml: 'Download started for {name}.html',
  convertedZip: 'Download started for {name}.zip',
  openFailed: 'Failed to open {name}.',
  convertFailed: 'Conversion failed: {error}',
  expiryCustomRequired: 'Please select a custom expiry date and time.',
  expiryCustomPast: 'The custom expiry must be in the future.',
  copyPasswordSuccess: 'Password copied to the clipboard.',
  copyPasswordFailed: 'Unable to copy the password to the clipboard.',
  runtimeMissing:
    'Failed to load viewer-runtime.iife.js. Rebuild the example package and refresh.'
} as const

const CONVERT_BUTTON_LABELS = {
  single: 'Convert and download HTML',
  multi: 'Convert and download ZIP'
} as const

const PASSWORD_CHARS =
  'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789'

const EXPIRY_DAY_VALUES = new Set<string>(['1', '7', '30', 'never', 'custom'])

function format(template: string, vars: Record<string, string>): string {
  return template.replace(/\{(\w+)\}/g, (_, key: string) => vars[key] ?? '')
}

function isCadFileName(name: string): boolean {
  const lower = name.toLowerCase()
  return lower.endsWith('.dwg') || lower.endsWith('.dxf')
}

function drawingBaseName(name: string): string {
  return name.replace(/\.(dwg|dxf)$/i, '')
}

class HtmlConverterApp {
  private readonly container: HTMLDivElement
  private readonly hiddenViewer: HTMLElement
  private readonly converterCard: HTMLElement
  private readonly dropZone: HTMLLabelElement
  private readonly fileInput: HTMLInputElement
  private readonly fileNameEl: HTMLElement
  private readonly statusEl: HTMLElement
  private readonly progressOverlay: HTMLElement
  private readonly progressMessage: HTMLElement
  private readonly convertButton: HTMLButtonElement
  private readonly exportInvisibleLayers: HTMLInputElement
  private readonly exportLayouts: HTMLInputElement
  private readonly packageOptions: HTMLElement | null
  private readonly chunkSizeMiB: HTMLInputElement | null
  private readonly compressChunks: HTMLInputElement | null
  private readonly customExpiresAt: HTMLInputElement
  private readonly exportPassword: HTMLInputElement
  private readonly copyPasswordButton: HTMLButtonElement
  private initialized = false
  private busy = false
  private currentName = ''
  private pendingFile: File | undefined
  private pendingSample = false
  private runtimePromise: Promise<string> | undefined
  private downloadUrl = ''

  constructor() {
    this.container = document.getElementById('cad-container') as HTMLDivElement
    this.hiddenViewer = document.getElementById('hiddenViewer') as HTMLElement
    this.converterCard = document.getElementById('converterCard') as HTMLElement
    this.dropZone = document.getElementById('dropZone') as HTMLLabelElement
    this.fileInput = document.getElementById('fileInput') as HTMLInputElement
    this.fileNameEl = document.getElementById('fileName') as HTMLElement
    this.statusEl = document.getElementById('status') as HTMLElement
    this.progressOverlay = document.getElementById(
      'progressOverlay'
    ) as HTMLElement
    this.progressMessage = document.getElementById(
      'progressMessage'
    ) as HTMLElement
    this.convertButton = document.getElementById(
      'convertButton'
    ) as HTMLButtonElement
    this.exportInvisibleLayers = document.getElementById(
      'exportInvisibleLayers'
    ) as HTMLInputElement
    this.exportLayouts = document.getElementById(
      'exportLayouts'
    ) as HTMLInputElement
    this.packageOptions = document.getElementById('packageOptions')
    this.chunkSizeMiB = document.getElementById(
      'chunkSizeMiB'
    ) as HTMLInputElement | null
    this.compressChunks = document.getElementById(
      'compressChunks'
    ) as HTMLInputElement | null
    this.customExpiresAt = document.getElementById(
      'customExpiresAt'
    ) as HTMLInputElement
    this.exportPassword = document.getElementById(
      'exportPassword'
    ) as HTMLInputElement
    this.copyPasswordButton = document.getElementById(
      'copyPassword'
    ) as HTMLButtonElement

    this.bindEvents()
    this.initSecurityDefaults()
    this.initPackageDefaults()
  }

  private bindEvents() {
    document.getElementById('sampleButton')?.addEventListener('click', () => {
      this.selectSample()
    })
    this.fileInput.addEventListener('change', () => {
      const file = this.fileInput.files?.[0]
      this.fileInput.value = ''
      if (file) {
        this.selectFile(file)
      }
    })
    this.convertButton.addEventListener('click', () => {
      void this.convert()
    })

    this.dropZone.addEventListener('dragover', event => {
      event.preventDefault()
      this.dropZone.classList.add('drag')
    })
    this.dropZone.addEventListener('dragleave', () => {
      this.dropZone.classList.remove('drag')
    })
    this.dropZone.addEventListener('drop', event => {
      event.preventDefault()
      this.dropZone.classList.remove('drag')
      const file = event.dataTransfer?.files?.[0]
      if (file) {
        this.selectFile(file)
      }
    })

    document
      .querySelectorAll<HTMLInputElement>('.choice input[type="radio"]')
      .forEach(input => {
        input.addEventListener('change', () => {
          this.syncChoiceSelection()
          if (input.name === 'exportFormat') {
            this.syncExportFormatUi()
          }
        })
      })
    this.syncChoiceSelection()
    this.syncExportFormatUi()

    document.querySelectorAll<HTMLButtonElement>('.tab').forEach(tab => {
      tab.addEventListener('click', () => {
        const name = tab.dataset.tab
        if (name !== 'data' && name !== 'display' && name !== 'security') {
          return
        }
        if (name === 'security' && this.readExportFormat() === 'multi') {
          return
        }
        this.activateTab(name)
      })
    })

    document
      .querySelectorAll<HTMLInputElement>('input[name="expiryDays"]')
      .forEach(input => {
        input.addEventListener('change', () => this.syncExpirySelection())
      })
    this.syncExpirySelection()

    document.getElementById('generatePassword')?.addEventListener('click', () => {
      this.generatePassword()
    })
    this.copyPasswordButton.addEventListener('click', () => {
      void this.copyPassword()
    })
    this.exportPassword.addEventListener('input', () => {
      this.syncCopyPasswordButton()
    })
    this.syncCopyPasswordButton()

    document.getElementById('togglePassword')?.addEventListener('click', () => {
      this.togglePasswordVisibility()
    })
  }

  private activateTab(tab: ConverterTab) {
    document.querySelectorAll<HTMLButtonElement>('.tab').forEach(button => {
      const isActive = button.dataset.tab === tab
      button.classList.toggle('is-active', isActive)
      button.setAttribute('aria-selected', isActive ? 'true' : 'false')
      button.tabIndex = isActive ? 0 : -1
    })
    const panels: Record<ConverterTab, HTMLElement | null> = {
      data: document.getElementById('panelData'),
      display: document.getElementById('panelDisplay'),
      security: document.getElementById('panelSecurity')
    }
    ;(Object.keys(panels) as ConverterTab[]).forEach(name => {
      const panel = panels[name]
      if (panel) {
        panel.hidden = name !== tab
      }
    })
  }

  private readExportFormat(): AcApHtmlExportFormat {
    const raw = (
      document.querySelector(
        'input[name="exportFormat"]:checked'
      ) as HTMLInputElement | null
    )?.value
    return raw === 'multi' ? 'multi' : 'single'
  }

  private syncExportFormatUi() {
    const isMulti = this.readExportFormat() === 'multi'
    const securityTab = document.getElementById(
      'tabSecurity'
    ) as HTMLButtonElement | null
    const securityHint = document.getElementById('securitySingleOnlyHint')
    const securityControls = document.getElementById('securityControls')
    const securityPanel = document.getElementById('panelSecurity')

    if (securityTab) {
      securityTab.classList.toggle('is-disabled', isMulti)
      securityTab.setAttribute('aria-disabled', isMulti ? 'true' : 'false')
      if (isMulti) {
        securityTab.tabIndex = -1
      }
    }
    if (securityHint) {
      securityHint.hidden = !isMulti
    }
    if (securityControls) {
      securityControls.hidden = isMulti
    }
    if (securityPanel) {
      securityPanel.classList.toggle('is-disabled', isMulti)
    }
    if (this.packageOptions) {
      this.packageOptions.hidden = !isMulti
    }
    if (isMulti) {
      const activeTab = document.querySelector('.tab.is-active') as
        | HTMLButtonElement
        | null
      if (activeTab?.dataset.tab === 'security') {
        this.activateTab('data')
      }
    }

    this.convertButton.textContent = isMulti
      ? CONVERT_BUTTON_LABELS.multi
      : CONVERT_BUTTON_LABELS.single
  }

  private initPackageDefaults() {
    if (this.chunkSizeMiB) {
      this.chunkSizeMiB.min = String(ACEX_MIN_CHUNK_SIZE_MIB)
      this.chunkSizeMiB.max = String(ACEX_MAX_CHUNK_SIZE_MIB)
      this.chunkSizeMiB.value = String(ACEX_DEFAULT_CHUNK_SIZE_MIB)
    }
    if (this.compressChunks) {
      this.compressChunks.checked = true
    }
  }

  private readChunkSizeMiB(): number {
    const raw = Number(this.chunkSizeMiB?.value ?? ACEX_DEFAULT_CHUNK_SIZE_MIB)
    return clampAcApHtmlChunkSizeMiB(raw)
  }

  private initSecurityDefaults() {
    this.customExpiresAt.value = this.toDateTimeLocalValue(
      this.defaultCustomExpiresAt()
    )
    this.customExpiresAt.min = this.toDateTimeLocalValue(new Date())
  }

  private defaultCustomExpiresAt(): Date {
    const date = new Date()
    date.setDate(date.getDate() + 1)
    date.setSeconds(0, 0)
    return date
  }

  private toDateTimeLocalValue(date: Date): string {
    const pad = (n: number) => String(n).padStart(2, '0')
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`
  }

  private syncChoiceSelection() {
    document.querySelectorAll<HTMLLabelElement>('.choice').forEach(label => {
      const input = label.querySelector('input[type="radio"]')
      label.classList.toggle(
        'is-selected',
        Boolean(input && (input as HTMLInputElement).checked)
      )
    })
  }

  private syncExpirySelection() {
    document
      .querySelectorAll<HTMLLabelElement>('.expiry-option')
      .forEach(label => {
        const input = label.querySelector('input[type="radio"]')
        label.classList.toggle(
          'is-selected',
          Boolean(input && (input as HTMLInputElement).checked)
        )
      })
    const selected = (
      document.querySelector(
        'input[name="expiryDays"]:checked'
      ) as HTMLInputElement | null
    )?.value
    this.customExpiresAt.classList.toggle(
      'is-visible',
      selected === 'custom'
    )
  }

  private syncCopyPasswordButton() {
    this.copyPasswordButton.disabled = this.exportPassword.value.trim().length === 0
  }

  private togglePasswordVisibility() {
    const toggle = document.getElementById(
      'togglePassword'
    ) as HTMLButtonElement | null
    const show = this.exportPassword.type === 'password'
    this.exportPassword.type = show ? 'text' : 'password'
    if (!toggle) {
      return
    }
    toggle.classList.toggle('is-visible', show)
    toggle.setAttribute('aria-pressed', show ? 'true' : 'false')
    toggle.setAttribute(
      'aria-label',
      show ? 'Hide password' : 'Show password'
    )
    toggle.title = show ? 'Hide password' : 'Show password'
  }

  private generatePassword() {
    const bytes = new Uint8Array(12)
    crypto.getRandomValues(bytes)
    this.exportPassword.value = Array.from(
      bytes,
      byte => PASSWORD_CHARS[byte % PASSWORD_CHARS.length]!
    ).join('')
    this.syncCopyPasswordButton()
  }

  private async copyPassword() {
    const password = this.exportPassword.value.trim()
    if (!password) {
      return
    }
    try {
      await navigator.clipboard.writeText(password)
      this.setStatus(MESSAGES.copyPasswordSuccess)
    } catch {
      this.setStatus(MESSAGES.copyPasswordFailed, true)
    }
  }

  private setStatus(message: string, isError = false) {
    this.statusEl.textContent = message
    this.statusEl.classList.toggle('error', isError)
    this.progressMessage.textContent = message
  }

  private hasPendingSource(): boolean {
    return this.pendingSample || this.pendingFile != null
  }

  private setBusy(busy: boolean, message?: string) {
    this.busy = busy
    this.convertButton.disabled = busy || !this.hasPendingSource()
    document.getElementById('sampleButton')?.toggleAttribute('disabled', busy)
    this.fileInput.disabled = busy
    this.converterCard.classList.toggle('is-busy', busy)
    this.progressOverlay.hidden = !busy
    this.progressOverlay.setAttribute('aria-busy', busy ? 'true' : 'false')
    if (message) {
      this.setStatus(message)
    }
  }

  private clearDownloadUrl() {
    if (this.downloadUrl) {
      URL.revokeObjectURL(this.downloadUrl)
      this.downloadUrl = ''
    }
  }

  private selectFile(file: File) {
    if (this.busy) {
      return
    }
    if (!isCadFileName(file.name)) {
      this.setStatus(MESSAGES.invalidType, true)
      return
    }

    this.pendingFile = file
    this.pendingSample = false
    this.markSelected(file.name)
  }

  private selectSample() {
    if (this.busy) {
      return
    }
    this.pendingFile = undefined
    this.pendingSample = true
    this.markSelected(SAMPLE_DRAWING_NAME)
  }

  private markSelected(name: string) {
    this.currentName = name
    this.fileNameEl.textContent = name
    this.convertButton.disabled = this.busy
    this.clearDownloadUrl()
    this.setStatus(format(MESSAGES.ready, { name }))
  }

  private async initialize() {
    if (this.initialized) {
      return
    }

    const dwgParserUrl = `./workers/${LIBREDWG_PARSER_WORKER_FILE}`
    registerLibreDwgConverter(dwgParserUrl)
    AcApDocManager.createInstance({
      container: this.container,
      busyIndicatorHost: this.hiddenViewer,
      autoResize: true,
      baseUrl: CAD_DATA_BASE_URL,
      builtinOpenFileDialog: false,
      useMainThreadDraw: false,
      openDocumentDefaults: OPEN_OPTIONS,
      webworkerFileUrls: {
        mtextRender: `./workers/${MTEXT_RENDERER_WORKER_FILE}`,
        dwgParser: dwgParserUrl
      }
    })
    this.runtimePromise = this.loadViewerRuntime()
    this.initialized = true
  }

  private viewerRuntimeUrl(): string {
    return new URL(VIEWER_RUNTIME_URL, window.location.href).href
  }

  private async loadViewerRuntime(): Promise<string> {
    const runtimeUrl = this.viewerRuntimeUrl()
    const response = await fetch(runtimeUrl)
    if (!response.ok) {
      throw new Error(
        `${MESSAGES.runtimeMissing} (${response.status} ${runtimeUrl})`
      )
    }
    return response.text()
  }

  private readFile(file: File): Promise<ArrayBuffer> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onload = () => resolve(reader.result as ArrayBuffer)
      reader.onerror = () => reject(reader.error)
      reader.readAsArrayBuffer(file)
    })
  }

  private openOptions(): AcApOpenDatabaseOptions {
    const initialView = this.readExportOptions().initialView
    return {
      ...OPEN_OPTIONS,
      openViewMode:
        initialView === 'current'
          ? AcApOpenViewMode.Saved
          : AcApOpenViewMode.Extents
    }
  }

  private async openPendingDrawing(): Promise<boolean> {
    const openOptions = this.openOptions()
    if (this.pendingSample) {
      return AcApDocManager.instance.openUrl(SAMPLE_DRAWING_URL, openOptions)
    }
    if (!this.pendingFile) {
      return false
    }
    const content = await this.readFile(this.pendingFile)
    return AcApDocManager.instance.openDocument(
      this.pendingFile.name,
      content,
      openOptions
    )
  }

  private readExpiryDays(): AcApHtmlExpiryDays {
    const raw = (
      document.querySelector(
        'input[name="expiryDays"]:checked'
      ) as HTMLInputElement | null
    )?.value
    if (!raw || !EXPIRY_DAY_VALUES.has(raw)) {
      return 'never'
    }
    if (raw === '1' || raw === '7' || raw === '30') {
      return Number(raw) as 1 | 7 | 30
    }
    return raw as 'never' | 'custom'
  }

  private readCustomExpiresAt(): number | null {
    const value = this.customExpiresAt.value
    if (!value) {
      return null
    }
    const time = new Date(value).getTime()
    return Number.isNaN(time) ? null : time
  }

  private validateSecurityOptions(
    options: ReturnType<typeof resolveAcApHtmlExportOptions>
  ): string | null {
    if (options.exportFormat === 'multi' || options.expiryDays !== 'custom') {
      return null
    }
    if (options.expiresAt == null) {
      return MESSAGES.expiryCustomRequired
    }
    if (options.expiresAt <= Date.now()) {
      return MESSAGES.expiryCustomPast
    }
    return null
  }

  private readExportOptions(): ReturnType<typeof resolveAcApHtmlExportOptions> {
    const exportFormat = this.readExportFormat()
    const viewerMode = (
      document.querySelector(
        'input[name="viewerMode"]:checked'
      ) as HTMLInputElement | null
    )?.value as AcExViewerMode | undefined
    const initialView = (
      document.querySelector(
        'input[name="initialView"]:checked'
      ) as HTMLInputElement | null
    )?.value as AcExInitialViewMode | undefined
    const background = (
      document.querySelector(
        'input[name="background"]:checked'
      ) as HTMLInputElement | null
    )?.value as AcExHtmlBackground | undefined
    const expiryDays = this.readExpiryDays()
    return resolveAcApHtmlExportOptions({
      exportFormat,
      exportInvisibleLayers: this.exportInvisibleLayers.checked,
      exportLayouts: this.exportLayouts.checked,
      background: background ?? 'black',
      initialView: initialView ?? 'fit',
      viewerMode: viewerMode ?? 'measure',
      expiryDays: exportFormat === 'multi' ? 'never' : expiryDays,
      expiresAt:
        exportFormat === 'single' && expiryDays === 'custom'
          ? this.readCustomExpiresAt()
          : null,
      password:
        exportFormat === 'single'
          ? this.exportPassword.value.trim() || undefined
          : undefined,
      ...(exportFormat === 'multi'
        ? {
            maxChunkBytes: acexChunkSizeMiBToBytes(this.readChunkSizeMiB()),
            compressChunks: this.compressChunks?.checked !== false
          }
        : {})
    })
  }

  private triggerDownload(
    data: string | Uint8Array,
    downloadName: string,
    mimeType: string
  ) {
    this.clearDownloadUrl()
    // Copy Uint8Array so Blob gets an ArrayBuffer-backed view (TS DOM typings).
    const blobPart =
      typeof data === 'string'
        ? data
        : (() => {
            const copy = new Uint8Array(data.byteLength)
            copy.set(data)
            return copy
          })()
    const blob = new Blob([blobPart], { type: mimeType })
    this.downloadUrl = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = this.downloadUrl
    link.download = downloadName
    link.rel = 'noopener'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  private async buildExport(
    fileName: string
  ): Promise<{ downloadName: string; mimeType: string; data: string | Uint8Array }> {
    const view = AcApDocManager.instance.curView as AcTrView2d
    if (
      !view?.cadScene ||
      typeof view.ensureEntitiesConvertedForExport !== 'function'
    ) {
      throw new Error(
        'CAD scene is not available. Open a drawing before exporting to HTML.'
      )
    }

    const resolved = this.readExportOptions()
    await view.ensureEntitiesConvertedForExport({
      includeInvisibleLayers: resolved.exportInvisibleLayers,
      includeLayouts: resolved.exportLayouts
    })

    const document = AcApDocManager.instance.curDocument
    const baseName = getDrawingExportBaseName(fileName)
    const snapshot = await new AcApHtmlSnapshotBuilder().buildAsync(
      view.cadScene,
      document.database,
      {
        title: baseName,
        background: view.backgroundColor,
        exportInvisibleLayers: resolved.exportInvisibleLayers,
        exportLayouts: resolved.exportLayouts,
        initialView: resolved.initialView,
        viewerMode: resolved.viewerMode,
        viewState:
          resolved.initialView === 'current' &&
          (resolved.exportLayouts ||
            view.activeLayoutBtrId === view.modelSpaceBtrId)
            ? captureAcApHtmlViewState(view)
            : undefined,
        canvasAspectRatio: view.width / Math.max(view.height, 1)
      }
    )
    // Live geometry is baked for the canvas on screen. Remap ACI 7 onto the
    // chosen background; `'space'` uses black in model and white on paper.
    applyAcExHtmlBackground(
      snapshot,
      view.backgroundColor,
      resolved.background
    )

    const viewerRuntime = await (this.runtimePromise ?? this.loadViewerRuntime())

    if (resolved.exportFormat === 'multi') {
      const pkg = buildAcExPackage(snapshot, {
        viewerRuntime,
        baseName,
        ...resolveAcApHtmlPackageBuildOptions(resolved)
      })
      return {
        downloadName: resolveExportDownloadName(fileName, 'zip'),
        mimeType: 'application/zip',
        data: zipAcExPackageFiles(pkg)
      }
    }

    const expiresAt = resolveAcApHtmlExpiresAt(
      resolved.expiryDays,
      Date.now(),
      resolved.expiresAt
    )
    const protectedSnapshot = await protectAcExHtmlEncodedSnapshot(
      encodeSnapshot(snapshot),
      {
        expiresAt,
        password: resolved.password || undefined
      }
    )

    const html = packHtml(snapshot, {
      title: snapshot.meta.title,
      viewerRuntime,
      encoded: protectedSnapshot.encoded,
      accessManifest: protectedSnapshot.manifest
    })

    return {
      downloadName: resolveExportDownloadName(fileName, 'html'),
      mimeType: 'text/html;charset=utf-8',
      data: html
    }
  }

  private async convert() {
    if (this.busy || !this.hasPendingSource()) {
      return
    }

    const options = this.readExportOptions()
    const securityError = this.validateSecurityOptions(options)
    if (securityError) {
      this.setStatus(securityError, true)
      this.activateTab('security')
      return
    }

    const sourceName = this.currentName
    const isMulti = options.exportFormat === 'multi'
    this.setBusy(true, format(MESSAGES.opening, { name: sourceName }))
    try {
      await this.initialize()
      const success = await this.openPendingDrawing()
      if (!success) {
        this.setStatus(format(MESSAGES.openFailed, { name: sourceName }), true)
        return
      }

      this.setStatus(
        format(isMulti ? MESSAGES.convertingZip : MESSAGES.convertingHtml, {
          name: sourceName
        })
      )
      const exportResult = await this.buildExport(sourceName)
      this.triggerDownload(
        exportResult.data,
        exportResult.downloadName,
        exportResult.mimeType
      )
      this.setStatus(
        format(isMulti ? MESSAGES.convertedZip : MESSAGES.convertedHtml, {
          name: drawingBaseName(sourceName)
        })
      )
    } catch (error) {
      log.error('HTML conversion failed:', error)
      this.setStatus(
        format(MESSAGES.convertFailed, {
          error: error instanceof Error ? error.message : String(error)
        }),
        true
      )
    } finally {
      this.setBusy(false)
    }
  }
}

new HtmlConverterApp()
