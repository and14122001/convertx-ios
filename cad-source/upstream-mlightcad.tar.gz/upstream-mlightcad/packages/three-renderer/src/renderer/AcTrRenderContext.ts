import {
  AcDbDatabase,
  ACGI_DARK_THEME_FOREGROUND,
  ACGI_LIGHT_THEME_FOREGROUND,
  AcGiContext,
  acgiIsLightBackground
} from '@mlightcad/data-model'

import {
  AcTrBatchDrawPolicy,
  alwaysBatchDrawPolicy
} from '../draw/AcTrBatchDrawPolicy'
import { AcTrStyleManager } from '../style/AcTrStyleManager'

/**
 * Per-renderer shared services passed into drawable objects during conversion.
 *
 * Bundles material/style access with scene-graph policies so entity instances
 * only hold one reference while each concern stays in its own module.
 * Extends {@link AcGiContext} so {@link AcGiRenderer.context} can carry the
 * active database and background-dependent colour resolution state.
 *
 * Defaults to {@link alwaysBatchDrawPolicy} so entities merge in
 * {@link AcTrBatchedGroup} whenever possible. Large-coordinate precision is
 * handled at render time by relative-to-eye rebasing in {@link AcTrRenderer}.
 * Inject {@link defaultBatchDrawPolicy} only when you need the legacy
 * coordinate-threshold unbatch path for testing or compatibility.
 */
export class AcTrRenderContext extends AcGiContext {
  readonly styleManager: AcTrStyleManager
  batchDrawPolicy: AcTrBatchDrawPolicy

  /**
   * Database being drawn. Narrows {@link AcGiContext.database} from `unknown`
   * to {@link AcDbDatabase} for three-renderer consumers.
   */
  database: AcDbDatabase | undefined = undefined

  /**
   * When `true` (default), {@link AcTrGroup} glyph `asyncDraw` returns to the
   * event loop every few dozen milliseconds so a browser can paint.
   * Headless export sets this to `false` so that yield does not add timer delay.
   */
  yieldDuringAsyncDraw = true

  /**
   * When `true`, glyph entities skip scene-level mesh-glyph InstancedMesh
   * enqueue during attach. Used for jig / transient overlay draws so preview
   * text cannot leave world instances that outlive each cursor update.
   *
   * Prefer this over only setting `userData.skipMeshGlyphInstancing` on the
   * root: nested MTEXT may `syncDraw` (e.g. INSERT `compactForInstancing`)
   * before the root flag exists and before children are parented to it.
   */
  skipMeshGlyphInstancing = false

  constructor(
    styleManager: AcTrStyleManager = new AcTrStyleManager(),
    batchDrawPolicy: AcTrBatchDrawPolicy = alwaysBatchDrawPolicy
  ) {
    super()
    this.styleManager = styleManager
    this.batchDrawPolicy = batchDrawPolicy
  }

  /**
   * Refreshes background-dependent fields from the canvas background colour.
   */
  syncBackgroundColor(backgroundColor: number): void {
    this.backgroundIsDark = !acgiIsLightBackground(backgroundColor)
    this.foregroundOnDark = ACGI_DARK_THEME_FOREGROUND
    this.foregroundOnLight = ACGI_LIGHT_THEME_FOREGROUND
  }
}
