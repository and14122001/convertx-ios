import {
  AcDbSolid,
  AcDbTrace,
  AcGeArea2d,
  AcGeIndexNode,
  AcGePoint2d,
  AcGePoint2dLike,
  AcGePoint3dLike,
  AcGePolyline2d
} from '@mlightcad/data-model'
import * as THREE from 'three'

import {
  type AcTrBuiltDirectGeometry,
  buildAreaGeometry,
  buildOffsetRingCenterline,
  buildOffsetRingDirectGeometry,
  getAreaBuildStats,
  resetAreaBuildStats,
  setForceGeneralAreaPath
} from '../src/object/AcTrLineGeometryBuilder'
import { AcTrRenderContext } from '../src/renderer/AcTrRenderContext'
import { AcTrSubEntityTraitsUtil } from '../src/util'

const defaultTraits = AcTrSubEntityTraitsUtil.createDefaultTraits()

/** Absolute area tolerance in squared drawing units (float32 output). */
const AREA_TOLERANCE = 1e-4
/**
 * Gauss-Krüger style drawing coordinate. float32 ulp here is 2 units, so any
 * tolerance below that proves the fast path did not lose WCS precision.
 */
const LARGE = 39_652_926.8

/** Builds a fake area whose single loop is exactly `points`. */
function areaFromLoop(points: AcGePoint2dLike[]): AcGeArea2d {
  const loop = points.map(point => new AcGePoint2d(point.x, point.y))
  const hierarchy: AcGeIndexNode = {
    index: -1,
    children: [{ index: 0, children: [] }]
  }
  // Fake area implements both legacy (getPoints/buildHierarchy) and modern
  // (tessellate) APIs so AcTrPolygon's general path works alongside the fast
  // path's API auto-detection.
  return {
    getPoints: () => [loop],
    tessellate: () => [loop],
    buildHierarchy: () => hierarchy
  } as unknown as AcGeArea2d
}

/** Builds a real closed polyline area, as `AcDbTrace.subWorldDraw` does. */
function areaFromVertices(vertices: AcGePoint2dLike[]): AcGeArea2d {
  const polyline = new AcGePolyline2d(
    vertices.map(point => new AcGePoint2d(point.x, point.y)),
    true
  )
  const area = new AcGeArea2d()
  area.add(polyline)
  return area
}

/** Axis-aligned rectangle in the canonical SOLID corner order. */
function rectangle(
  minX: number,
  minY: number,
  maxX: number,
  maxY: number
): AcGePoint2dLike[] {
  return [
    { x: minX, y: minY },
    { x: maxX, y: minY },
    { x: maxX, y: maxY },
    { x: minX, y: maxY }
  ]
}

/** Reads one geometry into local-space triangles. */
function localTriangles(geometry: THREE.BufferGeometry): number[][][] {
  const position = geometry.getAttribute('position') as THREE.BufferAttribute
  const index = geometry.getIndex() as THREE.BufferAttribute
  const triangles: number[][][] = []
  for (let i = 0; i < index.count; i += 3) {
    const triangle: number[][] = []
    for (let k = 0; k < 3; k++) {
      const vertex = index.getX(i + k)
      triangle.push([
        position.getX(vertex),
        position.getY(vertex),
        position.getZ(vertex)
      ])
    }
    triangles.push(triangle)
  }
  return triangles
}

/** Signed area of one planar triangle in X/Y. */
function signedTriangleArea(a: number[], b: number[], c: number[]): number {
  return ((b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])) * 0.5
}

/** Total covered area of an indexed triangle geometry. */
function totalArea(built: AcTrBuiltDirectGeometry): number {
  let total = 0
  for (const triangle of localTriangles(built.geometry)) {
    total += Math.abs(signedTriangleArea(triangle[0], triangle[1], triangle[2]))
  }
  return total
}

/** Every world-space vertex key referenced by at least one triangle. */
function usedVertexKeys(built: AcTrBuiltDirectGeometry): Set<string> {
  const keys = new Set<string>()
  const position = built.geometry.getAttribute(
    'position'
  ) as THREE.BufferAttribute
  const index = built.geometry.getIndex() as THREE.BufferAttribute
  for (let i = 0; i < index.count; i++) {
    const vertex = index.getX(i)
    keys.add(
      `${(position.getX(vertex) + built.worldOffset.x).toFixed(3)},${(
        position.getY(vertex) + built.worldOffset.y
      ).toFixed(3)}`
    )
  }
  return keys
}

/**
 * Builds one area through {@link buildAreaGeometry} and asserts it produced
 * mesh geometry.
 */
function build(
  area: AcGeArea2d,
  context: AcTrRenderContext,
  traits = defaultTraits
): AcTrBuiltDirectGeometry {
  const built = buildAreaGeometry(area, traits, context)
  expect(built).not.toBeNull()
  if (!built) {
    throw new Error('buildAreaGeometry returned null')
  }
  return built
}

/**
 * Asserts the fast path and the general path describe the same filled region:
 * identical covered area, identical used vertices, identical WCS bounds and
 * offset, and the same front-facing triangle winding.
 */
function expectSameFill(
  fast: AcTrBuiltDirectGeometry,
  general: AcTrBuiltDirectGeometry
) {
  const fastArea = totalArea(fast)
  const generalArea = totalArea(general)
  expect(fastArea).toBeGreaterThan(AREA_TOLERANCE)
  expect(Math.abs(fastArea - generalArea)).toBeLessThan(AREA_TOLERANCE)

  expect(usedVertexKeys(fast)).toEqual(usedVertexKeys(general))

  const winding = (built: AcTrBuiltDirectGeometry) => {
    const signs = new Set(
      localTriangles(built.geometry).map(triangle =>
        Math.sign(signedTriangleArea(triangle[0], triangle[1], triangle[2]))
      )
    )
    expect(signs.size).toBe(1)
    expect(signs.has(0)).toBe(false)
    return [...signs][0]
  }
  expect(winding(fast)).toBe(winding(general))

  // The fast path now computes wcsBbox/worldOffset from the loop's own
  // double-precision points (#729), while the general path still reads them
  // back from a built (float32) geometry. Compare with float32-ULP
  // tolerance rather than exact equality -- the fast path is the more
  // precise of the two.
  expect(fast.wcsBbox.min.x).toBeCloseTo(general.wcsBbox.min.x, 5)
  expect(fast.wcsBbox.min.y).toBeCloseTo(general.wcsBbox.min.y, 5)
  expect(fast.wcsBbox.max.x).toBeCloseTo(general.wcsBbox.max.x, 5)
  expect(fast.wcsBbox.max.y).toBeCloseTo(general.wcsBbox.max.y, 5)
  expect(fast.worldOffset.x).toBeCloseTo(general.worldOffset.x, 5)
  expect(fast.worldOffset.y).toBeCloseTo(general.worldOffset.y, 5)
  expect(fast.material).toBe(general.material)
}

/**
 * Builds the same area twice — once through the shipped fast path and once
 * forced through the general path — and compares the two outputs.
 *
 * The general path is forced with the builder's test-only seam so both builds
 * receive identical traits and therefore resolve the same material.
 */
function expectFastPathMatchesGeneral(area: AcGeArea2d) {
  // One shared context so the style-cache material instance is identical.
  const context = new AcTrRenderContext()
  resetAreaBuildStats()
  const fast = build(area, context)
  expect(getAreaBuildStats()).toEqual({
    smallLoopFastPath: 1,
    generalPath: 0, offsetRingFastPath: 0
  })

  resetAreaBuildStats()
  setForceGeneralAreaPath(true)
  let general: AcTrBuiltDirectGeometry
  try {
    general = build(area, context)
  } finally {
    setForceGeneralAreaPath(false)
  }
  expect(getAreaBuildStats()).toEqual({
    smallLoopFastPath: 0,
    generalPath: 1, offsetRingFastPath: 0
  })

  expectSameFill(fast, general)
  fast.geometry.dispose()
  general.geometry.dispose()
}

describe('buildAreaGeometry single-loop fast path', () => {
  it('matches the general path for a clockwise rectangle (edge-loop hatch)', () => {
    expectFastPathMatchesGeneral(
      areaFromLoop([
        { x: 0, y: 0 },
        { x: 0, y: 6 },
        { x: 10, y: 6 },
        { x: 10, y: 0 }
      ])
    )
  })

  it('matches the general path for a closed rectangle loop (SOLID quad)', () => {
    expectFastPathMatchesGeneral(areaFromVertices(rectangle(0, 0, 10, 6)))
  })

  it('matches the general path for an open four-point rectangle loop', () => {
    expectFastPathMatchesGeneral(areaFromLoop(rectangle(2, 3, 12, 9)))
  })

  it('matches the general path for a rotated rectangle', () => {
    const side = Math.SQRT2 * 10
    expectFastPathMatchesGeneral(
      areaFromLoop([
        { x: 0, y: 0 },
        { x: side, y: side },
        { x: 0, y: 2 * side },
        { x: -side, y: side }
      ])
    )
  })

  it('matches the general path when the quad degenerates to a triangle', () => {
    // SOLID whose corners 3 and 4 coincide: three distinct points.
    expectFastPathMatchesGeneral(
      areaFromLoop([
        { x: 0, y: 0 },
        { x: 10, y: 0 },
        { x: 4, y: 6 },
        { x: 4, y: 6 }
      ])
    )
  })

  it('matches the general path for a loop with a duplicated closing point', () => {
    expectFastPathMatchesGeneral(
      areaFromLoop([
        { x: 0, y: 0 },
        { x: 10, y: 0 },
        { x: 10, y: 6 },
        { x: 0, y: 6 },
        { x: 0, y: 0 }
      ])
    )
  })

  it('matches the general path for a concave quad (wrong fan would add area)', () => {
    // Diagonal 0→2 covers the triangle (0,0)-(10,0)-(10,10) = 50 plus the
    // thin (0,0)-(10,10)-(0,1) sliver = 5, so it covers 5 units of area
    // outside the concave polygon. Diagonal 1→3 is the correct split.
    const area = areaFromLoop([
      { x: 0, y: 0 },
      { x: 10, y: 0 },
      { x: 10, y: 10 },
      { x: 0, y: 1 }
    ])
    expectFastPathMatchesGeneral(area)

    const fast = build(area, new AcTrRenderContext())
    expect(totalArea(fast)).toBeCloseTo(55, 3)
    fast.geometry.dispose()
  })

  it('keeps large drawing coordinates precise in the fast path (#729)', () => {
    // The general (AcTrPolygon) path still writes raw WCS coordinates into a
    // float32 buffer before any rebase and loses precision at this
    // magnitude -- a separate, pre-existing instance of the same class of
    // bug, out of scope here. Assert the fast path directly against ground
    // truth instead of cross-checking against that known-imprecise baseline.
    const fast = build(
      areaFromLoop(rectangle(LARGE, LARGE, LARGE + 8, LARGE + 6)),
      new AcTrRenderContext()
    )
    expect(fast.wcsBbox.min.x).toBeCloseTo(LARGE, 5)
    expect(fast.wcsBbox.min.y).toBeCloseTo(LARGE, 5)
    expect(fast.wcsBbox.max.x).toBeCloseTo(LARGE + 8, 5)
    expect(fast.wcsBbox.max.y).toBeCloseTo(LARGE + 6, 5)
    expect(totalArea(fast)).toBeCloseTo(48, 3)
    fast.geometry.dispose()
  })

  it('falls back to the general path for a curved loop', () => {
    resetAreaBuildStats()
    const curved = new AcGePolyline2d(
      [
        { x: 0, y: 0, bulge: 1 },
        { x: 10, y: 0 },
        { x: 10, y: 10 },
        { x: 0, y: 10 }
      ],
      true
    )
    const area = new AcGeArea2d()
    area.add(curved)

    const built = build(area, new AcTrRenderContext())
    expect(built.geometry.getAttribute('position').count).toBeGreaterThan(4)
    expect(getAreaBuildStats()).toEqual({
      smallLoopFastPath: 0,
      generalPath: 1, offsetRingFastPath: 0
    })
    built.geometry.dispose()
  })

  it('leaves self-intersecting quads to the general path', () => {
    // Crossing loops have no well-defined triangulation. The fast path bails
    // out so earcut keeps deciding, instead of the builder inventing a fill
    // for a loop whose fill is undefined.
    const crossing = areaFromLoop([
      { x: 0, y: 0 },
      { x: 4, y: 0 },
      { x: 0, y: 3 },
      { x: 4, y: 3 }
    ])
    resetAreaBuildStats()
    const built = buildAreaGeometry(
      crossing,
      defaultTraits,
      new AcTrRenderContext()
    )
    expect(getAreaBuildStats()).toEqual({
      smallLoopFastPath: 0,
      generalPath: 1, offsetRingFastPath: 0
    })
    // Pin whatever earcut produces today so a future earcut change is visible.
    expect(built).not.toBeNull()
    if (built) {
      expect(totalArea(built)).toBeCloseTo(6, 3)
      built.geometry.dispose()
    }
  })

  it('falls back to the general path when the loop has a hole', () => {
    resetAreaBuildStats()
    const outer = [
      new AcGePoint2d(0, 0),
      new AcGePoint2d(10, 0),
      new AcGePoint2d(10, 10),
      new AcGePoint2d(0, 10)
    ]
    const inner = [
      new AcGePoint2d(4, 4),
      new AcGePoint2d(6, 4),
      new AcGePoint2d(6, 6),
      new AcGePoint2d(4, 6)
    ]
    const area = {
      getPoints: () => [outer, inner],
      tessellate: () => [outer, inner],
      buildHierarchy: (): AcGeIndexNode => ({
        index: -1,
        children: [{ index: 0, children: [{ index: 1, children: [] }] }]
      })
    } as unknown as AcGeArea2d

    const built = build(area, new AcTrRenderContext())
    expect(getAreaBuildStats()).toEqual({
      smallLoopFastPath: 0,
      generalPath: 1, offsetRingFastPath: 0
    })
    // Outer 100 minus the 4-unit hole.
    expect(totalArea(built)).toBeCloseTo(96, 3)
    built.geometry.dispose()
  })
})

describe('AcDbSolid / AcDbTrace fill capacity', () => {
  /** Creates a SOLID/Trace whose corners 3/4 coincide for a 3-corner solid. */
  function createSolid(cornerCount: number) {
    const solid = new AcDbSolid()
    const corners = rectangle(0, 0, 10, 6)
    for (let i = 0; i < 4; i++) {
      const corner = corners[i < cornerCount ? i : cornerCount - 1]
      solid.setPointAt(i, {
        x: corner.x,
        y: corner.y,
        z: 0
      } as unknown as AcGePoint3dLike)
    }
    return solid
  }

  it('routes every solid corner count through the fast path', () => {
    for (const cornerCount of [3, 4]) {
      const solid = createSolid(cornerCount)
      resetAreaBuildStats()
      const built = build(
        areaFromVertices(solid.subGetGripPoints()),
        new AcTrRenderContext()
      )
      expect(getAreaBuildStats()).toEqual({
        smallLoopFastPath: 1,
        generalPath: 0, offsetRingFastPath: 0
      })
      // 3 corners → one triangle; 4 corners → two.
      expect(built.geometry.getIndex()!.count).toBe(cornerCount === 3 ? 3 : 6)
      built.geometry.dispose()
    }
  })

  it('matches the general path for a real AcDbTrace boundary', () => {
    const trace = new AcDbTrace()
    const corners = rectangle(0, 0, 10, 6)
    for (let i = 0; i < 4; i++) {
      trace.setPointAt(i, {
        x: corners[i].x,
        y: corners[i].y,
        z: 0
      } as unknown as AcGePoint3dLike)
    }

    expectFastPathMatchesGeneral(areaFromVertices(trace.subGetGripPoints()))
  })
})

describe('buildOffsetRingCenterline', () => {
  it('returns a closed midpoint loop for aligned outer/inner rings', () => {
    const outer: AcGePoint3dLike[] = [
      { x: 0, y: 0, z: 0 },
      { x: 10, y: 0, z: 0 },
      { x: 10, y: 10, z: 0 },
      { x: 0, y: 10, z: 0 }
    ]
    const inner: AcGePoint3dLike[] = [
      { x: 1, y: 1, z: 0 },
      { x: 9, y: 1, z: 0 },
      { x: 9, y: 9, z: 0 },
      { x: 1, y: 9, z: 0 }
    ]
    const centerline = buildOffsetRingCenterline(outer, inner)
    expect(centerline).not.toBeNull()
    if (!centerline) return
    // 4 corners + closing vertex
    expect(centerline).toHaveLength(5)
    expect(centerline[0]).toEqual({ x: 0.5, y: 0.5, z: 0 })
    expect(centerline[1]).toEqual({ x: 9.5, y: 0.5, z: 0 })
    expect(centerline[4]).toEqual(centerline[0])
  })

  it('returns null when outer/inner vertex counts disagree', () => {
    expect(
      buildOffsetRingCenterline(
        [
          { x: 0, y: 0, z: 0 },
          { x: 1, y: 0, z: 0 },
          { x: 1, y: 1, z: 0 }
        ],
        [
          { x: 0.1, y: 0.1, z: 0 },
          { x: 0.9, y: 0.1, z: 0 }
        ]
      )
    ).toBeNull()
  })
})

describe('buildOffsetRingDirectGeometry', () => {
  function ringPoints(radius: number, count: number) {
    const points: AcGePoint3dLike[] = []
    for (let i = 0; i < count; i++) {
      const angle = (i / count) * Math.PI * 2
      points.push({
        x: Math.cos(angle) * radius,
        y: Math.sin(angle) * radius,
        z: 0
      })
    }
    return points
  }

  function ringArea(outer: AcGePoint3dLike[], inner: AcGePoint3dLike[]) {
    const area = new AcGeArea2d()
    area.add(
      new AcGePolyline2d(
        outer.map(point => new AcGePoint2d(point.x, point.y)),
        true
      )
    )
    area.add(
      new AcGePolyline2d(
        inner.map(point => new AcGePoint2d(point.x, point.y)),
        true
      )
    )
    return area
  }

  it('stitches an aligned ring and matches the general path covered area', () => {
    const outer = ringPoints(10, 16)
    const inner = ringPoints(8, 16)
    const context = new AcTrRenderContext()
    resetAreaBuildStats()
    const fast = buildOffsetRingDirectGeometry(
      outer,
      inner,
      defaultTraits,
      context
    )
    expect(fast).not.toBeNull()
    if (!fast) return
    expect(getAreaBuildStats()).toEqual({
      smallLoopFastPath: 0,
      generalPath: 0,
      offsetRingFastPath: 1
    })
    expect(fast.geometry.getIndex()!.count).toBe(16 * 6)

    const general = build(ringArea(outer, inner), context)
    expect(Math.abs(totalArea(fast) - totalArea(general))).toBeLessThan(1e-3)
    fast.geometry.dispose()
    general.geometry.dispose()
  })

  it('keeps a thin ring distinct from its outer edge at large coordinates (#729)', () => {
    // Outer/inner radii only 0.05 apart -- well under a float32 ULP at this
    // magnitude if the ring were quantized before rebasing. A collapsed
    // ring would report ~zero covered area.
    const cx = LARGE
    const cy = LARGE
    const count = 32
    const shift = (points: AcGePoint3dLike[]) =>
      points.map(p => ({ x: p.x + cx, y: p.y + cy, z: 0 }))
    const outer = shift(ringPoints(10, count))
    const inner = shift(ringPoints(9.95, count))

    const built = buildOffsetRingDirectGeometry(
      outer,
      inner,
      defaultTraits,
      new AcTrRenderContext()
    )
    expect(built).not.toBeNull()
    if (!built) return
    const expectedArea = Math.PI * (10 * 10 - 9.95 * 9.95)
    expect(totalArea(built)).toBeCloseTo(expectedArea, 0)
    built.geometry.dispose()
  })

  it('builds a multi-thousand-vertex ring without the general path', () => {
    const count = 4000
    resetAreaBuildStats()
    const started = performance.now()
    const built = buildOffsetRingDirectGeometry(
      ringPoints(100, count),
      ringPoints(99, count),
      defaultTraits,
      new AcTrRenderContext()
    )
    const elapsed = performance.now() - started
    expect(built).not.toBeNull()
    expect(elapsed).toBeLessThan(500)
    expect(getAreaBuildStats().offsetRingFastPath).toBe(1)
    expect(getAreaBuildStats().generalPath).toBe(0)
    expect(built!.geometry.getIndex()!.count).toBe(count * 6)
    built!.geometry.dispose()
  })

  it('keeps half-width at survey coordinates (float32 rebase before upload, #724)', () => {
    const cx = 38_500_000
    const cy = 12_000_000
    const halfWidth = 1.05
    const outer: AcGePoint3dLike[] = [
      { x: cx - 10 - halfWidth, y: cy - 4 - halfWidth, z: 0 },
      { x: cx + 10 + halfWidth, y: cy - 4 - halfWidth, z: 0 },
      { x: cx + 10 + halfWidth, y: cy + 4 + halfWidth, z: 0 },
      { x: cx - 10 - halfWidth, y: cy + 4 + halfWidth, z: 0 }
    ]
    const inner: AcGePoint3dLike[] = [
      { x: cx - 10 + halfWidth, y: cy - 4 + halfWidth, z: 0 },
      { x: cx + 10 - halfWidth, y: cy - 4 + halfWidth, z: 0 },
      { x: cx + 10 - halfWidth, y: cy + 4 - halfWidth, z: 0 },
      { x: cx - 10 + halfWidth, y: cy + 4 - halfWidth, z: 0 }
    ]

    const built = buildOffsetRingDirectGeometry(
      outer,
      inner,
      defaultTraits,
      new AcTrRenderContext()
    )
    expect(built).not.toBeNull()
    if (!built) return

    expect(built.worldOffset.x).toBeCloseTo(cx, 5)
    expect(built.worldOffset.y).toBeCloseTo(cy, 5)

    const position = built.geometry.getAttribute('position')
    const outer0 = new THREE.Vector3().fromBufferAttribute(position, 0)
    const inner0 = new THREE.Vector3().fromBufferAttribute(position, 4)
    expect(outer0.distanceTo(inner0)).toBeGreaterThan(1.5)

    for (let i = 0; i < position.count; i++) {
      expect(Math.abs(position.getX(i))).toBeLessThan(20)
      expect(Math.abs(position.getY(i))).toBeLessThan(20)
    }
    built.geometry.dispose()
  })
})
