# MLightCAD（日本語）

[English](./README.md) | [简体中文](./README.zh-CN.md) | [日本語](./README.ja.md) | [한국어](./README.ko.md) | [Español](./README.es.md) | [Português](./README.pt.md) | [Русский](./README.ru.md) | [Čeština](./README.cs.md)

[![npm downloads](https://img.shields.io/npm/dy/@mlightcad/cad-simple-viewer.svg?label=cad-simple-viewer)](https://www.npmjs.com/package/@mlightcad/cad-simple-viewer)
[![npm downloads](https://img.shields.io/npm/dy/@mlightcad/cad-viewer.svg?label=cad-viewer)](https://www.npmjs.com/package/@mlightcad/cad-viewer)

<a href="https://trendshift.io/repositories/16129?utm_source=trendshift-badge&amp;utm_medium=badge&amp;utm_campaign=badge-trendshift-16129" target="_blank" rel="noopener noreferrer"><img src="https://trendshift.io/api/badge/trendshift/repositories/16129/daily?language=TypeScript" alt="mlightcad%2Fcad-viewer | Trendshift" width="250" height="55"/></a>

MLightCAD は、`バックエンドサービスに一切依存せず、完全にブラウザ上で動作する世界初の Web ベース DXF/DWG ビューア兼エディタ` です。
DWG/DXF の解析、ジオメトリ処理、レンダリングをすべてブラウザ内で行うことで、MLightCAD は真のサーバーレス CAD 閲覧・編集を実現します。クラウドアプリ、オフライン利用、プライバシーに配慮したワークフローに最適です。

また、他の CAD ビューアではほとんど見られない機能として、**ワンクリックで単一の自己完結型 HTML ファイルへエクスポート** できます。ダウンロードした `.html` には図面スナップショットと軽量なビューアランタイムが埋め込まれており、受信者は **CAD アプリもサーバーもインストールも不要** で、任意のモダンブラウザから開いて、パン、ズーム、レイヤー切り替え、距離測定ができます。多くのデスクトップおよび Web CAD ビューアは自社製品内での閲覧に限られますが、MLightCAD はライブな図面を、メール送信、アーカイブ、静的ファイルホストに置けるポータブルなオフライン成果物に変換します。クライアントへの共有、コンプライアンスアーカイブ、エアギャップ環境に最適です。オフラインビューアは、同じ図面を開く際に従来のデスクトップツールよりはるかに少ないメモリを使用します（下記の[メモリ比較](#自己完結型-html-のメモリ使用量)を参照）。

- [**🌐 ホームページ**](https://mlightcad.com/)
- **🌐 ライブデモ**：[Netlify](https://mlightcad.netlify.app/) · [GitHub Pages](https://mlightcad.github.io/cad-viewer/)
- **🌐 API ドキュメント**：[Read the Docs](https://cad-viewer.readthedocs.io/en/latest/)（バージョン管理あり）· [MCP サーバー](https://gitmcp.io/mlightcad/cad-viewer)
- [**🌐 Wiki**](https://github.com/mlightcad/cad-viewer/wiki)
- X (Twitter): [@mlightcad](https://x.com/mlightcad)
- YouTube: [@mlightcad](https://www.youtube.com/@mlightcad)
- Medium: [@mlightcad](https://medium.com/@mlightcad)
- DEV.to: [@mlightcad](https://dev.to/mlightcad)
- Juejin(稀土掘金): [@mlightcad](https://juejin.cn/column/7501992214283501579)

### MLightCAD で構築されたアプリ

[Thingraph](https://cad.thingraph.site/) チームは MLightCAD 上に本番向け DWG/DXF ビューアとプラットフォーム連携を構築し、世界中で数万ユーザーにサービスを提供しています：

- [DWG Viewer Web App](https://cad.thingraph.site/dwg-viewer) — エンジニアリングチームが高速かつサーバーレスで図面にアクセスするためのブラウザベース DWG/DXF ビューア。各プラットフォーム向けインストール：
  - [Google Drive](https://workspace.google.com/marketplace/app/dwg_viewer/641533811831) — **Open with** から Drive 上の DWG/DXF を開く
  - [VS Code](https://marketplace.visualstudio.com/items?itemName=thingraph.dwg-viewer) — `.dwg` / `.dxf` 向けカスタム読み取り専用エディタ
  - [Cursor](https://open-vsx.org/extension/thingraph/dwg-viewer) — Open VSX 経由の同一拡張機能
  - [Confluence](https://marketplace.atlassian.com/apps/2890472615/dwg-viewer-for-confluence) — ページに DWG/DXF プレビューを埋め込む
  - [Windows Explorer](https://cad.thingraph.site/install/windows) — エクスプローラーでのサムネイルとプレビュー

コミュニティアプリと連携：

- [flyfish-dev/cad-viewer](https://github.com/flyfish-dev/cad-viewer) — DWG、DXF、DWF、DWFx、XPS 向け本番向けブラウザ CAD ビューア（[ライブデモ](https://cad-viewer-iys.pages.dev)）
- [Nextcloud CAD Viewer](https://github.com/ashcoft/nextcloud-cad-viewer) — ブラウザで DWG/DXF を表示する Nextcloud ネイティブアプリ（[App Store](https://apps.nextcloud.com/apps/cad_viewer)）

コミュニティ Linux デスクトップパッケージ：

- [CAD Viewer AppImage](https://github.com/pass-wind/cad-viewer-appimage) — Linux 向け Electron ベース AppImage（約 114 MB）、Fedora で検証済み
- [cad-viewer (AUR)](https://aur.archlinux.org/packages/cad-viewer) — システム Electron を使用する Arch Linux ソースパッケージ（約 5.4 MB）
- [cad-viewer-bin (AUR)](https://aur.archlinux.org/packages/cad-viewer-bin) — フォント/テンプレート同梱の Arch Linux バイナリパッケージ。完全オフラインでの図面オープンに対応

### デモアプリ（Demo Apps）

MLightCAD を自社プロダクトへ組み込む方法を示す公式サンプルです：

- [cad-simple-viewer-demo](https://github.com/mlightcad/cad-simple-viewer-example) — [`@mlightcad/cad-simple-viewer`](https://www.npmjs.com/package/@mlightcad/cad-simple-viewer) 向けの最小構成 vanilla TypeScript ホスト。ローカルまたは CDN の DXF/DWG を開き、小型ツールバーでコマンドを実行し、フル Vue UI なしで HTML/PDF/SVG エクスポートプラグインを遅延読み込みします。
- [cad-editor-demo](https://github.com/mlightcad/cad-viewer-example) — [`@mlightcad/cad-viewer`](https://www.npmjs.com/package/@mlightcad/cad-viewer) ベースのフル機能 Vue 3 アプリ。メニュー、リボン、ダイアログ、コマンドライン、ステータスバー付き（[ライブデモ](https://mlightcad.github.io/cad-viewer-example/)）。
- [cad-viewer-nextjs-demo](https://github.com/mlightcad/cad-viewer-nextjs-demo) — Next.js の「CAD ドライブ」デモ。DWG/DXF のチャンク再開アップロード、SQLite のファイル一覧とプレビュー、**ブラウザ側ライブ解析**（`cad-simple-viewer`）または**サーバー側 ACEX プリレンダ**（高速表示・低メモリ）での図面オープンに対応。

![MLightCAD Quick Demo](./assets/cad-viewer.gif)

## 機能

- **高性能** — 大規模 DWG/DXF ファイルを 60 FPS 以上の滑らかなレンダリングで表示
- **バックエンド不要** — ファイルの解析と処理をすべてブラウザ内で完結
- **データセキュリティの強化** — ファイルがデバイス外に出ないため、完全なプライバシーを確保
- **容易な統合** — サーバー設定やバックエンドインフラが不要
- サードパーティ連携に適したモジュラーアーキテクチャ
- **プラグインシステム** — 拡張可能なプラグインアーキテクチャ。UI、AI アシスタント、HTML/PDF/SVG エクスポートの公式プラグインを提供。詳細は[プラグインシステム開発ガイド](https://mlightcad.com/cad-viewer/docs/ja/development/plugin-system.html)
- **モバイルレイアウトとタッチ操作** — `@mlightcad/cad-simple-viewer` にレスポンシブなスマホ/タブレット UI とタッチジェスチャ（ピンチズーム、単指パン、タップ選択）を内蔵。専用モバイルアプリなしでモバイルブラウザから利用可能
- **オフライン HTML へのエクスポート** — 現在の図面を、埋め込みビューア付きの単一自己完結型 `.html` ファイルとしてエクスポート（パン/ズーム、範囲ズーム、レイヤー、距離測定、EN/ZH UI）。任意のブラウザでオフライン起動可能。MLightCAD インスタンスやバックエンドは不要
- オフラインおよびオンライン編集ワークフロー
- 高度な最適化手法を備えた THREE.js 3D レンダリングエンジン
- CMS、Notion、WeChat などのプラットフォームとの連携を見据えた拡張性

## 1 行のコードで DWG/DXF を埋め込む

単一の `<iframe>` で、任意のサイトに DWG/DXF 表示を追加できます。CAD バックエンドは不要で、図面をサードパーティのクラウドにアップロードする必要もありません。ファイルは**あなた自身の URL** から取得され、訪問者のブラウザだけで解析・描画され、レビュー機能（パン、ズーム、計測、注釈）がすぐ使えます。

```html
<iframe
  src="https://mlightcad.com/embed.html?url=https://example.com/plans/floor.dwg&mode=review&toolbar=1
  style="width:100%;height:600px;border:0"
  allowfullscreen>
</iframe>
```

解説とライブ体験：[Embed DWG/DXF on Your Website Without Uploading a Single Byte](https://medium.com/@mlightcad/embed-dwg-dxf-on-your-website-without-uploading-a-single-byte-cf5f6ad484c4)。

## はじめに

### 前提条件

- [Node.js](https://nodejs.org/) >= 24
- [pnpm](https://pnpm.io/) >= 10

### インストール

```bash
git clone https://github.com/mlightcad/cad-viewer.git
cd cad-viewer
pnpm install
```

### 開発

```bash
# フル機能ビューア（cad-viewer）を起動
pnpm dev

# またはシンプルビューアを起動
pnpm dev:simple
```

### ビルド

```bash
pnpm build
```

### プレビュー

```bash
# フル機能ビューアをプレビュー
pnpm preview

# シンプルビューアをプレビュー
pnpm preview:simple
```

## 使い方

MLightCAD を初めてお使いですか？**[ユーザーガイド](https://mlightcad.com/cad-viewer/docs/)** では、ビューアの画面構成、デスクトップ/タッチ操作、マークアップ、計測ツールについて順を追って説明しています。

### デスクトップブラウザ操作
- **選択**：エンティティを左クリック
- **拡大/縮小**：マウスホイールを上下にスクロール
- **パン**：マウス中ボタンを押したままドラッグ
- **消去**：エンティティを選択して `Del` キーを押す

### タブレット/モバイルブラウザ操作
- **選択**：エンティティをタップ
- **ズーム**：2 本指でピンチ
- **パン**：1 本指でドラッグ

## パフォーマンス

MLightCAD は **卓越したパフォーマンス** 向けに設計されており、高フレームレートを維持しながら非常に大きな DXF/DWG ファイルを処理できます。複数の高度なレンダリング技術でパフォーマンスを最適化しています：

- **カスタムシェーダーマテリアル**：GPU 加速シェーダーマテリアルで複雑な線種とハッチ塗りつぶしパターンを効率的にレンダリング
- **ジオメトリバッチング**：同一マテリアルの点、線、面をマージし、ドローコールを大幅に削減
- **インスタンスレンダリング**：インスタンシング技術で反復ジオメトリのレンダリングを最適化
- **バッファジオメトリ最適化**：効率的なメモリ管理とジオメトリマージングで GPU オーバーヘッドを低減
- **マテリアルキャッシュ**：類似エンティティ間でマテリアルを再利用し、状態変更を最小化
- **WebGL 最適化**：モダン WebGL 機能でハードウェア加速レンダリングを活用

これらの最適化により、MLightCAD は数千のエンティティを含む複雑な CAD 図面を滑らかにレンダリングし、応答性の高いユーザー操作を維持します。

#### 自己完結型 HTML のメモリ使用量

サンプル図面 [`canteen.dwg`](https://cdn.jsdelivr.net/gh/mlightcad/cad-data@main/data/canteen.dwg) を開いた場合のメモリ消費量の目安：

| ビューア | メモリ消費量 |
|--------|-------------|
| AutoCAD 2020 | 320 MB |
| GstarCAD Viewer (浩辰看图王) | 246 MB |
| 自己完結型 HTML（測定モード） | 56 MB |
| 自己完結型 HTML（表示モード） | 33 MB |

オフライン HTML ビューアは、表示モードで AutoCAD 2020 より約 **83% 少ない** メモリ、GstarCAD Viewer より約 **77% 少ない** メモリを使用しながら、パン/ズーム、レイヤー切り替え、距離測定（測定モード）をサポートします。

## 既知の問題

デフォルトのオープンソース DWG パスは、オプションの `@mlightcad/libredwg-converter` パッケージ経由で [LibreDWG](https://github.com/LibreDWG/libredwg) を使用します。多くの図面で問題なく動作しますが、エンティティのカバレッジは依然として限定的で、WASM バンドルははるかに大きく、起動は遅く、メモリ使用量は高く、非常に大きな DWG ファイルではメモリ不足エラーが発生する可能性があります。商用クローズドソース製品には GPL ライセンスの考慮事項も伴います。`@mlightcad/cad-simple-viewer` はデフォルトではそのコンバーターに **依存せず、登録もしません** — ホストアプリ（各 example パッケージを参照）が明示的にオプトインします。

より良い互換性、低いメモリ使用量、大容量ファイル対応、またはより明確な商用ライセンスが必要な場合は、[**プロプライエタリ DWG パーサー**](./PROPRIETARY-PARSER.md) を参照してください。

| 項目 | LibreDWG ベースパーサー | プロプライエタリ DWG パーサー |
|------|------------------------|------------------------|
| サポートエンティティ | 限定的なカバレッジ | より広いカバレッジ |
| バンドルサイズ | ~13 MB | ~437 KB |
| 読み込み速度 | 起動が遅い | 起動がはるかに高速 |
| メモリ使用量 | 高い | 低い |
| 大容量 DWG ファイル | 大容量ファイルで OOM の可能性 | そのような問題なし |
| ライセンス | GPL 伝播リスク | GPL 伝播の問題なし |

## ロードマップ

本プロジェクトの目標は、モジュラーアーキテクチャとフレームワーク非依存の統合を備えた、**ブラウザ上のフル機能 2D AutoCAD ライクシステム**（ビューア + エディタ）を構築することです。

凡例：
- [x] 完了

### コアファイルとデータ層

#### ファイルサポート

* [x] DXF 読み込み
* [x] DWG 読み込み
* [x] 自己完結型オフライン HTML へのエクスポート（埋め込みビューア）
* [x] 大容量ファイルのストリーミング / 増分読み込み
* [x] ファイルバージョン互換性（R12–Latest）

#### データモデル

* [x] 統一エンティティデータモデル
* [x] レイヤーテーブルサポート
* [x] ブロック / 挿入構造
* [ ] Handle と object ID 管理：現在 objectId は handle と同一で、bigint（int64）ではなく 1 つの文字列として表現されている
* [x] XData / 拡張辞書サポート
* [x] プロキシエンティティ処理

### レンダリングとパフォーマンス

#### レンダリングエンジン

* [x] WebGL ベースレンダリング（Three.js）
* [x] 2D 専用最適化パイプライン
* [x] レイヤーベースのシーン構成
* [x] レイアウト / ペーパースペースレンダリング
* [x] ビューポートエンティティサポート

#### パフォーマンス最適化

* [x] ジオメトリマージとバッチング
* [x] 空間インデックス（基本）
* [x] 高度な空間インデックス（R-tree / BVH）
* [ ] レベルオブディテール（LOD）レンダリング
* [ ] 超大規模図面向けマルチキャンバス / タイルレンダリング

### 表示とナビゲーション

#### ビュー制御

* [x] パン
* [x] ズーム（ホイール / ボックスズーム）
* [x] 全体表示 / 範囲フィット
* [ ] 名前付きビュー
* [ ] ビュー履歴（ビュー変更の元に戻す / やり直し）

#### 表示制御

* [x] レイヤー表示 ON/OFF
* [x] レイヤーフリーズ / ロック
* [x] 線幅表示
* [x] 線種スケーリング
* [x] 背景 / テーマ切り替え

### 選択と操作

#### 選択

* [x] 単一エンティティ選択
* [x] 選択エンティティのハイライト
* [x] ウィンドウ選択
* [x] クロシング選択
* [x] 選択フィルター（タイプ / レイヤー別）
* [x] 選択サイクリング

#### スナップ（OSNAP）

* [x] 端点
* [x] 中点
* [x] 中心
* [x] 交点
* [ ] 垂線 / 接線
* [x] 最近点
* [ ] スナップトラッキング


### 編集と変更

#### 基本編集

* [x] エンティティ編集フレームワーク
* [x] 移動
* [x] コピー
* [x] 回転
* [ ] スケール
* [x] 削除
* [x] 元に戻す / やり直し

#### ジオメトリ編集

* [x] グリップポイント
* [ ] ストレッチ
* [ ] トリム
* [ ] 延長
* [x] オフセット
* [ ] 分解
* [ ] 結合 / フィレット / 面取り（2D）

### 作図と作成ツール

#### 基本エンティティ

* [x] 線分
* [x] ポリライン
* [x] スプライン
* [x] 円
* [x] 円弧
* [x] 楕円
* [x] 矩形 / 多角形

#### 高度なエンティティ

* [x] ハッチ
* [x] テキスト（単一行 / 複数行）
* [x] 寸法（線形、位置合わせ、角度）
* [x] ブロック作成と挿入

### 測定

* [x] 距離
* [x] 弧長
* [x] 面積
* [x] 角度
* [x] 座標
* [x] エンティティ統計（長さ、面積、数）

### 寸法

* [x] 線形寸法
* [x] 角度寸法
* [x] 座標

### プロパティと UI パネル

#### プロパティパレット

* [x] 選択エンティティのプロパティ
* [ ] レイヤー、色、線種の編集
* [x] 変更時のライブ更新

#### パネルと UI

* [x] レイヤーマネージャー
* [x] ブロックマネージャー
* [x] コマンド履歴 / コンソール
* [x] ステータスバー（スナップ、直交、グリッド）

#### コマンドシステム

* [x] コマンドレジストリ
* [x] コマンドエイリアス
* [x] コマンドプロンプト（AutoCAD スタイル）

### 統合と拡張性

#### フレームワーク統合

* [x] フレームワーク非依存コア
* [ ] React 統合サンプル
* [x] Vue 統合サンプル
* [x] [Next.js 統合サンプル](https://github.com/mlightcad/cad-viewer-nextjs-demo)
* [ ] OpenLayers / マップ統合
* [ ] CMS / Notion 埋め込み

#### プラグインシステム

* [x] プラグイン API
* [ ] カスタムエンティティサポート
* [x] カスタムコマンド

### オフラインとオンライン編集

#### オフラインエディタ

* [x] ブラウザ内ローカル編集
* [x] DXF として保存
* [x] 変更セット / diff の保存
* [ ] IndexedDB 永続化

#### オンラインエディタ

* [ ] バックエンド API 設計
* [ ] ユーザー認証
* [ ] ファイルバージョン管理
* [ ] マルチユーザーアクセス制御
* [ ] リアルタイムコラボレーション（将来）

### プラットフォーム目標

* [x] Google Drive 連携（Picker データソース；Drive “Open with” は任意のフォローアップ）
* [x] OneDrive 連携（Microsoft OneDrive / SharePoint データソース）
* [ ] WeChat Mini Program ビューア
* [x] モバイルブラウザサポート（レスポンシブレイアウトとタッチ操作）

### ドキュメントとコミュニティ

* [x] アーキテクチャドキュメント
* [x] API リファレンス
* [ ] コントリビューションガイド
* [x] サンプルプロジェクト
* [x] ロードマップとチェンジログのメンテナンス

このロードマップは意図的に細分化されており、コントリビューターが **存在する機能**、**不足している機能**、**支援が必要な領域** を明確に把握できるようにしています。

## コントリビューション

コントリビューションを歓迎します！バグ修正、新機能、提案については issue または pull request を開いてください。バグ報告では、問題のある図面へのリンクを提供いただくと、再現と修正に役立ちます。

## ライセンス

MLightCAD モノレポは主に [MIT](LICENSE) ライセンスです。

DXF 読み込みは `@mlightcad/data-model` 内の組み込み MIT パーサーを使用します。DWG 読み込みは **オプトイン** です：`@mlightcad/cad-simple-viewer` は GPL の LibreDWG パッケージに依存しません。オープンソースの DWG サポートが必要なホストは、自身で `@mlightcad/libredwg-converter`（GPL-3.0）を追加し、worker と wasm を配置してコンバーターを登録します。クローズドソース製品を提供し、GPL コードを顧客に配布できない場合は、代わりに [**プロプライエタリ DWG パーサー**](./PROPRIETARY-PARSER.md) を使用してください。

→ **商用パーサー：** [PROPRIETARY-PARSER.md](./PROPRIETARY-PARSER.md)（スコープ、ライセンス、価格、統合、GPL コンプライアンス、サポート）
